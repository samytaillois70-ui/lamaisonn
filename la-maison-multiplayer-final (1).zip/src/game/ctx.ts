import * as THREE from 'three'
import type { Builder, Collider } from './builder'
import type { Mats } from './materials'
import type { Textures } from './textures'

export type Facing = 'px' | 'nx' | 'pz' | 'nz'

export interface Ctx {
  b: Builder
  M: Mats
  T: Textures
  colliders: Collider[]
  rand: () => number
  addLight: (x: number, y: number, z: number, color?: number, intensity?: number, dist?: number) => void
  picture: (x: number, y: number, z: number, facing: Facing, w: number, h: number, art?: number) => void
  plant: (x: number, y: number, z: number, scale?: number) => void
  lamp: (x: number, y: number, z: number, h?: number, light?: boolean) => void
  books: (x: number, y: number, z: number, n: number, axis: 'x' | 'z', h?: number) => void
  /** pose un collider invisible */
  block: (x1: number, y0: number, z1: number, x2: number, y1: number, z2: number) => void
  makeLeaf: (w: number, h: number, front: boolean, mat: THREE.Material) => THREE.Group
}
