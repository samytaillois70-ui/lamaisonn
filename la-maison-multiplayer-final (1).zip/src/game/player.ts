import * as THREE from 'three'
import { pointIn, type HouseSystem } from './house'

export interface CameraPose {
  position: THREE.Vector3
  yaw: number
  pitch: number
  roll: number
  fovKick: number
}

const shortestAngle = (angle: number) => Math.atan2(Math.sin(angle), Math.cos(angle))

export class PlayerSystem {
  position = new THREE.Vector3(8.7, 0, 7.8)
  velocity = new THREE.Vector3()
  yaw = -Math.PI / 2
  pitch = -0.04
  viewYaw = this.yaw
  viewPitch = this.pitch
  eye = 1.64
  height = 1.78
  stamina = 100
  battery = 100
  flashlight = true
  crouched = false
  running = false
  grounded = true
  vy = 0
  fatigue = 0
  bob = 0
  stepDistance = 0
  keys = new Set<string>()
  distance = 0
  exhausted = false
  /** During the chase the player can run without tiring. */
  freeSprint = false
  lastSafe = this.position.clone()

  // Camera feel, kept separate from gameplay position and collision.
  cameraRoll = 0
  cameraSwayX = 0
  cameraPitchSway = 0
  fovKick = 0
  private yawRate = 0
  private pitchRate = 0
  private stridePhase = 0
  private breathPhase = 0
  private landingDip = 0
  private landingVelocity = 0
  private previousLocalSpeed = 0
  private surge = 0

  constructor(private house: HouseSystem) {}

  reset() {
    this.position.set(8.7, 0, 7.8)
    this.velocity.set(0, 0, 0)
    this.yaw = -Math.PI / 2
    this.pitch = -0.04
    this.syncView()
    this.stamina = 100
    this.battery = 100
    this.flashlight = true
    this.crouched = false
    this.running = false
    this.grounded = true
    this.vy = 0
    this.distance = 0
    this.exhausted = false
    this.freeSprint = false
    this.stridePhase = 0
    this.breathPhase = 0
    this.landingDip = 0
    this.landingVelocity = 0
    this.cameraRoll = 0
    this.cameraSwayX = 0
    this.cameraPitchSway = 0
    this.fovKick = 0
    this.clear()
    this.lastSafe.copy(this.position)
  }

  clear() { this.keys.clear(); this.velocity.set(0, 0, 0); this.running = false }

  syncView() {
    this.viewYaw = this.yaw
    this.viewPitch = this.pitch
    this.yawRate = 0
    this.pitchRate = 0
  }

  look(dx: number, dy: number, sensitivity: number) {
    this.yaw -= dx * sensitivity
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * sensitivity, -1.35, 1.35)
  }

  private resolve() {
    const p = this.position
    for (let pass = 0; pass < 4; pass++) {
      let moved = false
      for (const c of this.house.nearbyColliders(p.x, p.z)) {
        if (!pointIn(c, p.x, p.y, p.z, 0.2, this.height)) continue
        const distances = [p.x + 0.2 - c.x1, c.x2 - p.x + 0.2, p.z + 0.2 - c.z1, c.z2 - p.z + 0.2]
        const min = Math.min(...distances)
        switch (distances.indexOf(min)) {
          case 0: p.x -= min; break
          case 1: p.x += min; break
          case 2: p.z -= min; break
          case 3: p.z += min; break
        }
        moved = true
      }
      const contact = this.house.openDoorContact(p, 0.2, this.height)
      if (contact) { p.add(contact); moved = true }
      if (!moved) break
    }
  }

  tick(dt: number, frozen: boolean, onStep: (running: boolean) => void, motion = true, onLand?: (impact: number) => void) {
    const k = this.keys

    // The view follows the requested look direction with a short, weighted lag.
    // It removes mouse jitter without making aiming feel disconnected.
    if (!motion || dt === 0) this.syncView()
    else {
      const previousYaw = this.viewYaw
      const previousPitch = this.viewPitch
      const yawBlend = 1 - Math.exp(-dt * 17)
      const pitchBlend = 1 - Math.exp(-dt * 19)
      this.viewYaw += shortestAngle(this.yaw - this.viewYaw) * yawBlend
      this.viewPitch += (this.pitch - this.viewPitch) * pitchBlend
      const instantYawRate = shortestAngle(this.viewYaw - previousYaw) / Math.max(dt, 0.001)
      const instantPitchRate = (this.viewPitch - previousPitch) / Math.max(dt, 0.001)
      this.yawRate = THREE.MathUtils.damp(this.yawRate, instantYawRate, 10, dt)
      this.pitchRate = THREE.MathUtils.damp(this.pitchRate, instantPitchRate, 10, dt)
    }

    const forwardInput = frozen ? 0 : Number(k.has('KeyW') || k.has('KeyZ') || k.has('ArrowUp')) - Number(k.has('KeyS') || k.has('ArrowDown'))
    const sidewaysInput = frozen ? 0 : Number(k.has('KeyD')) - Number(k.has('KeyA') || k.has('KeyQ'))
    if (!frozen) this.yaw += (Number(k.has('ArrowLeft')) - Number(k.has('ArrowRight'))) * dt * 1.35
    const crouch = this.crouched || k.has('ControlLeft')
    if (this.freeSprint) { this.exhausted = false; this.stamina = Math.max(this.stamina, 60) }
    this.running = !frozen && forwardInput > 0 && !crouch && !this.exhausted && this.stamina > 0 && (k.has('ShiftLeft') || k.has('ShiftRight'))
    if (this.running) {
      this.stamina = this.freeSprint ? 100 : Math.max(0, this.stamina - dt * 20)
      this.fatigue = 0.8
      if (this.stamina <= 0) this.exhausted = true
    } else {
      this.fatigue = Math.max(0, this.fatigue - dt)
      if (this.fatigue === 0) this.stamina = Math.min(100, this.stamina + dt * 10)
      if (this.stamina >= 30) this.exhausted = false
    }
    if (this.flashlight) this.battery = Math.max(0, this.battery - dt * 0.17)
    if (this.battery === 0) this.flashlight = false
    this.height = THREE.MathUtils.damp(this.height, crouch ? 1.06 : 1.78, 9, dt)
    this.eye = THREE.MathUtils.damp(this.eye, crouch ? 0.94 : 1.64, 9, dt)

    let targetSpeed = crouch ? 1.12 : this.running ? 4.35 : 2.18
    if (forwardInput < 0) targetSpeed *= 0.72
    else if (forwardInput === 0 && sidewaysInput !== 0) targetSpeed *= 0.88

    const sin = Math.sin(this.viewYaw)
    const cos = Math.cos(this.viewYaw)
    let dx = -sin * forwardInput + cos * sidewaysInput
    let dz = -cos * forwardInput - sin * sidewaysInput
    const inputLength = Math.hypot(dx, dz)
    if (inputLength > 0) { dx = dx / inputLength * targetSpeed; dz = dz / inputLength * targetSpeed }

    const response = !this.grounded ? 2.1 : inputLength > 0 ? (crouch ? 8.5 : 7.4) : 11.5
    this.velocity.x = THREE.MathUtils.damp(this.velocity.x, dx, response, dt)
    this.velocity.z = THREE.MathUtils.damp(this.velocity.z, dz, response, dt)

    const old = this.position.clone()
    const wasGrounded = this.grounded
    const impactVelocity = this.vy
    const steps = Math.max(1, Math.ceil(Math.hypot(this.velocity.x, this.velocity.z) * dt / 0.07))
    for (let i = 0; i < steps; i++) {
      this.position.x += this.velocity.x * dt / steps
      this.position.z += this.velocity.z * dt / steps
      this.resolve()
      const ground = this.house.ground(this.position.x, this.position.z, this.position.y)
      if (this.grounded && Math.abs(ground - this.position.y) < 0.45) this.position.y = ground
    }
    if (!frozen && this.grounded && k.has('Space') && !crouch) { this.vy = 3.3; this.grounded = false; k.delete('Space') }
    const ground = this.house.ground(this.position.x, this.position.z, this.position.y)
    if (this.grounded && this.position.y - ground > 0.45) this.grounded = false
    if (!this.grounded) {
      this.vy -= dt * 16
      this.position.y += this.vy * dt
      for (const slab of this.house.world.slabs) {
        if (this.vy <= 0 || old.y + this.height > slab.min.y + 0.04) continue
        if (this.position.x > slab.min.x && this.position.x < slab.max.x && this.position.z > slab.min.z && this.position.z < slab.max.z && this.position.y + this.height > slab.min.y) {
          this.position.y = slab.min.y - this.height; this.vy = 0
        }
      }
      if (this.position.y <= ground) {
        this.position.y = ground
        this.vy = 0
        this.grounded = true
        if (!wasGrounded) {
          const impact = Math.abs(impactVelocity)
          this.landingVelocity += Math.min(1.7, impact * 0.42)
          if (impact > 1.1 && onLand) onLand(impact)
        }
      }
    }
    // Prevent a numerical step from leaving the preserved interior footprint.
    if (!Number.isFinite(ground) || this.position.y < -3.2 || this.position.x < 0.3 || this.position.x > 17.7 || this.position.z < 0.3 || this.position.z > 8.68) {
      this.position.copy(old); this.vy = 0; this.grounded = true
    }
    this.resolve()

    const travelled = Math.hypot(this.position.x - old.x, this.position.z - old.z)
    this.distance += travelled
    this.stepDistance += travelled
    this.stridePhase += travelled * (this.running ? 3.65 : crouch ? 4.9 : 4.35)
    this.bob = this.stridePhase
    const strideLength = crouch ? 0.62 : this.running ? 1.08 : 0.78
    if (this.stepDistance > strideLength && this.grounded) {
      this.stepDistance = 0
      onStep(this.running)
    }

    // Landing spring and acceleration surge.
    this.landingVelocity += (-this.landingDip * 92 - this.landingVelocity * 13) * dt
    this.landingDip = THREE.MathUtils.clamp(this.landingDip + this.landingVelocity * dt, -0.025, 0.15)
    const forwardVector = new THREE.Vector2(-sin, -cos)
    const localSpeed = this.velocity.x * forwardVector.x + this.velocity.z * forwardVector.y
    const acceleration = dt > 0 ? (localSpeed - this.previousLocalSpeed) / dt : 0
    this.previousLocalSpeed = localSpeed
    this.surge = THREE.MathUtils.damp(this.surge, THREE.MathUtils.clamp(acceleration * 0.0035, -0.018, 0.018), 7, dt)

    const horizontalSpeed = Math.hypot(this.velocity.x, this.velocity.z)
    const right = new THREE.Vector2(cos, -sin)
    const localStrafe = this.velocity.x * right.x + this.velocity.z * right.y
    const targetRoll = motion ? THREE.MathUtils.clamp(-localStrafe * 0.0065 - this.yawRate * 0.011, -0.038, 0.038) : 0
    this.cameraRoll = THREE.MathUtils.damp(this.cameraRoll, targetRoll, 8, dt)
    this.cameraSwayX = THREE.MathUtils.damp(this.cameraSwayX, motion ? THREE.MathUtils.clamp(-this.yawRate * 0.016, -0.026, 0.026) : 0, 7, dt)
    this.cameraPitchSway = THREE.MathUtils.damp(this.cameraPitchSway, motion ? THREE.MathUtils.clamp(this.pitchRate * 0.006, -0.014, 0.014) : 0, 7, dt)
    const targetFovKick = this.running && horizontalSpeed > 3 ? (horizontalSpeed - 3) / 1.35 * 4.2 : 0
    this.fovKick = THREE.MathUtils.damp(this.fovKick, targetFovKick, 5.5, dt)
    if (horizontalSpeed < 0.18) this.breathPhase += dt * (this.stamina < 45 ? 1.65 : 1.05)
    if (!motion) {
      this.stridePhase = 0
      this.landingDip = 0
      this.cameraRoll = 0
      this.cameraSwayX = 0
      this.cameraPitchSway = 0
      this.fovKick = 0
    }
  }

  eyePosition() {
    return this.position.clone().add(new THREE.Vector3(0, this.eye, 0))
  }

  cameraPose(motion = true): CameraPose {
    const position = this.eyePosition()
    if (!motion) return { position, yaw: this.yaw, pitch: this.pitch, roll: 0, fovKick: 0 }
    const horizontalSpeed = Math.hypot(this.velocity.x, this.velocity.z)
    const speedAmount = THREE.MathUtils.clamp(horizontalSpeed / 4.35, 0, 1)
    const crouchAmount = THREE.MathUtils.clamp((1.78 - this.height) / 0.72, 0, 1)
    const amplitude = (0.009 + speedAmount * 0.017) * (1 - crouchAmount * 0.45)
    const bobY = this.grounded ? Math.sin(this.stridePhase * 2) * amplitude : 0
    const bobX = this.grounded ? Math.sin(this.stridePhase) * amplitude * 0.55 : 0
    const breathing = horizontalSpeed < 0.18 ? Math.sin(this.breathPhase * Math.PI * 2) * 0.0042 : 0
    const right = new THREE.Vector3(Math.cos(this.viewYaw), 0, -Math.sin(this.viewYaw))
    position.addScaledVector(right, bobX + this.cameraSwayX)
    position.y += bobY + breathing - this.landingDip
    return {
      position,
      yaw: this.viewYaw,
      pitch: THREE.MathUtils.clamp(this.viewPitch + this.cameraPitchSway + this.surge + (this.grounded ? Math.sin(this.stridePhase * 2 + 0.4) * amplitude * 0.16 : 0), -1.38, 1.38),
      roll: this.cameraRoll + (horizontalSpeed < 0.18 ? Math.sin(this.breathPhase * Math.PI * 2) * 0.0007 : 0),
      fovKick: this.fovKick,
    }
  }
}
