import * as THREE from 'three'
import type { HouseObject } from './builder'
import type { DoorObj } from './world'
import type { HouseSystem } from './house'
import type { NightSystem } from './night'
import type { HouseAudio } from './audio'
import type { LightingSystem } from './lighting'
import type { EntitySystem } from './entity'

export type AnomalyCategory = 'movement' | 'missing' | 'extra' | 'image' | 'light' | 'door' | 'sound' | 'presence'
export const CATEGORIES: { id: AnomalyCategory; name: string; description: string }[] = [
  { id: 'movement', name: 'Objet déplacé', description: 'Position ou orientation inhabituelle' },
  { id: 'missing', name: 'Disparition', description: 'Un objet familier manque' },
  { id: 'extra', name: 'Objet supplémentaire', description: 'Quelque chose n’était pas là' },
  { id: 'image', name: 'Image altérée', description: 'Tableau ou écran inhabituel' },
  { id: 'light', name: 'Éclairage', description: 'Une lumière a changé seule' },
  { id: 'door', name: 'Porte', description: 'Une porte s’est entrouverte' },
  { id: 'sound', name: 'Son anormal', description: 'Des coups répétés dans une pièce vide' },
  { id: 'presence', name: 'Présence', description: 'Une silhouette réellement observée' },
]

export interface AnomalyDefinition {
  id: string
  roomId: string
  category: AnomalyCategory
  weight: number
  minPhase: number
  duration: [number, number]
  condition: 'unobserved-and-visited'
  detection: 'room-and-category'
  resolution: 'restore-out-of-sight'
  point: THREE.Vector3
  object?: HouseObject
  door?: DoorObj
}

interface ActiveAnomaly {
  definition: AnomalyDefinition
  age: number
  lifetime: number
  acknowledged: boolean
  missed: boolean
  originalDoor?: { open: boolean; ajar?: number }
  duplicate?: THREE.Group
  materials?: { mesh: THREE.Mesh; material: THREE.Material | THREE.Material[] }[]
  offset?: THREE.Vector3
  angle?: number
  accent?: THREE.PointLight
  soundTimer: number
}

export interface SavedAnomaly { id: string; age: number; lifetime: number; acknowledged: boolean; offset?: number[]; angle?: number; originalDoor?: { open: boolean; ajar?: number } }

export class AnomalySystem {
  definitions: AnomalyDefinition[] = []
  active: ActiveAnomaly[] = []
  lastReport = -100
  missed = 0
  private cooldown = new Map<string, number>()
  private screenTexture: THREE.CanvasTexture

  constructor(private house: HouseSystem, private night: NightSystem, private lights: LightingSystem, private audio: HouseAudio, private entity: EntitySystem) {
    const canvas = document.createElement('canvas')
    canvas.width = 256; canvas.height = 128
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = '#141b20'; ctx.fillRect(0, 0, 256, 128)
    for (let i = 0; i < 1200; i++) {
      const v = 28 + Math.floor(Math.random() * 22)
      ctx.fillStyle = `rgb(${v},${v + 6},${v + 9})`; ctx.fillRect(Math.random() * 256, Math.random() * 128, 3, 1)
    }
    ctx.font = '12px monospace'; ctx.fillStyle = '#7e8c89'; ctx.textAlign = 'center'; ctx.fillText('AUCUN SIGNAL', 128, 68)
    this.screenTexture = new THREE.CanvasTexture(canvas)
    this.screenTexture.colorSpace = THREE.SRGBColorSpace
    const add = (id: string, roomId: string, category: AnomalyCategory, point: THREE.Vector3, object?: HouseObject, door?: DoorObj) => {
      this.definitions.push({ id, roomId, category, point: point.clone(), object, door, weight: category === 'movement' ? 1.5 : category === 'sound' ? 0.5 : 1,
        minPhase: category === 'extra' || category === 'sound' ? 2 : 1, duration: [160, 250],
        condition: 'unobserved-and-visited', detection: 'room-and-category', resolution: 'restore-out-of-sight' })
    }
    const canVanish = (object: HouseObject) => object.kind !== 'furniture' || /^(stool-|bedroom-chair|laundry-basket|bath-towel|dressing-box|living-books|basement-boxes)/.test(object.id)
    for (const room of house.rooms) {
      for (const object of room.objects) {
        if (object.kind === 'picture' || object.kind === 'screen') add(`${object.id}-image`, room.id, 'image', object.origin, object)
        else {
          add(`${object.id}-movement`, room.id, 'movement', object.origin, object)
          if (canVanish(object)) add(`${object.id}-missing`, room.id, 'missing', object.origin, object)
          if (['living-books', 'dressing-box'].includes(object.id)) add(`${object.id}-extra`, room.id, 'extra', object.origin, object)
        }
      }
      const source = house.world.lights.find((l) => house.roomForPoint(l.pos)?.id === room.id)
      if (source) add(`${room.id}-light`, room.id, 'light', source.pos)
      if (room.name !== 'Escalier sous-sol') add(`${room.id}-sound`, room.id, 'sound', room.center.clone().add(new THREE.Vector3(0, 0.7, 0)))
    }
    house.world.doors.filter((d) => !d.locked).forEach((door, index) => {
      const pos = new THREE.Vector3(door.x, door.y + 1.1, door.z)
      const room = house.roomForPoint(pos.clone().add(new THREE.Vector3(0.17, 0, 0.17)))
      if (room) add(`door-${index}`, room.id, 'door', pos, undefined, door)
    })
  }

  reset() {
    this.active.forEach((a) => this.restore(a))
    this.active = []
    this.cooldown.clear()
    this.lastReport = -100
    this.missed = 0
  }

  private canShift(object: HouseObject, delta: THREE.Vector3) {
    const bounds = object.bounds.clone().translate(delta)
    const same = this.house.roomForPoint(object.origin)?.id === this.house.roomForPoint(object.origin.clone().add(delta))?.id
    if (!same) return false
    const own = new Set(object.colliders.map((c) => c.live))
    return !this.house.world.colliders.some((c) => c.active && !own.has(c) && bounds.min.x < c.x2 - 0.025 && bounds.max.x > c.x1 + 0.025 && bounds.min.z < c.z2 - 0.025 && bounds.max.z > c.z1 + 0.025 && bounds.min.y < c.y1 - 0.025 && bounds.max.y > c.y0 + 0.025)
  }

  private objectObserved(object: HouseObject, observed: (point: THREE.Vector3) => boolean) {
    const bounds = new THREE.Box3().setFromObject(object.group)
    if (observed(object.group.position) || observed(object.origin)) return true
    for (const x of [bounds.min.x, bounds.max.x]) {
      for (const y of [bounds.min.y, bounds.max.y]) {
        for (const z of [bounds.min.z, bounds.max.z]) if (observed(new THREE.Vector3(x, y, z))) return true
      }
    }
    return false
  }

  private apply(definition: AnomalyDefinition, saved?: SavedAnomaly) {
    const a: ActiveAnomaly = { definition, age: saved?.age ?? 0, lifetime: saved?.lifetime ?? definition.duration[0] + this.night.random() * (definition.duration[1] - definition.duration[0]), acknowledged: saved?.acknowledged ?? false, missed: false, soundTimer: 1 }
    const o = definition.object
    switch (definition.category) {
      case 'movement': {
        if (!o) return null
        const deltas = [new THREE.Vector3(0, 0, 0.42), new THREE.Vector3(-0.4, 0, 0), new THREE.Vector3(0, 0, -0.34), new THREE.Vector3(0.38, 0, 0)]
        const offset = saved?.offset ? new THREE.Vector3(...saved.offset as [number, number, number]) : deltas.find((d) => this.canShift(o, d))
        if (!offset) return null
        a.offset = offset
        const turnsVisibly = /^(stool-|bedroom-chair|suite-armchair|laundry-basket)/.test(o.id)
        a.angle = saved?.angle ?? (turnsVisibly ? 0.3 : o.kind === 'furniture' ? 0.14 : 0.35)
        this.house.moveObject(o, offset, a.angle)
        break
      }
      case 'missing': if (o) this.house.moveObject(o, new THREE.Vector3(), 0, false); break
      case 'extra':
        if (o) {
          a.duplicate = o.group.clone(true)
          a.duplicate.position.add(new THREE.Vector3(0.48, 0, 0.06))
          o.group.parent?.add(a.duplicate)
        }
        break
      case 'image':
        if (!o) return null
        if (o.kind === 'screen') {
          a.materials = []
          o.group.traverse((mesh) => {
            if (!(mesh instanceof THREE.Mesh)) return
            a.materials!.push({ mesh, material: mesh.material })
            mesh.material = new THREE.MeshStandardMaterial({ color: 0x6d7e89, emissive: 0x627c85, emissiveIntensity: 0.7, emissiveMap: this.screenTexture, roughness: 0.2 })
          })
          a.accent = this.lights.addAccent(o.origin.clone().add(new THREE.Vector3(-0.18, 0, 0)))
          a.accent.intensity = 1.8
        } else {
          const size = o.bounds.getSize(new THREE.Vector3())
          o.group.rotation[size.x < size.z ? 'x' : 'z'] = saved?.angle ?? 0.13
          a.angle = saved?.angle ?? 0.13
        }
        break
      case 'door':
        if (definition.door) {
          a.originalDoor = saved?.originalDoor ?? { open: definition.door.open, ajar: definition.door.ajar }
          definition.door.ajar = definition.door.open ? 0.08 : 0.35
        }
        break
      case 'light': this.lights.overrides.set(definition.roomId, !this.lights.states.get(definition.roomId)); break
      case 'sound': break
    }
    this.lights.invalidateShadows()
    return a
  }

  spawn(observed: (point: THREE.Vector3) => boolean, player: THREE.Vector3) {
    const max = this.night.phase < 3 ? 2 : 4
    if (this.active.filter((a) => !a.acknowledged).length >= max) return false
    const candidates = this.definitions.filter((d) => {
      const room = this.house.rooms.find((r) => r.id === d.roomId)
      return d.minPhase <= this.night.phase && (room?.visited || this.night.phase >= 3) &&
        !observed(d.point) && (!d.object || !this.objectObserved(d.object, observed)) && d.point.distanceTo(player) > 2.5 &&
        (this.cooldown.get(d.id) ?? 0) < this.night.elapsed &&
        !this.active.some((a) => a.definition.roomId === d.roomId || d.object && a.definition.object === d.object)
    })
    let pool = candidates.reduce((sum, d) => sum + d.weight, 0)
    let target = this.night.random() * pool
    if (pool === 0) return false
    for (const d of candidates) {
      target -= d.weight
      if (target > 0) continue
      const active = this.apply(d)
      if (active) { this.active.push(active); return true }
      pool -= d.weight
    }
    return false
  }

  private restore(a: ActiveAnomaly) {
    const d = a.definition
    if (d.object) {
      d.object.group.rotation.set(0, 0, 0)
      this.house.moveObject(d.object)
    }
    a.duplicate?.removeFromParent()
    a.materials?.forEach(({ mesh, material }) => {
      const current = mesh.material
      if (!Array.isArray(current)) current.dispose()
      mesh.material = material
    })
    if (a.accent) this.lights.removeAccent(a.accent)
    if (d.door && a.originalDoor) { d.door.open = a.originalDoor.open; d.door.ajar = a.originalDoor.ajar }
    if (d.category === 'light') this.lights.overrides.delete(d.roomId)
    this.lights.invalidateShadows()
  }

  tick(dt: number, observed: (point: THREE.Vector3) => boolean) {
    for (const a of [...this.active]) {
      a.age += dt
      if (a.definition.category === 'sound' && !a.acknowledged) {
        a.soundTimer -= dt
        if (a.soundTimer <= 0) { a.soundTimer = 9 + this.night.random() * 5; this.audio.play('knock', a.definition.point, 0.56) }
      }
      if (a.age > a.lifetime && !a.missed && !a.acknowledged) {
        a.missed = true
        this.missed++
        // Every missed anomaly leaves a little more of the house wrong: lights lose strength,
        // the atmosphere gets less stable, and later manifestations become easier to miss.
        this.lights.corruption = THREE.MathUtils.clamp(this.lights.corruption + 0.075, 0, 0.85)
        this.lights.invalidateShadows()
        this.audio.play('glitch', undefined, 0.22 + Math.min(0.25, this.missed * 0.015))
      }
      const point = a.definition.object?.group.position ?? a.definition.point
      if ((a.acknowledged || a.age > a.lifetime) && !observed(point) && !observed(a.definition.point) && (!a.definition.object || !this.objectObserved(a.definition.object, observed)) && (!a.duplicate || !observed(a.duplicate.position))) {
        this.restore(a)
        this.cooldown.set(a.definition.id, this.night.elapsed + 180)
        this.active = this.active.filter((entry) => entry !== a)
      }
    }
  }

  report(roomId: string, category: AnomalyCategory) {
    if (this.night.elapsed - this.lastReport < 9) return { accepted: false, message: 'Vérification en cours. Patientez quelques secondes.', pending: true }
    this.lastReport = this.night.elapsed
    const anomaly = this.active.find((a) => !a.acknowledged && a.definition.roomId === roomId && a.definition.category === category)
    const presence = category === 'presence' && this.entity.hasSighting(roomId)
    if (anomaly || presence) {
      if (anomaly) anomaly.acknowledged = true
      this.night.reports++
      const room = this.house.rooms.find((r) => r.id === roomId)
      this.night.log(`${room?.name ?? 'Maison'} : ${CATEGORIES.find((c) => c.id === category)?.name.toLowerCase()}. Écart confirmé.`, 'report')
      // Naming what changed makes it leave. Another will come back later in the night.
      this.entity.banish()
      this.entity.lastSeenAt = -100
      return { accepted: true, message: 'Écart confirmé. Le relevé a été enregistré.', pending: false }
    }
    this.night.mistakes++
    this.night.log('Aucun écart confirmé pour ce relevé. Un bruit isolé peut venir de la maison.', 'note')
    return { accepted: false, message: 'Aucun écart confirmé. Observez encore avant de conclure.', pending: false }
  }

  doorTouched(door: DoorObj) {
    const a = this.active.find((entry) => entry.definition.door === door)
    if (a) {
      a.acknowledged = true
      a.originalDoor = { open: !door.open }
    }
  }

  save(): SavedAnomaly[] {
    return this.active.map((a) => ({ id: a.definition.id, age: a.age, lifetime: a.lifetime, acknowledged: a.acknowledged, offset: a.offset?.toArray(), angle: a.angle, originalDoor: a.originalDoor }))
  }

  load(saved: SavedAnomaly[]) {
    this.reset()
    for (const data of saved) {
      const definition = this.definitions.find((d) => d.id === data.id)
      if (definition) { const a = this.apply(definition, data); if (a) this.active.push(a) }
    }
  }

  dispose() { this.reset(); this.screenTexture.dispose() }
}