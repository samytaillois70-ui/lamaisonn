import * as THREE from 'three'
import type { DoorObj, World } from './world'
import type { HouseAudio } from './audio'

export class DoorSystem {
  private speeds = new Map<DoorObj, number>()
  constructor(private world: World, private audio: HouseAudio) {}

  set(door: DoorObj, open: boolean, slow = false) {
    if (door.locked || door.open === open && door.ajar === undefined) return false
    door.open = open
    door.ajar = undefined
    this.speeds.set(door, slow ? 0.32 : 1.3)
    this.audio.play('door', new THREE.Vector3(door.x, door.y + 1, door.z), slow ? 0.32 : 0.6)
    return true
  }

  reset() {
    for (const d of this.world.doors) {
      d.open = false; d.ajar = undefined; d.t = 0; d.collider.active = true
      d.group.rotation.y = d.theta0
      d.group.scale.y = 1
    }
  }

  tick(dt: number, player: THREE.Vector3) {
    let changed = false
    for (const d of this.world.doors) {
      let target = d.locked ? 0 : d.ajar ?? (d.open ? 1 : 0)
      if (target < d.t && Math.abs(player.y - d.y) < 1.4) {
        const c = d.collider
        if (player.x > c.x1 - 0.25 && player.x < c.x2 + 0.25 && player.z > c.z1 - 0.25 && player.z < c.z2 + 0.25) target = d.t
      }
      if (Math.abs(target - d.t) > 0.001) {
        const step = (this.speeds.get(d) ?? 0.55) * dt
        d.t = THREE.MathUtils.clamp(target > d.t ? d.t + step : d.t - step, Math.min(target, d.t), Math.max(target, d.t))
        changed = true
      } else d.t = target
      const ease = d.t * d.t * (3 - 2 * d.t)
      if (d.kind === 'door') d.group.rotation.y = d.theta0 + d.phi * ease
      else d.group.scale.y = 1 - ease * 0.96
      d.collider.active = d.locked || d.t < 0.64
    }
    return changed
  }
}