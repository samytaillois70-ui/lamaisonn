import * as THREE from 'three'
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js'
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js'
import { GTAOPass } from 'three/examples/jsm/postprocessing/GTAOPass.js'
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js'
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js'
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js'
import { Pass } from 'three/examples/jsm/postprocessing/Pass.js'

export type FxTier = 'off' | 'standard' | 'ultra'

export interface FxParams {
  cctv: boolean
  stress: number
  /** 0..1, how dark the scene is: more sensor noise in the dark, like a real eye or camera. */
  darkness: number
  /** 0..1: the picture breaks. Torn slices, wrong colours. */
  glitch: number
}

// Final grade, applied after tone mapping: film grain that fades in bright areas,
// a trace of lateral chromatic aberration toward the edges, a lens vignette,
// and a low-quality surveillance sensor look for the cameras.
const GradeShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    time: { value: 0 },
    grain: { value: 0.03 },
    aberration: { value: 0.0025 },
    vignette: { value: 0.32 },
    cctv: { value: 0 },
    glitch: { value: 0 },
    resolution: { value: new THREE.Vector2(1920, 1080) },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
  fragmentShader: `
    uniform sampler2D tDiffuse; uniform float time; uniform float grain; uniform float aberration;
    uniform float vignette; uniform float cctv; uniform float glitch; uniform vec2 resolution; varying vec2 vUv;
    float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
    void main(){
      vec2 uv = vUv;
      // The picture tears: horizontal slices slide sideways and blocks repeat.
      float tick = floor(time * 14.0);
      float band = floor(uv.y * 28.0);
      float torn = step(1.0 - 0.38 * glitch, hash(vec2(band, tick)));
      uv.x += torn * (hash(vec2(band, tick + 3.0)) - 0.5) * 0.22 * glitch;
      float block = step(1.0 - 0.1 * glitch, hash(vec2(floor(uv.x * 9.0), floor(uv.y * 7.0) + tick)));
      uv = mix(uv, fract(uv + vec2(0.07, -0.05)), block);
      vec2 c = uv - 0.5; float r2 = dot(c, c);
      vec2 off = c * r2 * aberration * 2.0 + vec2(glitch * 0.02 * (hash(vec2(tick, 5.0)) - 0.4), 0.0);
      vec3 col;
      col.r = texture2D(tDiffuse, uv + off).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - off).b;
      // Wrong colours: channels swap, the picture goes negative for a frame, coloured noise.
      float swap = step(0.55, hash(vec2(tick, 1.0))) * glitch;
      col = mix(col, col.gbr, swap * 0.9);
      float flip = step(0.9, hash(vec2(tick, 2.0))) * glitch;
      col = mix(col, vec3(1.0) - col, flip);
      col += glitch * 0.18 * (vec3(hash(uv * resolution + time), hash(uv * resolution * 1.3 + time), hash(uv * resolution * 0.7 + time)) - 0.5) * step(0.5, hash(vec2(band, tick + 9.0)));
      float luma = dot(col, vec3(0.299, 0.587, 0.114));
      float g1 = hash(uv * resolution + fract(time) * vec2(37.1, 91.7)) - 0.5;
      float g2 = hash(uv * resolution * 0.5 + fract(time * 1.3) * vec2(12.3, 77.7)) - 0.5;
      float amount = grain * (1.0 - luma * 0.8);
      col += vec3(g1, g2, (g1 + g2) * 0.5) * amount;
      if (cctv > 0.5) {
        float scan = sin(uv.y * resolution.y * 1.6) * 0.5 + 0.5;
        col *= 1.0 - 0.1 * scan;
        col = mix(col, vec3(luma), 0.3);
        col = floor(col * 36.0 + 0.5) / 36.0;
        col += (hash(vec2(floor(uv.y * resolution.y / 3.0), time)) - 0.5) * 0.028;
      }
      col *= 1.0 - vignette * smoothstep(0.18, 0.95, r2 * 2.4);
      gl_FragColor = vec4(max(col, 0.0), 1.0);
    }`,
}

/** Hides or restores objects that must not take part in the ambient occlusion normal pass. */
class VisibilityPass extends Pass {
  constructor(private objects: () => THREE.Object3D[], private hide: boolean) {
    super()
    this.needsSwap = false
  }
  render() {
    for (const object of this.objects()) {
      if (this.hide) { object.userData.fxVisible = object.visible; object.visible = false }
      else if (object.userData.fxVisible !== undefined) object.visible = object.userData.fxVisible as boolean
    }
  }
}

export class PostFX {
  tier: FxTier = 'ultra'
  private composer: EffectComposer
  private ao: GTAOPass
  private bloom: UnrealBloomPass
  private grade: ShaderPass
  private hidePass: VisibilityPass
  private showPass: VisibilityPass
  private low = 0
  private clock = 0

  constructor(private renderer: THREE.WebGLRenderer, private scene: THREE.Scene, private camera: THREE.PerspectiveCamera, hidden: () => THREE.Object3D[]) {
    const size = renderer.getSize(new THREE.Vector2())
    const ratio = renderer.getPixelRatio()
    const samples = Math.min(4, renderer.capabilities.maxSamples)
    const target = new THREE.WebGLRenderTarget(Math.max(2, size.x * ratio), Math.max(2, size.y * ratio), { type: THREE.HalfFloatType, samples })
    this.composer = new EffectComposer(renderer, target)
    this.composer.setPixelRatio(ratio)
    this.composer.setSize(size.x, size.y)
    this.composer.addPass(new RenderPass(scene, camera))
    this.hidePass = new VisibilityPass(hidden, true)
    this.showPass = new VisibilityPass(hidden, false)
    this.ao = new GTAOPass(scene, camera, size.x, size.y)
    this.ao.updateGtaoMaterial({ radius: 0.6, distanceExponent: 1.5, thickness: 1.4, scale: 1.25, samples: 14 })
    this.ao.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 6, rings: 2, samples: 12 })
    this.ao.blendIntensity = 0.95
    this.composer.addPass(this.hidePass)
    this.composer.addPass(this.ao)
    this.composer.addPass(this.showPass)
    // Only truly bright things glow: bulbs, the standby diode, the torch lens.
    this.bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 0.3, 0.6, 1.4)
    this.composer.addPass(this.bloom)
    this.composer.addPass(new OutputPass())
    this.grade = new ShaderPass(GradeShader)
    this.composer.addPass(this.grade)
    this.setTier('ultra')
  }

  setTier(tier: FxTier) {
    this.tier = tier
    const ultra = tier === 'ultra'
    this.ao.enabled = ultra
    this.hidePass.enabled = ultra
    this.showPass.enabled = ultra
    this.bloom.enabled = tier !== 'off'
  }

  setSize(width: number, height: number, ratio: number) {
    this.composer.setPixelRatio(ratio)
    this.composer.setSize(width, height)
    this.grade.uniforms.resolution.value.set(width * ratio, height * ratio)
  }

  /** Drops a tier if the frame rate stays low. Returns the new tier when it changes. */
  adapt(fps: number, dt: number): FxTier | null {
    if (this.tier === 'off' || fps <= 0) return null
    if (fps < (this.tier === 'ultra' ? 30 : 20)) this.low += dt
    else this.low = Math.max(0, this.low - dt * 2)
    if (this.low > 5) {
      this.low = 0
      this.setTier(this.tier === 'ultra' ? 'standard' : 'off')
      return this.tier
    }
    return null
  }

  render(dt: number, p: FxParams) {
    if (this.tier === 'off') {
      this.renderer.render(this.scene, this.camera)
      return
    }
    this.clock += dt
    const u = this.grade.uniforms
    u.time.value = this.clock
    u.cctv.value = p.cctv ? 1 : 0
    u.glitch.value = p.glitch
    u.grain.value = (p.cctv ? 0.05 : 0.022) + p.darkness * 0.022
    u.aberration.value = 0.0022 + p.stress * 0.004 + (p.cctv ? 0.003 : 0)
    u.vignette.value = p.cctv ? 0.5 : 0.3 + p.stress * 0.18
    this.bloom.strength = 0.26 + p.darkness * 0.12
    this.composer.render(dt)
  }

  dispose() {
    this.composer.dispose()
    this.ao.dispose()
    this.bloom.dispose()
  }
}
