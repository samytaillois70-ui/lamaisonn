import * as THREE from 'three'

const COUNT = 620
const RANGE_XZ = 6.5
const RANGE_Y = 3.2

/**
 * Dust motes drifting in the air. They exist everywhere around the player but are only
 * visible where light reaches them: inside the torch beam and close to a lit lamp.
 * In a dark room with no light, there is nothing to see, exactly as in real life.
 */
export class Dust {
  readonly points: THREE.Points
  private positions = new Float32Array(COUNT * 3)
  private seeds = new Float32Array(COUNT)
  private velocity = new Float32Array(COUNT * 3)
  private material: THREE.ShaderMaterial
  private lamps: THREE.Vector3[] = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]
  private lampOn = [0, 0, 0, 0]
  private time = 0
  private primed = false

  constructor() {
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3))
    for (let i = 0; i < COUNT; i++) this.seeds[i] = Math.random()
    geometry.setAttribute('seed', new THREE.BufferAttribute(this.seeds, 1))
    this.material = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
      uniforms: {
        uTime: { value: 0 },
        uPixel: { value: 1 },
        uTorchPos: { value: new THREE.Vector3() },
        uTorchDir: { value: new THREE.Vector3(0, 0, -1) },
        uTorch: { value: 0 },
        uCos: { value: Math.cos(0.38) },
        uLamp: { value: this.lamps },
        uLampOn: { value: this.lampOn },
      },
      vertexShader: `
        attribute float seed;
        uniform float uTime; uniform float uPixel;
        uniform vec3 uTorchPos; uniform vec3 uTorchDir; uniform float uTorch; uniform float uCos;
        uniform vec3 uLamp[4]; uniform float uLampOn[4];
        varying float vLight;
        void main(){
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vec3 d = position - uTorchPos;
          float dist = max(length(d), 0.001);
          float c = dot(d / dist, uTorchDir);
          float cone = smoothstep(uCos - 0.03, uCos + 0.07, c) * (1.0 - smoothstep(5.0, 15.0, dist));
          float light = uTorch * cone * (0.9 / (1.0 + dist * 0.22));
          for (int i = 0; i < 4; i++) {
            float dl = length(position - uLamp[i]);
            light += uLampOn[i] * (1.0 - smoothstep(0.4, 3.4, dl)) * 0.5;
          }
          float twinkle = 0.55 + 0.45 * sin(uTime * (1.2 + seed * 2.4) + seed * 60.0);
          vLight = light * twinkle;
          gl_PointSize = clamp((1.5 + seed * 2.6) * uPixel * (4.0 / max(-mv.z, 0.3)), 1.0, 7.0);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying float vLight;
        void main(){
          vec2 p = gl_PointCoord - 0.5;
          float a = smoothstep(0.5, 0.0, length(p)) * vLight;
          if (a < 0.003) discard;
          gl_FragColor = vec4(vec3(1.0, 0.93, 0.8) * a, a);
        }`,
    })
    this.points = new THREE.Points(geometry, this.material)
    this.points.frustumCulled = false
    this.points.renderOrder = 4
    this.points.name = 'dust'
  }

  setPixelRatio(ratio: number) {
    this.material.uniforms.uPixel.value = ratio
  }

  setLamps(sources: THREE.Vector3[]) {
    for (let i = 0; i < 4; i++) {
      const s = sources[i]
      if (s) { this.lamps[i].copy(s); this.lampOn[i] = 1 } else this.lampOn[i] = 0
    }
  }

  update(dt: number, camera: THREE.Camera, torch: { on: boolean; power: number; angle: number }) {
    this.time += dt
    const eye = camera.position
    if (!this.primed) {
      for (let i = 0; i < COUNT; i++) this.scatter(i, eye, true)
      this.primed = true
    }
    for (let i = 0; i < COUNT; i++) {
      const k = i * 3
      // Slow convection plus a random walk: motes hang in the air rather than falling.
      const s = this.seeds[i]
      this.velocity[k] += (Math.sin(this.time * 0.31 + s * 40) * 0.012 - this.velocity[k] * 0.5) * dt
      this.velocity[k + 1] += (Math.sin(this.time * 0.23 + s * 17) * 0.008 - 0.003 - this.velocity[k + 1] * 0.6) * dt
      this.velocity[k + 2] += (Math.cos(this.time * 0.27 + s * 29) * 0.012 - this.velocity[k + 2] * 0.5) * dt
      this.positions[k] += this.velocity[k] * dt
      this.positions[k + 1] += this.velocity[k + 1] * dt
      this.positions[k + 2] += this.velocity[k + 2] * dt
      if (Math.abs(this.positions[k] - eye.x) > RANGE_XZ || Math.abs(this.positions[k + 2] - eye.z) > RANGE_XZ || Math.abs(this.positions[k + 1] - eye.y) > RANGE_Y) this.scatter(i, eye, false)
    }
    ;(this.points.geometry.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true
    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
    const lens = new THREE.Vector3(0.17, -0.165, -0.56).applyQuaternion(camera.quaternion).add(camera.position)
    const u = this.material.uniforms
    u.uTime.value = this.time
    u.uTorchPos.value.copy(lens)
    u.uTorchDir.value.copy(forward)
    u.uTorch.value += ((torch.on ? torch.power : 0) - u.uTorch.value) * Math.min(1, dt * 10)
    u.uCos.value = Math.cos(torch.angle)
  }

  private scatter(i: number, eye: THREE.Vector3, anywhere: boolean) {
    const k = i * 3
    this.positions[k] = eye.x + (Math.random() * 2 - 1) * RANGE_XZ
    this.positions[k + 1] = eye.y + (Math.random() * 2 - 1) * RANGE_Y * 0.8
    this.positions[k + 2] = eye.z + (Math.random() * 2 - 1) * RANGE_XZ
    if (!anywhere) {
      // Fresh motes appear at the edge of the volume, never popping in right in front of the eye.
      const a = Math.random() * Math.PI * 2
      const r = RANGE_XZ * (0.8 + Math.random() * 0.2)
      this.positions[k] = eye.x + Math.cos(a) * r
      this.positions[k + 2] = eye.z + Math.sin(a) * r
    }
    this.velocity[k] = this.velocity[k + 1] = this.velocity[k + 2] = 0
  }

  dispose() {
    this.points.geometry.dispose()
    this.material.dispose()
  }
}
