import * as THREE from 'three'
import type { SoundKind } from './audio'
import type { InteractionTarget } from './interactions'
import { CLUTTER_KINDS, buildCartridge, buildClutter, buildHammer, buildKey, buildNote, buildPistol } from './props'

export type ItemId = 'hammer' | 'doorKey' | 'gunKey' | 'drawerKey' | 'note'
export const ITEM_LABEL: Record<ItemId, string> = {
  hammer: 'Marteau',
  doorKey: "Clé d'entrée",
  gunKey: 'Clé armoire',
  drawerKey: 'Clé de meuble',
  note: 'Papier',
}

export interface UseResult {
  msg?: string
  long?: boolean
  sound?: SoundKind
  /** A second sound layered on the first: the key, then the drawer sliding. */
  also?: SoundKind
  panel?: 'keypad' | 'note'
  hold?: boolean
  exit?: boolean
  log?: string
}

type Style = 'bar' | 'knob' | 'cup' | 'slot'

interface Spot {
  id: string
  label: string
  /** Where the drawer is, as a player would say it. */
  room: string
  /** Centre of the drawer front, on the plane of the existing furniture face. */
  at: [number, number, number]
  axis: 'x' | 'z'
  dir: 1 | -1
  w: number
  h: number
  depth: number
  style: Style
  /** A painted front. Otherwise it is wood, tinted to sit next to the furniture around it. */
  paint?: number
  grain?: number
  metal?: boolean
  locked?: boolean
  out?: number
}

// Every position sits on a face of furniture that already exists in the house.
const SPOTS: Spot[] = [
  { id: 'hall', label: 'tiroir de la console du hall', room: 'le hall', at: [9.58, 0.7, 5.3], axis: 'x', dir: -1, w: 0.52, h: 0.09, depth: 0.3, style: 'knob', grain: 0x959595 },
  { id: 'salon', label: 'tiroir de la console du salon', room: 'le salon', at: [10.47, 0.7, 5.35], axis: 'x', dir: 1, w: 0.5, h: 0.09, depth: 0.3, style: 'knob', grain: 0x959595 },
  { id: 'ilot', label: "tiroir de l'îlot de cuisine", room: 'la cuisine', at: [13.25, 0.55, 2.0], axis: 'z', dir: -1, w: 0.6, h: 0.22, depth: 0.45, style: 'bar', paint: 0xd9d4c8 },
  { id: 'buanderie', label: 'tiroir de la buanderie', room: 'la buanderie', at: [7.0, 0.55, 0.75], axis: 'z', dir: 1, w: 0.5, h: 0.22, depth: 0.45, style: 'bar', paint: 0xd9d4c8 },
  { id: 'coffre', label: 'tiroir du coffre à outils', room: 'le garage', at: [1.5, 0.55, 2.37], axis: 'x', dir: 1, w: 0.5, h: 0.13, depth: 0.4, style: 'bar', paint: 0x8f211c, metal: true, out: 0.05 },
  { id: 'etabli', label: "tiroir de l'établi", room: 'le garage', at: [0.8, 0.79, 2.6], axis: 'x', dir: 1, w: 0.5, h: 0.12, depth: 0.35, style: 'knob', grain: 0x959595 },
  { id: 'chevet-amie', label: 'tiroir de la table de chevet', room: 'la chambre amie', at: [10.62, 3.34, 0.55], axis: 'z', dir: 1, w: 0.36, h: 0.16, depth: 0.3, style: 'knob', paint: 0x2a2523 },
  { id: 'dressing', label: "tiroir de l'îlot du dressing", room: 'le dressing', at: [15.6, 3.5, 2.7], axis: 'z', dir: 1, w: 0.5, h: 0.2, depth: 0.5, style: 'bar', paint: 0x2a2523, locked: true },
  { id: 'bain', label: 'meuble de la salle de bain', room: 'la salle de bain', at: [9.2, 3.45, 6.78], axis: 'x', dir: 1, w: 0.42, h: 0.3, depth: 0.4, style: 'cup', paint: 0x2a2523 },
  { id: 'chevet-suite', label: 'tiroir de la table de chevet', room: 'la suite parentale', at: [17.4, 3.38, 5.45], axis: 'x', dir: -1, w: 0.4, h: 0.16, depth: 0.3, style: 'knob', paint: 0x2a2523 },
  { id: 'tele', label: 'meuble de la télévision', room: 'le salon', at: [17.145, 0.26, 7.4], axis: 'x', dir: -1, w: 0.5, h: 0.34, depth: 0.5, style: 'slot', grain: 0xb09070, locked: true },
  { id: 'commode', label: 'commode de la suite parentale', room: 'la suite parentale', at: [12.2, 3.5, 7.6], axis: 'x', dir: 1, w: 0.8, h: 0.2, depth: 0.5, style: 'bar', grain: 0x959595, locked: true },
]

/**
 * The chain, in the order a player meets it. Nothing is random between two rooms that make no sense
 * together, and nothing is ever hidden behind something that is itself hidden behind it.
 *
 *   free drawers, on the ground floor      -> the small drawer key
 *   the garage (a hammer belongs there)    -> the hammer
 *   bedside tables and the bathroom        -> the paper with the code
 *   the three drawers that have a lock     -> the front-door key and the gun-cabinet key
 */
const POOLS: Record<ItemId, string[]> = {
  drawerKey: ['hall', 'salon', 'ilot', 'buanderie'],
  hammer: ['etabli', 'coffre'],
  note: ['chevet-amie', 'chevet-suite', 'bain'],
  doorKey: ['tele', 'commode', 'dressing'],
  gunKey: ['tele', 'commode', 'dressing'],
}

/** Seconds without any progress before the game says where to look. */
const HINT_AFTER = 150

interface Drawer {
  spot: Spot
  root: THREE.Group
  slider: THREE.Group
  holder: THREE.Group
  item: THREE.Group | null
  open: number
  vel: number
  target: number
  shake: number
  tried: number
  travel: number
  unlocked: boolean
}

interface FallingPlank { mesh: THREE.Mesh; vy: number; spin: number; vx: number; time: number }
interface Pickup { obj: THREE.Group; from: THREE.Vector3; q: THREE.Quaternion; scale: number; t: number }

export interface EscapeSave {
  placement: Record<string, ItemId | null>
  opened: string[]
  unlocked: string[]
  inv: ItemId[]
  code: string
  planks: [boolean, boolean]
  keypad: boolean
  lock: boolean
  cabinet: boolean
  gun: boolean
  bullets: number
  discovered: boolean
}

const PLANK_Z = 8.835

function seeded(text: string) {
  let h = 2166136261
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619)
  let s = h >>> 0
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0
    return s / 4294967296
  }
}

export class EscapeSystem {
  readonly group = new THREE.Group()
  readonly targets: InteractionTarget[] = []
  inv = new Set<ItemId>()
  code = '0000'
  planks: [boolean, boolean] = [false, false]
  keypadOk = false
  lockOpen = false
  cabinetOpen = false
  gunTaken = false
  bullets = 0
  discovered = false
  placement: Record<string, ItemId | null> = {}
  drawers = new Map<string, Drawer>()
  pickups: Pickup[] = []
  idle = 0
  private lastSig = ''
  private plankMeshes: (THREE.Mesh | null)[] = [null, null]
  private falling: FallingPlank[] = []
  private ledMaterial = new THREE.MeshStandardMaterial({ color: 0x331111, emissive: 0xff2a1a, emissiveIntensity: 1.6 })
  private cabDoor = new THREE.Group()
  private cabOpenAmount = 0
  private cabContents = new THREE.Group()
  private byId = new Map<string, InteractionTarget>()
  private cache = new Map<string, THREE.MeshStandardMaterial>()
  private wood: THREE.CanvasTexture
  private black = new THREE.MeshBasicMaterial({ color: 0x020202 })
  private brass = new THREE.MeshStandardMaterial({ color: 0xb9923f, roughness: 0.32, metalness: 0.9 })
  private chrome = new THREE.MeshStandardMaterial({ color: 0xc7cbce, roughness: 0.2, metalness: 1 })
  private readonly _v = new THREE.Vector3()
  private readonly _f = new THREE.Vector3()
  private readonly _u = new THREE.Vector3(0, 1, 0)
  private readonly _q = new THREE.Quaternion()

  constructor(scene: THREE.Scene) {
    this.group.name = 'escape-room'
    this.wood = this.woodTexture()
    SPOTS.forEach((spot) => this.buildDrawer(spot))
    this.buildPlanks()
    this.buildKeypad()
    this.buildLock()
    this.buildCabinet()
    scene.add(this.group)
  }

  /* ------------------------------------------------------------ construction */

  private std(key: string, make: () => THREE.MeshStandardMaterial) {
    let m = this.cache.get(key)
    if (!m) { m = make(); this.cache.set(key, m) }
    return m
  }

  private target(escapeId: string, label: string, position: THREE.Vector3, hold?: number) {
    const t: InteractionTarget = { id: `escape-${escapeId}`, kind: 'escape', escapeId, label, position, hold }
    this.targets.push(t)
    this.byId.set(escapeId, t)
    return t
  }

  private woodTexture() {
    const c = document.createElement('canvas')
    c.width = 256
    c.height = 64
    const x = c.getContext('2d')!
    x.fillStyle = '#6b5238'
    x.fillRect(0, 0, 256, 64)
    const r = seeded('wood')
    for (let i = 0; i < 80; i++) {
      x.strokeStyle = `rgba(${r() > 0.5 ? '30,20,12' : '150,118,82'},${0.1 + r() * 0.26})`
      x.lineWidth = 0.6 + r() * 1.1
      x.beginPath()
      const y = r() * 64
      x.moveTo(0, y)
      x.bezierCurveTo(80, y + (r() - 0.5) * 6, 170, y + (r() - 0.5) * 6, 256, y + (r() - 0.5) * 4)
      x.stroke()
    }
    x.fillStyle = 'rgba(30,20,12,.5)'
    x.beginPath()
    x.ellipse(70 + r() * 110, 32, 7, 5, 0, 0, 7)
    x.fill()
    const t = new THREE.CanvasTexture(c)
    t.colorSpace = THREE.SRGBColorSpace
    t.wrapS = t.wrapT = THREE.RepeatWrapping
    return t
  }

  private buildDrawer(spot: Spot) {
    const out = spot.out ?? 0.03
    const root = new THREE.Group()
    const slider = new THREE.Group()
    const holder = new THREE.Group()
    root.add(slider)
    const front = spot.paint !== undefined
      ? this.std(`paint:${spot.paint}:${spot.metal ? 1 : 0}`, () => new THREE.MeshStandardMaterial({ color: spot.paint, roughness: spot.metal ? 0.36 : 0.5, metalness: spot.metal ? 0.4 : 0, envMapIntensity: 0.4 }))
      : this.std(`grain:${spot.grain}`, () => new THREE.MeshStandardMaterial({ map: this.wood, bumpMap: this.wood, bumpScale: 0.018, color: spot.grain ?? 0x959595, roughness: 0.56, envMapIntensity: 0.35 }))
    const inner = this.std('inner', () => new THREE.MeshStandardMaterial({ map: this.wood, bumpMap: this.wood, bumpScale: 0.01, color: 0xd2b894, roughness: 0.86 }))
    const handleMat = spot.metal ? this.chrome : this.brass
    const add = (parent: THREE.Object3D, g: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) => {
      const mesh = new THREE.Mesh(g, m)
      mesh.position.set(x, y, z)
      mesh.rotation.set(rx, ry, rz)
      mesh.castShadow = false
      mesh.receiveShadow = true
      parent.add(mesh)
      return mesh
    }
    const half = Math.PI / 2

    // The opening in the furniture, seen as a thin black seam around the front.
    add(root, new THREE.BoxGeometry(spot.w + 0.01, spot.h + 0.01, 0.003), this.black, 0, 0, 0.0015)
    add(slider, new THREE.BoxGeometry(spot.w - 0.008, spot.h - 0.008, out), front, 0, 0, out / 2)

    switch (spot.style) {
      case 'bar': {
        for (const s of [-1, 1]) add(slider, new THREE.CylinderGeometry(0.0055, 0.0055, 0.026, 10), handleMat, s * spot.w * 0.17, 0, out + 0.013, half)
        add(slider, new THREE.CylinderGeometry(0.0048, 0.0048, spot.w * 0.34 + 0.012, 10), handleMat, 0, 0, out + 0.027, 0, 0, half)
        break
      }
      case 'knob': {
        add(slider, new THREE.CylinderGeometry(0.006, 0.006, 0.02, 10), handleMat, 0, 0, out + 0.01, half)
        const knob = add(slider, new THREE.SphereGeometry(0.0155, 14, 10), handleMat, 0, 0, out + 0.03)
        knob.scale.z = 0.9
        break
      }
      case 'cup': {
        add(slider, new THREE.BoxGeometry(0.1, 0.026, 0.004), handleMat, 0, spot.h * 0.28, out + 0.002)
        add(slider, new THREE.BoxGeometry(0.1, 0.008, 0.02), handleMat, 0, spot.h * 0.28 - 0.009, out + 0.012)
        break
      }
      case 'slot': {
        add(slider, new THREE.BoxGeometry(spot.w * 0.5, 0.014, 0.004), this.black, 0, spot.h * 0.38, out + 0.001)
        break
      }
    }

    // A lock is a brass plate and a dark keyhole. It stays where it is, whether it is locked or not.
    if (spot.locked) {
      add(slider, new THREE.BoxGeometry(0.028, 0.044, 0.004), this.brass, -spot.w * 0.33, 0, out + 0.002)
      add(slider, new THREE.CylinderGeometry(0.0055, 0.0055, 0.003, 12), this.black, -spot.w * 0.33, 0.007, out + 0.0045, half)
      add(slider, new THREE.BoxGeometry(0.0034, 0.015, 0.003), this.black, -spot.w * 0.33, -0.004, out + 0.0045)
    }

    // The drawer box.
    const iw = spot.w - 0.05
    const ih = spot.h * 0.86
    add(slider, new THREE.BoxGeometry(iw, 0.012, spot.depth), inner, 0, -ih / 2 + 0.006, -spot.depth / 2)
    for (const s of [-1, 1]) add(slider, new THREE.BoxGeometry(0.012, ih, spot.depth), inner, s * iw / 2, 0, -spot.depth / 2)
    add(slider, new THREE.BoxGeometry(iw, ih, 0.012), inner, 0, 0, -spot.depth)
    // Runners fixed to the furniture, visible once the drawer is pulled out.
    for (const s of [-1, 1]) add(root, new THREE.BoxGeometry(0.005, 0.012, spot.depth * 0.92), this.chrome, s * (iw / 2 + 0.0085), -ih * 0.2, -spot.depth * 0.46)

    holder.position.set(0, -ih / 2 + 0.012, -spot.depth * 0.42)
    slider.add(holder)

    // Whatever else lives in a drawer. The same junk, in the same places, every night.
    const rand = seeded(spot.id)
    const count = 3 + Math.floor(rand() * 3)
    for (let i = 0; i < count; i++) {
      const kind = CLUTTER_KINDS[Math.floor(rand() * CLUTTER_KINDS.length)]
      const object = buildClutter(kind)
      let x = (rand() * 2 - 1) * (iw / 2 - 0.045)
      const z = -0.05 - rand() * (spot.depth - 0.1)
      if (Math.abs(x) < 0.1 && Math.abs(z + spot.depth * 0.42) < 0.11) x = (x < 0 ? -1 : 1) * (0.1 + rand() * 0.05)
      object.position.set(x, -ih / 2 + 0.012, z)
      object.rotation.y = rand() * Math.PI * 2
      slider.add(object)
    }

    root.position.set(...spot.at)
    root.rotation.y = spot.axis === 'x' ? spot.dir * (Math.PI / 2) : spot.dir === 1 ? 0 : Math.PI
    this.group.add(root)
    const normal = spot.axis === 'x' ? new THREE.Vector3(spot.dir, 0, 0) : new THREE.Vector3(0, 0, spot.dir)
    const position = new THREE.Vector3(...spot.at).addScaledVector(normal, 0.06)
    this.drawers.set(spot.id, {
      spot, root, slider, holder, item: null, open: 0, vel: 0, target: 0, shake: 0, tried: 0,
      travel: Math.min(0.34, spot.depth * 0.85), unlocked: !spot.locked,
    })
    this.target(`drawer:${spot.id}`, spot.label, position)
  }

  private buildPlanks() {
    const texture = this.woodTexture()
    const mat = new THREE.MeshStandardMaterial({ map: texture, bumpMap: texture, bumpScale: 0.02, roughness: 0.9, color: 0xc9b7a0 })
    const nail = new THREE.MeshStandardMaterial({ color: 0x777b80, metalness: 0.9, roughness: 0.4 })
    ;[0.85, 1.45].forEach((y, i) => {
      const plank = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.15, 0.04), mat)
      plank.position.set(8.7, y, PLANK_Z)
      plank.rotation.z = i === 0 ? 0.045 : -0.035
      plank.castShadow = false
      plank.receiveShadow = true
      for (const sx of [-0.62, -0.5, 0.5, 0.62]) {
        const n = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 0.02, 8), nail)
        n.rotation.x = Math.PI / 2
        n.position.set(sx, (sx > 0 ? 1 : -1) * 0.012, -0.028)
        plank.add(n)
      }
      this.group.add(plank)
      this.plankMeshes[i] = plank
      this.target(`plank:${i}`, 'Planches clouées', new THREE.Vector3(8.7, y, PLANK_Z - 0.04))
    })
  }

  private buildKeypad() {
    const g = new THREE.Group()
    const body = new THREE.MeshStandardMaterial({ color: 0x1b1d20, roughness: 0.5, metalness: 0.5 })
    const key = new THREE.MeshStandardMaterial({ color: 0x5c6167, roughness: 0.45, metalness: 0.4 })
    const screen = new THREE.MeshStandardMaterial({ color: 0x0c1a10, emissive: 0x3dff7a, emissiveIntensity: 0.9 })
    const add = (geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number) => {
      const mesh = new THREE.Mesh(geo, m)
      mesh.position.set(x, y, z)
      mesh.castShadow = false
      g.add(mesh)
      return mesh
    }
    add(new THREE.BoxGeometry(0.16, 0.25, 0.035), body, 0, 0, 0)
    add(new THREE.BoxGeometry(0.11, 0.04, 0.004), screen, 0, 0.08, -0.019)
    for (let r = 0; r < 4; r++) for (let c = 0; c < 3; c++) add(new THREE.BoxGeometry(0.03, 0.022, 0.006), key, (c - 1) * 0.036, 0.02 - r * 0.03, -0.019)
    add(new THREE.SphereGeometry(0.006, 8, 8), this.ledMaterial, 0.055, 0.112, -0.02)
    g.position.set(9.55, 1.25, 8.857)
    g.rotation.y = Math.PI
    this.group.add(g)
    this.target('keypad', 'Digicode', new THREE.Vector3(9.55, 1.25, 8.8))
  }

  private buildLock() {
    const plate = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.17, 0.018), this.brass)
    plate.position.set(8.3, 1.3, 8.864)
    plate.castShadow = false
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.03, 18), new THREE.MeshStandardMaterial({ color: 0x8c9096, roughness: 0.25, metalness: 0.95 }))
    cyl.rotation.x = Math.PI / 2
    cyl.position.set(8.3, 1.3, 8.85)
    const slot = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.016, 0.004), this.black)
    slot.position.set(8.3, 1.3, 8.834)
    this.group.add(plate, cyl, slot)
    this.target('lock', 'Verrou à clé', new THREE.Vector3(8.3, 1.3, 8.8))
    this.target('exit', 'Sortir de la maison', new THREE.Vector3(8.75, 1.05, 8.8))
  }

  private buildCabinet() {
    const steel = new THREE.MeshStandardMaterial({ color: 0x2a3630, roughness: 0.5, metalness: 0.65 })
    const dark = new THREE.MeshStandardMaterial({ color: 0x101312, roughness: 0.7 })
    const y0 = -3
    const add = (parent: THREE.Object3D, geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number) => {
      const mesh = new THREE.Mesh(geo, m)
      mesh.position.set(x, y, z)
      mesh.castShadow = false
      mesh.receiveShadow = true
      parent.add(mesh)
      return mesh
    }
    add(this.group, new THREE.BoxGeometry(0.02, 1.9, 1.0), steel, 8.865, y0 + 0.95, 2.8)
    add(this.group, new THREE.BoxGeometry(0.4, 1.9, 0.02), steel, 8.675, y0 + 0.95, 2.31)
    add(this.group, new THREE.BoxGeometry(0.4, 1.9, 0.02), steel, 8.675, y0 + 0.95, 3.29)
    add(this.group, new THREE.BoxGeometry(0.4, 0.02, 1.0), steel, 8.675, y0 + 1.9, 2.8)
    add(this.group, new THREE.BoxGeometry(0.4, 0.02, 1.0), steel, 8.675, y0 + 0.01, 2.8)
    add(this.group, new THREE.BoxGeometry(0.38, 0.02, 0.96), steel, 8.68, y0 + 1.0, 2.8)
    add(this.group, new THREE.BoxGeometry(0.01, 1.84, 0.96), dark, 8.855, y0 + 0.95, 2.8)
    this.cabDoor.position.set(8.468, y0 + 0.95, 2.31)
    add(this.cabDoor, new THREE.BoxGeometry(0.025, 1.88, 0.98), steel, 0, 0, 0.49)
    add(this.cabDoor, new THREE.BoxGeometry(0.012, 1.6, 0.8), new THREE.MeshStandardMaterial({ color: 0x35433b, roughness: 0.55, metalness: 0.55 }), -0.016, 0, 0.49)
    add(this.cabDoor, new THREE.BoxGeometry(0.018, 0.1, 0.05), this.brass, -0.02, -0.05, 0.88)
    add(this.cabDoor, new THREE.CylinderGeometry(0.01, 0.01, 0.012, 12), this.brass, -0.022, 0.06, 0.88).rotation.z = Math.PI / 2
    this.group.add(this.cabDoor)
    const pistol = buildPistol()
    pistol.rotation.set(0, Math.PI / 2, Math.PI / 2)
    pistol.position.set(8.72, y0 + 1.04, 2.62)
    this.cabContents.add(pistol)
    for (let i = 0; i < 3; i++) {
      const bullet = buildCartridge()
      bullet.rotation.y = Math.PI / 2
      bullet.position.set(8.7, y0 + 1.016, 3.0 + i * 0.045)
      this.cabContents.add(bullet)
    }
    this.group.add(this.cabContents)
    this.target('cabinet', 'Armoire à armes', new THREE.Vector3(8.42, y0 + 1.0, 2.8))
  }

  /* ------------------------------------------------------------ state */

  /** Hides the items following the chain, and closes everything. */
  reset(rand: () => number) {
    this.inv.clear()
    this.planks = [false, false]
    this.keypadOk = false
    this.lockOpen = false
    this.cabinetOpen = false
    this.gunTaken = false
    this.bullets = 0
    this.discovered = false
    this.idle = 0
    this.lastSig = ''
    this.code = String(1000 + Math.floor(rand() * 9000))
    this.falling.forEach((f) => f.mesh.removeFromParent())
    this.falling = []
    this.pickups.forEach((p) => p.obj.removeFromParent())
    this.pickups = []
    this.plankMeshes.forEach((m, i) => { if (m) { m.visible = true; m.position.y = i === 0 ? 0.85 : 1.45; m.rotation.set(0, 0, i === 0 ? 0.045 : -0.035) } })
    this.cabOpenAmount = 0
    this.cabDoor.rotation.y = 0
    this.cabContents.visible = true
    this.placement = {}
    const place = (item: ItemId) => {
      const pool = POOLS[item]
      const free = pool.filter((id) => !this.placement[id])
      const list = free.length ? free : pool
      this.placement[list[Math.floor(rand() * list.length)]] = item
    }
    ;(['drawerKey', 'hammer', 'note', 'doorKey', 'gunKey'] as ItemId[]).forEach(place)
    this.drawers.forEach((d) => { d.open = 0; d.vel = 0; d.target = 0; d.shake = 0; d.tried = 0; d.unlocked = !d.spot.locked; this.mountItem(d) })
    this.applyVisuals()
  }

  private mountItem(d: Drawer) {
    if (d.item) { d.item.removeFromParent(); d.item = null }
    const id = this.placement[d.spot.id]
    if (!id) return
    const model = id === 'hammer' ? buildHammer() : id === 'doorKey' ? buildKey('door') : id === 'gunKey' ? buildKey('gun') : id === 'drawerKey' ? buildKey('drawer') : buildNote()
    model.rotation.y = 0.35
    model.position.y = id === 'hammer' ? 0.0158 : id === 'note' ? 0.002 : 0.0045
    if (id === 'hammer') model.scale.setScalar(Math.min(1, d.spot.w / 0.38))
    d.holder.add(model)
    d.item = model
  }

  private applyVisuals() {
    this.ledMaterial.emissive.setHex(this.keypadOk ? 0x30ff6a : 0xff2a1a)
    this.cabContents.visible = !this.gunTaken
    this.plankMeshes.forEach((m, i) => { if (m && this.planks[i]) m.visible = false })
  }

  get hasGun() { return this.gunTaken }
  get hasNote() { return this.inv.has('note') }
  get canExit() { return this.planks[0] && this.planks[1] && this.keypadOk && this.lockOpen }
  get planksLeft() { return Number(!this.planks[0]) + Number(!this.planks[1]) }

  inventory() {
    return (Object.keys(ITEM_LABEL) as ItemId[]).filter((i) => this.inv.has(i)).map((id) => ({ id, label: ITEM_LABEL[id] }))
  }

  private spotOf(item: ItemId) {
    return Object.keys(this.placement).find((id) => this.placement[id] === item)
  }

  /** The next thing the player still has to get, in the order the chain asks for it. */
  private nextNeed(): ItemId | null {
    if (this.planksLeft && !this.inv.has('hammer')) return 'hammer'
    if (!this.lockOpen && !this.inv.has('doorKey')) return 'doorKey'
    if (!this.keypadOk && !this.inv.has('note')) return 'note'
    return null
  }

  /** Where to look, in words: never the exact drawer, never nothing. */
  hint() {
    const need = this.nextNeed()
    if (!need) return null
    const spot = this.spotOf(need)
    const d = spot ? this.drawers.get(spot) : null
    if (!spot || !d) return null
    if (!d.unlocked && !this.inv.has('drawerKey')) {
      const key = this.spotOf('drawerKey')
      const room = key ? this.drawers.get(key)?.spot.room : null
      return room ? `une clé de meuble traîne dans ${room}` : 'il faut une clé de meuble'
    }
    return `cherchez dans ${d.spot.room}`
  }

  /** The line shown as an objective once the player has started looking at the door. */
  objective() {
    if (!this.discovered) return null
    if (this.canExit) return 'La porte est libre. Sortez.'
    const missing: string[] = []
    if (this.planksLeft) missing.push(`planches ${2 - this.planksLeft}/2`)
    if (!this.lockOpen) missing.push('verrou')
    if (!this.keypadOk) missing.push('code')
    const base = `Porte d'entrée : ${missing.join(' · ')}`
    const hint = this.idle > HINT_AFTER ? this.hint() : null
    return hint ? `${base} — piste : ${hint}` : base
  }

  fire() {
    if (!this.gunTaken || this.bullets <= 0) return false
    this.bullets--
    return true
  }

  checkCode(value: string) {
    if (value !== this.code) return false
    this.keypadOk = true
    this.applyVisuals()
    return true
  }

  /* ------------------------------------------------------------ interactions */

  use(t: InteractionTarget): UseResult {
    this.discovered = this.discovered || !t.escapeId?.startsWith('drawer:')
    const id = t.escapeId ?? ''
    if (id.startsWith('drawer:')) return this.useDrawer(id.slice(7))
    switch (id) {
      case 'plank:0':
      case 'plank:1': {
        const i = Number(id.slice(6))
        if (this.planks[i]) return {}
        if (!this.inv.has('hammer')) return { msg: 'Des planches clouées en travers de la porte. Il faudrait un outil pour les arracher.', sound: 'thud' }
        return { hold: true, sound: 'scrape' }
      }
      case 'lock': {
        if (this.lockOpen) return { msg: 'Le verrou est ouvert.' }
        if (!this.inv.has('doorKey')) return { msg: "Un verrou à clé. Il faut la clé de la porte d'entrée.", sound: 'lockrattle' }
        this.lockOpen = true
        this.inv.delete('doorKey')
        return { msg: 'La clé tourne. Le verrou est ouvert.', sound: 'key', log: "Verrou de la porte d'entrée ouvert." }
      }
      case 'keypad':
        if (this.keypadOk) return { msg: 'Le digicode est déverrouillé.' }
        return { panel: 'keypad', sound: 'beep' }
      case 'exit': {
        if (!this.canExit) {
          const missing: string[] = []
          if (this.planksLeft) missing.push(this.planksLeft > 1 ? 'les planches' : 'une planche')
          if (!this.lockOpen) missing.push('le verrou à clé')
          if (!this.keypadOk) missing.push('le digicode')
          return { msg: `La porte tient encore : il reste ${missing.join(', ')}.`, sound: 'thud', long: true }
        }
        return { exit: true, sound: 'door' }
      }
      case 'cabinet': {
        if (!this.cabinetOpen) {
          if (!this.inv.has('gunKey')) return { msg: 'Armoire à armes. Elle est verrouillée : il faut sa clé.', sound: 'lockrattle' }
          this.cabinetOpen = true
          this.inv.delete('gunKey')
          return { msg: "L'armoire s'ouvre.", sound: 'key' }
        }
        if (!this.gunTaken) {
          this.gunTaken = true
          this.bullets = 3
          this.applyVisuals()
          return {
            msg: 'Un pistolet et trois cartouches, pas une de plus. Clic gauche (ou G) pour tirer.',
            long: true,
            sound: 'click',
            log: 'Pistolet récupéré : 3 cartouches, non rechargeables.',
          }
        }
        return { msg: "L'armoire est vide." }
      }
    }
    return {}
  }

  private useDrawer(id: string): UseResult {
    const d = this.drawers.get(id)
    if (!d) return {}
    if (!d.unlocked) {
      if (!this.inv.has('drawerKey')) {
        d.shake = 1
        d.tried++
        return {
          msg: d.tried === 1 ? 'Verrouillé. Une petite serrure : il doit exister une clé de meuble quelque part dans la maison.' : 'Toujours verrouillé.',
          long: d.tried === 1,
          sound: 'lockrattle',
        }
      }
      d.unlocked = true
      d.target = 1
      return { msg: this.placement[id] ? undefined : 'Le tiroir s’ouvre. Rien que de la bricole dedans.', sound: 'key', also: 'drawer' }
    }
    if (d.target === 0) {
      d.target = 1
      return { msg: this.placement[id] ? undefined : 'Rien d’utile ici.', sound: 'drawer', also: 'rattle' }
    }
    const item = this.placement[id]
    if (!item) {
      d.target = 0
      return { sound: 'drawer' }
    }
    this.placement[id] = null
    this.inv.add(item)
    if (d.item) this.startPickup(d.item)
    d.item = null
    const texts: Record<ItemId, string> = {
      hammer: 'Un marteau, un peu rouillé. De quoi arracher des planches.',
      doorKey: "Une clé en laiton, étiquette rouge : « PORTE ». Elle va au verrou de l'entrée.",
      gunKey: 'Une clé grise, étiquette noire : « ARMES ». Elle va à l’armoire du sous-sol.',
      drawerKey: this.drawerKeyText(),
      note: 'Un papier plié : un code est écrit dessus.',
    }
    return {
      msg: texts[item],
      long: item !== 'note',
      sound: item === 'note' ? 'paper' : 'key',
      panel: item === 'note' ? 'note' : undefined,
      log: item === 'note' ? `Papier trouvé. Code : ${this.code}` : `Trouvé : ${ITEM_LABEL[item]}.`,
    }
  }

  private drawerKeyText() {
    const locked = [...this.drawers.values()].filter((d) => !d.unlocked).map((d) => d.spot.label)
    return locked.length ? `Une petite clé de meuble. Elle ouvre ce qui est fermé : ${locked.join(' ; ')}.` : 'Une petite clé de meuble.'
  }

  /** The object leaves the drawer and rises toward the eyes, turning, before it goes into the pocket. */
  private startPickup(obj: THREE.Group) {
    const position = new THREE.Vector3()
    const q = new THREE.Quaternion()
    obj.getWorldPosition(position)
    obj.getWorldQuaternion(q)
    const scale = obj.scale.x
    obj.removeFromParent()
    this.group.add(obj)
    obj.position.copy(position)
    obj.quaternion.copy(q)
    this.pickups.push({ obj, from: position.clone(), q, scale, t: 0 })
  }

  /** A held action finished: a plank comes off the door. */
  complete(id: string): UseResult {
    if (id !== 'plank:0' && id !== 'plank:1') return {}
    const i = Number(id.slice(6))
    if (this.planks[i]) return {}
    this.planks[i] = true
    const mesh = this.plankMeshes[i]
    if (mesh) this.falling.push({ mesh, vy: 0.4, spin: (i ? 1 : -1) * (1.2 + Math.random()), vx: (Math.random() - 0.5) * 0.7, time: 0 })
    const left = this.planksLeft
    return {
      msg: left ? 'Une planche cède dans un craquement. Il en reste une.' : 'La dernière planche cède. La porte est dégagée.',
      sound: 'wood',
      log: left ? 'Une planche arrachée.' : 'Les deux planches sont arrachées.',
    }
  }

  /* ------------------------------------------------------------ frame update */

  tick(dt: number, camera?: THREE.Camera) {
    this.drawers.forEach((d) => {
      // A spring with a little overshoot: the drawer slides, hits its stop, and settles.
      d.vel += ((d.target - d.open) * 150 - d.vel * 17) * dt
      d.open = THREE.MathUtils.clamp(d.open + d.vel * dt, -0.02, 1.07)
      d.slider.position.z = d.open * d.travel
      d.shake = Math.max(0, d.shake - dt * 1.5)
      d.slider.position.x = d.shake > 0 ? Math.sin(performance.now() / 11) * 0.004 * d.shake : 0
    })
    this.cabOpenAmount += ((this.cabinetOpen ? 1 : 0) - this.cabOpenAmount) * Math.min(1, dt * 4)
    this.cabDoor.rotation.y = -this.cabOpenAmount * Math.PI * 0.52
    for (let i = this.falling.length - 1; i >= 0; i--) {
      const f = this.falling[i]
      f.time += dt
      f.vy -= 9.8 * dt
      f.mesh.position.y += f.vy * dt
      f.mesh.position.x += f.vx * dt
      f.mesh.position.z -= dt * 0.4
      f.mesh.rotation.z += f.spin * dt
      if (f.mesh.position.y < 0.05 || f.time > 1.6) {
        f.mesh.visible = false
        this.falling.splice(i, 1)
      }
    }
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i]
      p.t += dt
      const k = Math.min(1, p.t / 0.55)
      const e = k * k * (3 - 2 * k)
      if (camera) {
        camera.getWorldDirection(this._f)
        this._v.copy(camera.position).addScaledVector(this._f, 0.46).addScaledVector(this._u, -0.07)
        p.obj.position.lerpVectors(p.from, this._v, e)
      }
      this._q.setFromAxisAngle(this._u, p.t * 2.6)
      p.obj.quaternion.copy(p.q).premultiply(this._q)
      const fade = p.t < 0.75 ? 1 : Math.max(0, 1 - (p.t - 0.75) / 0.3)
      p.obj.scale.setScalar(Math.max(0.001, p.scale * (0.9 + e * 0.5) * fade))
      if (p.t > 1.05) {
        p.obj.removeFromParent()
        this.pickups.splice(i, 1)
      }
    }
    this.ledMaterial.emissiveIntensity = this.keypadOk ? 1.4 : 1.1 + Math.sin(performance.now() / 420) * 0.5

    // Time without any progress: after a while, the game says where to look.
    const sig = `${[...this.inv].sort().join()}|${this.planks.join()}|${this.keypadOk}|${this.lockOpen}|${this.cabinetOpen}|${this.gunTaken}|${[...this.drawers.values()].filter((d) => d.unlocked && d.spot.locked).length}`
    if (sig !== this.lastSig) { this.lastSig = sig; this.idle = 0 }
    else if (this.discovered && !this.canExit) this.idle += dt

    const label = (id: string, text: string, hold?: number, disabled = false) => {
      const t = this.byId.get(id)
      if (!t) return
      t.label = text
      t.hold = hold
      t.disabled = disabled
    }
    for (let i = 0; i < 2; i++) label(`plank:${i}`, this.inv.has('hammer') ? 'Arracher les planches' : 'Planches clouées', this.inv.has('hammer') ? 1.7 : undefined, this.planks[i])
    label('lock', this.lockOpen ? 'Verrou ouvert' : this.inv.has('doorKey') ? 'Déverrouiller la porte' : 'Verrou à clé', undefined, this.lockOpen)
    label('keypad', this.keypadOk ? 'Digicode déverrouillé' : 'Digicode')
    label('exit', this.canExit ? 'Sortir de la maison' : 'Porte condamnée', undefined, this.planksLeft > 0)
    label('cabinet', !this.cabinetOpen ? 'Armoire à armes' : this.gunTaken ? 'Armoire à armes (vide)' : 'Prendre le pistolet et les cartouches')
    this.drawers.forEach((d, id) => {
      const t = this.byId.get(`drawer:${id}`)
      if (!t) return
      const item = this.placement[id]
      t.label = !d.unlocked ? `${d.spot.label} (verrouillé)` : d.target === 0 ? `Ouvrir le ${d.spot.label}` : item ? 'Prendre ce qu’il y a dedans' : 'Refermer le tiroir'
    })
  }

  /* ------------------------------------------------------------ persistence */

  save(): EscapeSave {
    return {
      placement: { ...this.placement },
      opened: [...this.drawers.entries()].filter(([, d]) => d.target > 0).map(([id]) => id),
      unlocked: [...this.drawers.entries()].filter(([, d]) => d.unlocked && d.spot.locked).map(([id]) => id),
      inv: [...this.inv],
      code: this.code,
      planks: [...this.planks] as [boolean, boolean],
      keypad: this.keypadOk,
      lock: this.lockOpen,
      cabinet: this.cabinetOpen,
      gun: this.gunTaken,
      bullets: this.bullets,
      discovered: this.discovered,
    }
  }

  restore(data: EscapeSave) {
    this.placement = { ...data.placement }
    this.inv = new Set(data.inv)
    this.code = data.code
    this.planks = [!!data.planks?.[0], !!data.planks?.[1]]
    this.keypadOk = !!data.keypad
    this.lockOpen = !!data.lock
    this.cabinetOpen = !!data.cabinet
    this.gunTaken = !!data.gun
    this.bullets = Math.max(0, Math.min(3, data.bullets ?? 0))
    this.discovered = !!data.discovered
    this.idle = 0
    this.lastSig = ''
    this.cabOpenAmount = this.cabinetOpen ? 1 : 0
    this.drawers.forEach((d, id) => {
      d.unlocked = !d.spot.locked || data.unlocked.includes(id)
      d.target = data.opened.includes(id) ? 1 : 0
      d.open = d.target
      d.vel = 0
      this.mountItem(d)
    })
    this.plankMeshes.forEach((m, i) => { if (m) m.visible = !this.planks[i] })
    this.applyVisuals()
  }
}
