import * as THREE from 'three'
import type { HouseSystem } from './house'
import { NightSystem } from './night'
import { PlayerSystem } from './player'

export interface HouseCheck { name: string; passed: boolean; detail: string }

// Runs against the constructed house, never a replacement test map.
export function checkHouse(house: HouseSystem): HouseCheck[] {
  const results: HouseCheck[] = []
  const record = (name: string, passed: boolean, detail: string) => results.push({ name, passed, detail })
  const start = new THREE.Vector3(8.7, 0, 7.8)
  record('Interior spawn', !house.blocked(start.x, start.y, start.z, 0.2), 'The starting position must not overlap a wall or furnishing.')
  record('Original staircases', house.world.surfaces.filter((s) => !!s.fn).length === 2, 'Both original ramp functions are retained.')
  const destinations = [
    { name: 'Upper floor route', p: new THREE.Vector3(8, 3, 2.7) },
    { name: 'Basement route', p: new THREE.Vector3(5.5, -3, 4.2) },
    { name: 'Laundry route', p: new THREE.Vector3(7.2, 0, 1.5) },
    { name: 'Breaker route', p: new THREE.Vector3(7.7, -3, 7.4) },
  ]
  for (const destination of destinations) {
    const path = house.path(start, destination.p)
    const continuous = path.length > 0 && path.every((p, i) => i === 0 || p.distanceTo(path[i - 1]) < 0.5)
    record(destination.name, continuous, `${path.length} contiguous navigation nodes; closed doors are traversable only after opening.`)
  }
  record('Solid partition occludes sight', !house.visible(new THREE.Vector3(9.5, 1.5, 5.4), new THREE.Vector3(10.7, 1.5, 5.4)), 'Existing partition between hall and living room.')
  record('Open arch preserves sight', house.visible(new THREE.Vector3(9.5, 1.5, 7.4), new THREE.Vector3(10.7, 1.5, 7.4)), 'Existing living-room arch, not a wall-crossing shortcut.')
  record('Closed door occludes sight', !house.visible(new THREE.Vector3(5.5, 1.1, 3.5), new THREE.Vector3(6.5, 1.1, 3.5)), 'Existing garage interior door.')
  const unchanged = house.world.objects.every((o) => {
    const actual = new THREE.Box3().setFromObject(o.group)
    return actual.min.distanceTo(o.bounds.min) < 0.0001 && actual.max.distanceTo(o.bounds.max) < 0.0001
  })
  record('Furniture baseline preserved', unchanged, `${house.world.objects.length} indexed objects retain their original world bounds.`)
  const night = new NightSystem()
  night.reset(12)
  const atStart = night.time === '22:00'
  night.tick(180)
  const midnight = night.time === '00:00'
  night.tick(540)
  record('Full-night clock and victory', atStart && midnight && night.time === '06:00' && night.status === 'survived', '22:00 to 06:00 with a real terminal win state.')
  const player = new PlayerSystem(house)
  player.keys.add('KeyW'); player.keys.add('ShiftLeft')
  for (let i = 0; i < 301; i++) player.tick(1 / 60, false, () => {}, false)
  const limited = player.stamina < 1
  player.clear()
  for (let i = 0; i < 660; i++) player.tick(1 / 60, true, () => {}, false)
  record('Finite sprint and recovery', limited && player.stamina > 99, 'Roughly five seconds of sprint and ten seconds of recovery.')
  return results
}