import * as THREE from 'three'
import type { HouseRoom, HouseSystem } from './house'
import type { PlayerSystem } from './player'
import { ENTITY_START, type NightSystem } from './night'
import type { AnomalySystem } from './anomalies'
import type { EntitySystem } from './entity'
import type { LightingSystem } from './lighting'
import type { HouseAudio, SoundKind } from './audio'
import { DREAD_STATES, dreadFor, type Atmosphere, type DreadState } from './atmosphere'

// Higher dread means shorter gaps between events. Calm stretches still happen:
// the pace never stays at one level for long because the tension wave moves.
const PACING: Record<DreadState, number> = { 'CALME': 1.35, 'INQUIÉTUDE': 1, 'TENSION': 0.78, 'PRÉSENCE': 0.62, 'DANGER': 0.5, 'CLIMAX': 0.4 }

export class EventDirector {
  tension = 0.08
  private eventTimer = 24
  private ambientTimer = 10
  private rest = 0
  private camping = 0
  private previousRoom = ''
  private tripped = false
  private time = 0
  private stillSound = 0
  private knockTimer = 240
  private musicTimer = 170

  constructor(
    private house: HouseSystem,
    private player: PlayerSystem,
    private night: NightSystem,
    private anomalies: AnomalySystem,
    private entity: EntitySystem,
    private lights: LightingSystem,
    private audio: HouseAudio,
    private atmosphere: Atmosphere,
  ) {}

  reset() {
    this.tension = 0.08
    this.eventTimer = 24
    this.ambientTimer = 10
    this.rest = 0
    this.camping = 0
    this.previousRoom = ''
    this.tripped = false
    this.time = 0
    this.stillSound = 0
    this.knockTimer = 240
    this.musicTimer = 170
  }

  get dread(): DreadState {
    return dreadFor(this.tension * 0.55 + this.atmosphere.stress * 0.45)
  }

  report(accepted: boolean) {
    this.tension = THREE.MathUtils.clamp(this.tension + (accepted ? -0.15 : 0.05), 0.04, 0.96)
    if (accepted) this.rest = 10 + this.night.random() * 14
  }

  private randomPoint(room: HouseRoom, height = 0.9) {
    const area = room.areas[Math.floor(this.night.random() * room.areas.length)]
    return new THREE.Vector3(
      area.x1 + 0.5 + this.night.random() * Math.max(0.1, area.x2 - area.x1 - 1),
      room.level * 3 + height,
      area.z1 + 0.5 + this.night.random() * Math.max(0.1, area.z2 - area.z1 - 1),
    )
  }

  /** Sounds that belong to the house itself: pipes, wood, the fridge, distant doors. */
  private houseSound(room: HouseRoom | undefined, level: number) {
    const nearby = this.house.rooms.filter((r) => r.center.distanceTo(this.player.position) < 13)
    const source = nearby.length ? nearby[Math.floor(this.night.random() * nearby.length)] : room
    if (!source) return
    const roll = this.night.random()
    let kind: SoundKind
    if (/Buanderie|WC|Salle de bain|Local technique/.test(source.name)) kind = roll < 0.6 ? 'drip' : 'pipe'
    else if (/Cuisine|Garage|Sous-sol/.test(source.name)) kind = roll < 0.5 ? 'hum' : roll < 0.8 ? 'creak' : 'scrape'
    else kind = roll < 0.6 ? 'creak' : roll < 0.85 ? 'scrape' : 'thud'
    if (level >= 4 && roll > 0.82) kind = 'knock'
    this.audio.play(kind, this.randomPoint(source), 0.22 + level * 0.05)
  }

  tick(dt: number, cameraMode: boolean, observed: (point: THREE.Vector3) => boolean, reducedEffects: boolean, intensity: number) {
    this.time += dt
    const room = this.house.roomAt(this.player.position)
    this.camping = room?.id === this.previousRoom ? this.camping + dt : 0
    this.previousRoom = room?.id ?? ''
    this.rest = Math.max(0, this.rest - dt)
    this.stillSound = Math.max(0, this.stillSound - dt)

    const open = this.anomalies.active.filter((a) => !a.acknowledged).length
    const dark = !(this.lights.isOn(room?.id) || this.player.flashlight)
    const wave = Math.sin(this.time / 52) * 0.07 + Math.sin(this.time / 131 + 2.1) * 0.05
    const raw = 0.1 + this.night.progress * 0.5 + open * 0.06 + (dark ? 0.1 : 0) + (cameraMode ? 0.06 : 0)
      + Math.min(0.16, this.camping / 500) + Math.min(0.16, this.anomalies.missed * 0.025)
      + this.lights.corruption * 0.12 + wave
    this.tension = THREE.MathUtils.damp(this.tension, THREE.MathUtils.clamp(raw * intensity, 0.04, 0.96), 0.045, dt)
    const state = this.dread
    const level = DREAD_STATES.indexOf(state)
    const pace = PACING[state]

    this.ambientTimer -= dt
    if (this.ambientTimer <= 0) {
      this.ambientTimer = (9 + this.night.random() * 15) * pace
      this.houseSound(room, level)
    }

    // Someone who stays still for a while hears the house answer.
    if (!cameraMode && this.camping > 40 && this.stillSound <= 0) {
      this.stillSound = 22 + this.night.random() * 26
      const far = this.house.rooms.filter((r) => room && r.id !== room.id && r.center.distanceTo(this.player.position) > 6)
      const target = far[Math.floor(this.night.random() * far.length)]
      if (target) this.audio.play(this.night.random() < 0.5 ? 'door' : 'step', this.randomPoint(target, 0.1), 0.34 + intensity * 0.06)
    }

    // Late night: someone knocks at the front door, outside, through the walls.
    if (this.night.phase >= 5) {
      this.knockTimer -= dt
      if (this.knockTimer <= 0) {
        this.knockTimer = (170 + this.night.random() * 150) / intensity
        this.audio.play('knock', new THREE.Vector3(8.7, 1.1, 9.5), 0.5 + intensity * 0.08)
      }
    }

    // After 01:00, a music box plays somewhere far in the house, worn out and a little flat.
    if (this.night.progress >= ENTITY_START + 0.04) {
      this.musicTimer -= dt
      if (this.musicTimer <= 0) {
        this.musicTimer = (150 + this.night.random() * 170) / intensity
        const far = this.house.rooms.filter((r) => r.center.distanceTo(this.player.position) > 7)
        const target = far[Math.floor(this.night.random() * far.length)]
        if (target) this.audio.play('musicbox', this.randomPoint(target, 0.8), 0.42)
      }
    }

    // Lights in the room you are in can flicker as the tension rises.
    if (!reducedEffects && room && this.lights.isOn(room.id) && this.night.random() < dt * (0.02 + this.tension * 0.08)) {
      this.lights.flicker(room.id, 0.3 + this.night.random() * 0.5)
    }

    if (this.night.phase < 1) return
    this.eventTimer -= dt
    if (this.eventTimer <= 0 && this.rest === 0) {
      const success = this.anomalies.spawn(observed, this.player.position)
      this.eventTimer = (success ? 26 + this.night.random() * 40 - this.night.phase * 1.5 : 5) * pace
      if (this.night.phase >= 2 && this.night.random() < 0.3 + level * 0.1) {
        const head = this.entity.headPoint()
        if (!observed(head)) this.entity.disturb(this.camping > 65 ? this.player.position : undefined)
      }
      this.rest = this.night.random() < 0.24 ? 20 : 0
    }

    if (this.night.phase >= 4 && !this.tripped && this.night.random() < dt * 0.006 * (level >= 4 ? 2.5 : 1)) {
      this.tripped = true
      this.lights.power = false
      this.night.log('Le circuit d’éclairage a sauté. Réarmez le disjoncteur dans le local technique.', 'warning')
      this.audio.play('click', new THREE.Vector3(8.79, -1.5, 7.5), 0.65)
    }
  }

  save() { return { tension: this.tension, eventTimer: this.eventTimer, ambientTimer: this.ambientTimer, rest: this.rest, camping: this.camping, tripped: this.tripped } }
  restore(data: ReturnType<EventDirector['save']>) { Object.assign(this, data) }
}
