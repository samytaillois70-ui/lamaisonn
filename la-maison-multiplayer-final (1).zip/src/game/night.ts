/** The creature wakes at 01:00: three hours into the eight, so the first part of the night is for searching. */
export const ENTITY_START = 3 / 8

export type NightStatus = 'waiting' | 'active' | 'survived' | 'lost'
export interface JournalEntry { id: number; time: string; text: string; kind: 'note' | 'report' | 'warning' }
export interface NightSave {
  elapsed: number
  duration: number
  reports: number
  mistakes: number
  seed: number
  entries: JournalEntry[]
}

export const PHASES = [
  { name: 'Les habitudes', line: 'Apprenez le silence de cette maison. Chaque bruit a sa place.' },
  { name: 'Un détail de trop', line: 'Quelque chose a bougé. Ou alors c’est vous qui vous souvenez mal.' },
  { name: 'Après minuit', line: 'Un son venu d’en haut ne devrait pas exister à cette heure.' },
  { name: 'Les angles morts', line: 'Les caméras ne voient que ce qu’elles sont placées pour voir.' },
  { name: 'La maison écoute', line: 'Chaque pas est entendu. Chaque porte aussi.' },
  { name: 'Une présence', line: 'Éteignez. Attendez. Ne bougez pas trop vite.' },
  { name: 'Avant le silence', line: 'Une pièce éclairée ne vous protège pas de ce qui s’y trouve déjà.' },
  { name: 'La dernière heure', line: 'Tenez jusqu’à l’aube. Il n’y a rien à comprendre, seulement à survivre.' },
]

export class NightSystem {
  elapsed = 0
  duration = 1200
  reports = 0
  mistakes = 0
  status: NightStatus = 'waiting'
  entries: JournalEntry[] = []
  seed = (Date.now() >>> 0) || 317
  private entryId = 0
  private lastPhase = 0

  get progress() { return Math.min(1, this.elapsed / this.duration) }
  get phase() { return Math.min(7, Math.floor(this.progress * 8)) }
  get time() {
    const minutes = Math.floor(22 * 60 + this.progress * 480)
    return `${String(Math.floor(minutes / 60) % 24).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`
  }

  random() {
    this.seed = (Math.imul(1664525, this.seed) + 1013904223) >>> 0
    return this.seed / 4294967296
  }

  reset(minutes = 20) {
    this.elapsed = 0
    this.duration = minutes * 60
    this.reports = 0
    this.mistakes = 0
    this.status = 'active'
    this.entries = []
    this.entryId = 0
    this.lastPhase = 0
    this.seed = (Date.now() >>> 0) || 317
    this.log('La porte est verrouillée. La relève arrivera à 06:00. Faites une première ronde.')
    this.log('La lampe se recharge dans la buanderie. Le disjoncteur est dans le local technique, au sous-sol.')
  }

  tick(dt: number) {
    if (this.status !== 'active') return
    this.elapsed = Math.min(this.duration, this.elapsed + dt)
    if (this.phase !== this.lastPhase) {
      this.lastPhase = this.phase
      this.log(PHASES[this.phase].line)
    }
    if (this.elapsed >= this.duration) {
      this.status = 'survived'
      this.log('06:00. La maison est toujours là. Vous aussi.')
    }
  }

  log(text: string, kind: JournalEntry['kind'] = 'note') {
    this.entries.unshift({ id: ++this.entryId, time: this.time, text, kind })
    this.entries = this.entries.slice(0, 60)
  }

  save(): NightSave {
    return { elapsed: this.elapsed, duration: this.duration, reports: this.reports, mistakes: this.mistakes, seed: this.seed, entries: this.entries }
  }

  restore(data: NightSave) {
    this.elapsed = data.elapsed
    this.duration = data.duration
    this.reports = data.reports
    this.mistakes = data.mistakes
    this.seed = data.seed
    this.entries = data.entries
    this.entryId = Math.max(0, ...data.entries.map((e) => e.id))
    this.lastPhase = this.phase
    this.status = 'active'
  }
}