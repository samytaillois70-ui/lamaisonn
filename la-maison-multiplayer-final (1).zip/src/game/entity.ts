import * as THREE from 'three'
import type { HouseSystem } from './house'
import type { PlayerSystem } from './player'
import type { LightingSystem } from './lighting'
import type { DoorSystem } from './doors'
import type { HouseAudio } from './audio'
import { ENTITY_START, type NightSystem } from './night'

type Behavior = 'dormant' | 'roam' | 'watch' | 'search' | 'retreat' | 'hunt' | 'stalk' | 'stare' | 'devour'

export type EntityEvent =
  | { type: 'encounter'; strikes: number; viaCamera: boolean; room: string }
  | { type: 'chaseStart' }
  | { type: 'chaseEnd' }

export interface SightContext {
  /** The player is looking through a camera, not with their own eyes. */
  camera: boolean
  /** Position of the lens when `camera` is true. */
  at: THREE.Vector3 | null
}

/** Seconds it stands and stares at the first, second and third meeting. */
const STARE = [8, 7, 10]
/** The chase lasts this long; surviving it is a win. */
export const CHASE_SECONDS = 10
/** A hair above the player's running speed (4.35 m/s). */
export const CHASE_SPEED = 4.5

const wrap = (a: number) => Math.atan2(Math.sin(a), Math.cos(a))
const clamp = THREE.MathUtils.clamp
const smooth = THREE.MathUtils.smoothstep

function rng(seed: number) {
  let s = seed >>> 0
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0
    return s / 4294967296
  }
}

/** Turns a greyscale height map into a tangent-space normal map. */
function heightToNormal(source: HTMLCanvasElement, strength: number) {
  const size = source.width
  const data = source.getContext('2d')!.getImageData(0, 0, size, size).data
  const out = document.createElement('canvas')
  out.width = out.height = size
  const ctx = out.getContext('2d')!
  const image = ctx.createImageData(size, size)
  const at = (x: number, y: number) => data[(((y + size) % size) * size + ((x + size) % size)) * 4] / 255
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (at(x + 1, y) - at(x - 1, y)) * strength
      const dy = (at(x, y + 1) - at(x, y - 1)) * strength
      const len = Math.hypot(dx, dy, 1)
      const i = (y * size + x) * 4
      image.data[i] = ((-dx / len) * 0.5 + 0.5) * 255
      image.data[i + 1] = ((dy / len) * 0.5 + 0.5) * 255
      image.data[i + 2] = ((1 / len) * 0.5 + 0.5) * 255
      image.data[i + 3] = 255
    }
  }
  ctx.putImageData(image, 0, 0)
  const texture = new THREE.CanvasTexture(out)
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping
  return texture
}

function makeSkin() {
  const S = 512
  const r = rng(4242)
  const color = document.createElement('canvas')
  color.width = color.height = S
  const c = color.getContext('2d')!
  c.fillStyle = '#9c978c'
  c.fillRect(0, 0, S, S)
  // Under the skin: red where the blood sits, green-grey where it has left.
  for (let i = 0; i < 320; i++) {
    c.fillStyle = r() > 0.5 ? `rgba(128,62,58,${0.03 + r() * 0.08})` : `rgba(74,98,86,${0.03 + r() * 0.07})`
    c.beginPath()
    c.ellipse(r() * S, r() * S, 10 + r() * 64, 8 + r() * 42, r() * 3, 0, 7)
    c.fill()
  }
  // A network of veins: they fork, thin out, and never quite end.
  const vein = (x: number, y: number, a: number, w: number, depth: number) => {
    if (depth > 4 || w < 0.35) return
    c.strokeStyle = `rgba(${58 + r() * 24},${52 + r() * 18},${112 + r() * 36},${0.2 + r() * 0.26})`
    c.lineWidth = w
    c.beginPath()
    c.moveTo(x, y)
    let px = x
    let py = y
    for (let k = 0; k < 7; k++) {
      a += (r() - 0.5) * 0.7
      px += Math.cos(a) * (14 + r() * 18)
      py += Math.sin(a) * (14 + r() * 18)
      c.lineTo(px, py)
    }
    c.stroke()
    if (r() < 0.75) vein(px, py, a + 0.6 + r() * 0.5, w * 0.62, depth + 1)
    if (r() < 0.55) vein(px, py, a - 0.6 - r() * 0.5, w * 0.58, depth + 1)
  }
  for (let i = 0; i < 16; i++) vein(r() * S, r() * S, r() * 6.3, 1.6 + r() * 1.4, 0)
  // Bruises, jaundice and sores: dark, wet at the middle, pale at the edge.
  for (let i = 0; i < 11; i++) {
    c.fillStyle = r() > 0.5 ? `rgba(92,54,112,${0.1 + r() * 0.16})` : `rgba(124,112,56,${0.1 + r() * 0.13})`
    c.beginPath()
    c.ellipse(r() * S, r() * S, 16 + r() * 42, 10 + r() * 28, r() * 3, 0, 7)
    c.fill()
  }
  for (let i = 0; i < 14; i++) {
    const x = r() * S
    const y = r() * S
    const rx = 3 + r() * 13
    const ry = 2 + r() * 9
    c.fillStyle = `rgba(190,150,140,${0.14 + r() * 0.12})`
    c.beginPath()
    c.ellipse(x, y, rx * 1.5, ry * 1.5, 0, 0, 7)
    c.fill()
    c.fillStyle = `rgba(86,22,24,${0.4 + r() * 0.3})`
    c.beginPath()
    c.ellipse(x, y, rx, ry, 0, 0, 7)
    c.fill()
  }
  for (let i = 0; i < 12000; i++) {
    c.fillStyle = `rgba(${r() > 0.5 ? '255,255,255' : '0,0,0'},${r() * 0.05})`
    c.fillRect(r() * S, r() * S, 1 + r() * 2, 1 + r() * 2)
  }
  const map = new THREE.CanvasTexture(color)
  map.colorSpace = THREE.SRGBColorSpace
  map.wrapS = map.wrapT = THREE.RepeatWrapping

  const height = document.createElement('canvas')
  height.width = height.height = S
  const h = height.getContext('2d')!
  h.fillStyle = '#808080'
  h.fillRect(0, 0, S, S)
  for (let i = 0; i < 420; i++) {
    h.fillStyle = `rgba(${r() > 0.5 ? '255,255,255' : '0,0,0'},${0.03 + r() * 0.05})`
    h.beginPath()
    h.ellipse(r() * S, r() * S, 6 + r() * 36, 4 + r() * 22, r() * 3, 0, 7)
    h.fill()
  }
  // Wrinkles and cracks in a skin that is too tight.
  for (let i = 0; i < 300; i++) {
    h.strokeStyle = `rgba(0,0,0,${0.14 + r() * 0.3})`
    h.lineWidth = 0.6 + r() * 1.3
    h.beginPath()
    const x = r() * S
    const y = r() * S
    h.moveTo(x, y)
    h.bezierCurveTo(x + (r() - 0.5) * 30, y + r() * 14, x + (r() - 0.5) * 30, y + r() * 24, x + (r() - 0.5) * 40, y + r() * 32)
    h.stroke()
  }
  for (let i = 0; i < 9000; i++) {
    h.fillStyle = `rgba(0,0,0,${0.2 + r() * 0.3})`
    h.fillRect(r() * S, r() * S, 1, 1)
  }
  // Veins and sores stand out from the surface a little.
  for (let i = 0; i < 14; i++) {
    h.fillStyle = 'rgba(255,255,255,.35)'
    h.beginPath()
    h.ellipse(r() * S, r() * S, 4 + r() * 10, 3 + r() * 7, r() * 3, 0, 7)
    h.fill()
  }

  // Roughness: damp and glossy where it is raw or wet, dry and flaking elsewhere.
  const rough = document.createElement('canvas')
  rough.width = rough.height = S
  const g = rough.getContext('2d')!
  g.fillStyle = 'rgb(150,150,150)'
  g.fillRect(0, 0, S, S)
  for (let i = 0; i < 180; i++) {
    const wet = r() > 0.45
    g.fillStyle = wet ? `rgba(40,40,40,${0.2 + r() * 0.4})` : `rgba(235,235,235,${0.15 + r() * 0.3})`
    g.beginPath()
    g.ellipse(r() * S, r() * S, 6 + r() * 40, 4 + r() * 26, r() * 3, 0, 7)
    g.fill()
  }
  const roughness = new THREE.CanvasTexture(rough)
  roughness.wrapS = roughness.wrapT = THREE.RepeatWrapping
  return { map, normal: heightToNormal(height, 3.4), rough: roughness }
}

function makeCloth() {
  const S = 256
  const r = rng(808)
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = S
  const c = canvas.getContext('2d')!
  c.fillStyle = '#2b2927'
  c.fillRect(0, 0, S, S)
  for (let i = 0; i < 220; i++) {
    c.strokeStyle = `rgba(${r() > 0.5 ? '10,9,9' : '62,57,50'},${0.1 + r() * 0.25})`
    c.lineWidth = 0.7
    c.beginPath()
    const x = r() * S
    c.moveTo(x, r() * S)
    c.lineTo(x + (r() - 0.5) * 8, r() * S)
    c.stroke()
  }
  for (let i = 0; i < 16; i++) {
    c.fillStyle = `rgba(${r() > 0.4 ? '58,36,30' : '40,50,36'},${0.14 + r() * 0.2})`
    c.beginPath()
    c.ellipse(r() * S, r() * S, 6 + r() * 20, 4 + r() * 14, r() * 3, 0, 7)
    c.fill()
  }
  // Holes: the fabric is torn through, so the alpha channel is cut out.
  c.globalCompositeOperation = 'destination-out'
  for (let i = 0; i < 26; i++) {
    c.beginPath()
    c.ellipse(r() * S, r() * S, 3 + r() * 13, 3 + r() * 20, r() * 3, 0, 7)
    c.fill()
  }
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping
  return texture
}

function makeEye() {
  const canvas = document.createElement('canvas')
  canvas.width = 256
  canvas.height = 128
  const c = canvas.getContext('2d')!
  const r = rng(99)
  c.fillStyle = '#cdc6a4'
  c.fillRect(0, 0, 256, 128)
  c.strokeStyle = 'rgba(150,32,28,.55)'
  c.lineWidth = 1
  for (let i = 0; i < 90; i++) {
    const a = r() * Math.PI * 2
    c.beginPath()
    c.moveTo(192 + Math.cos(a) * 60, 64 + Math.sin(a) * 40)
    c.lineTo(192 + Math.cos(a) * 18, 64 + Math.sin(a) * 12)
    c.stroke()
  }
  c.fillStyle = '#2d2615'
  c.beginPath()
  c.ellipse(192, 64, 16, 14, 0, 0, 7)
  c.fill()
  c.fillStyle = '#050403'
  c.beginPath()
  c.ellipse(192, 64, 5, 5, 0, 0, 7)
  c.fill()
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  return texture
}

/** A tapered limb that hangs down from y = 0, with one swelling (muscle or bone) along its length. */
function limbGeometry(len: number, top: number, bottom: number, bulge: number, at: number, seg = 14) {
  const pts: THREE.Vector2[] = []
  for (let i = 0; i <= 12; i++) {
    const t = i / 12
    const r = THREE.MathUtils.lerp(bottom, top, t) + bulge * Math.exp(-Math.pow((t - at) / 0.2, 2))
    pts.push(new THREE.Vector2(Math.max(0.003, r), -len + t * len))
  }
  return new THREE.LatheGeometry(pts, seg)
}

/** An elongated skull: sunken cheeks, a brow ridge, a narrow jaw. The face looks toward -z. */
function skullGeometry() {
  const g = new THREE.SphereGeometry(1, 44, 30)
  const p = g.attributes.position as THREE.BufferAttribute
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i)
    const y = p.getY(i)
    const z = p.getZ(i)
    const taper = THREE.MathUtils.lerp(0.56, 1, smooth(y, -0.95, 0.35))
    let px = x * 0.1 * taper
    const py = y * 0.172
    let pz = z * 0.113 * THREE.MathUtils.lerp(0.78, 1, smooth(y, -1, 0))
    if (z < 0) {
      const cheek = Math.exp(-Math.pow((y + 0.25) / 0.3, 2)) * smooth(Math.abs(x), 0.25, 0.85)
      pz += cheek * 0.016
      px *= 1 - cheek * 0.14
      pz -= Math.exp(-Math.pow((y - 0.3) / 0.12, 2)) * 0.008
    } else pz *= 1.14
    p.setXYZ(i, px, py, pz)
  }
  g.computeVertexNormals()
  return g
}

interface Hand { fingers: THREE.Group[][]; thumb: THREE.Group[] }

/**
 * The presence of the house: about 2.6 m tall, far too thin, arms that end below the knees,
 * a long face with no lips and wet black sockets. It is built to read as a silhouette first and
 * as a body only where the torch lands.
 */
export class EntitySystem {
  readonly mesh = new THREE.Group()
  position = new THREE.Vector3()
  state: Behavior = 'dormant'
  lastSeenAt = -100
  lastSeenRoom = ''
  /** Meetings that were not reported. At three, it stares and then hunts. */
  strikes = 0
  chaseLeft = 0
  events: EntityEvent[] = []

  private sightings: { room: string; at: number }[] = []
  private route: THREE.Vector3[] = []
  private waypoint = 0
  private wait = 12
  private routeTimer = 0
  private seenFor = 0
  private unseenFor = 99
  private torchFor = 0
  private footstep = 0
  private grace = 0
  private watchTime = 0
  private burst = 0
  private whisperTimer = 24
  private raspTimer = 6
  private screamTimer = 0
  private flickerTimer = 2
  private encounterCooldown = 0
  private sight = false
  private respawnIn = 0
  private vanishIn = 0
  /** Time spent unseen after a manifestation; long enough means it is no longer just an apparition. */
  private unseenThreatFor = 0
  /** How long the current manifestation is allowed to remain in the house. */
  private manifestationFor = 0
  private generation = 0
  private stareTime = 0
  private stareDuration = 8
  private stareThen: 'leave' | 'chase' = 'leave'
  private stareAt = new THREE.Vector3()
  private stareCamera = false
  private baseScale = new THREE.Vector3(1, 1, 1)

  // Pose state
  private clock = 0
  private phase = 0
  private speed = 0
  private crouch = 0
  private jaw = 0
  private headYaw = 0
  private headPitch = 0
  private headRoll = 0
  private twitch = 0
  private twitchTimer = 2
  private stutter = 0
  private stepClock = 0
  private rand = rng(777)

  // Rig
  private skinMat!: THREE.MeshPhysicalMaterial
  private cavity!: THREE.Mesh
  private tongue!: THREE.Mesh
  private drool: THREE.Mesh[] = []
  private mouthAnchor = new THREE.Object3D()
  private stareP = 0
  /** It does not exist before 01:00. */
  private appeared = false
  private clickTimer = 3
  private dragTimer = 45
  private grab: { holder: THREE.Group; side: number; hand: Hand }[] = []
  private grabLight!: THREE.PointLight
  /** Hands that seize the view during the kill. Attach to the camera. */
  readonly grabGroup = new THREE.Group()
  private readonly _a = new THREE.Vector3()
  private readonly _f = new THREE.Vector3()
  private readonly _q = new THREE.Quaternion()
  private body = new THREE.Group()
  private spine = new THREE.Group()
  private neck = new THREE.Group()
  private head = new THREE.Group()
  private jawGroup = new THREE.Group()
  private hair = new THREE.Group()
  private legs: { hip: THREE.Group; knee: THREE.Group }[] = []
  private arms: { shoulder: THREE.Group; elbow: THREE.Group; hand: Hand }[] = []
  private strips: THREE.Mesh[] = []
  private eyeShine: THREE.MeshBasicMaterial

  constructor(scene: THREE.Scene, private house: HouseSystem, private player: PlayerSystem, private lights: LightingSystem, private doors: DoorSystem, private audio: HouseAudio, private night: NightSystem) {
    this.eyeShine = new THREE.MeshBasicMaterial({ color: 0xd9f2c6, transparent: true, opacity: 0, toneMapped: false, depthWrite: false })
    this.build()
    this.mesh.name = 'house-presence'
    this.applyVariant()
    scene.add(this.mesh)
    this.reset()
  }

  /* ------------------------------------------------------------ model */

  private build() {
    const skinTex = makeSkin()
    const skin = new THREE.MeshPhysicalMaterial({
      color: 0xffffff, map: skinTex.map, normalMap: skinTex.normal, normalScale: new THREE.Vector2(1.5, 1.5),
      roughness: 1, roughnessMap: skinTex.rough, clearcoat: 0.32, clearcoatRoughness: 0.38, sheen: 0.6, sheenRoughness: 0.5, sheenColor: new THREE.Color(0x7a5a64),
    })
    this.skinMat = skin
    const cloth = new THREE.MeshStandardMaterial({ map: makeCloth(), roughness: 1, side: THREE.DoubleSide, alphaTest: 0.45 })
    const eyeMat = new THREE.MeshPhysicalMaterial({ map: makeEye(), roughness: 0.14, clearcoat: 1, clearcoatRoughness: 0.05 })
    const teethMat = new THREE.MeshStandardMaterial({ color: 0xcbbf9c, roughness: 0.42 })
    const gumMat = new THREE.MeshStandardMaterial({ color: 0x4e2427, roughness: 0.5 })
    const boneMat = new THREE.MeshPhysicalMaterial({ color: 0xc9bfa0, roughness: 0.48, clearcoat: 0.2 })
    const clawMat = new THREE.MeshStandardMaterial({ color: 0x1a1612, roughness: 0.32 })
    const veinMat = new THREE.MeshStandardMaterial({ color: 0x3a2a46, roughness: 0.38 })
    const flapMat = skin.clone()
    flapMat.side = THREE.DoubleSide
    const hairMat = new THREE.MeshStandardMaterial({ color: 0x0c0b0b, roughness: 0.4, metalness: 0.2 })
    const black = new THREE.MeshBasicMaterial({ color: 0x000000 })

    const mesh = (g: THREE.BufferGeometry, m: THREE.Material, cast = false) => {
      const o = new THREE.Mesh(g, m)
      o.castShadow = cast
      o.receiveShadow = true
      return o
    }
    const ball = (radius: number, m: THREE.Material, sx = 1, sy = 1, sz = 1, cast = false) => {
      const o = mesh(new THREE.SphereGeometry(1, 16, 12), m, cast)
      o.scale.set(radius * sx, radius * sy, radius * sz)
      return o
    }
    const finger = (len: number, joints = 3) => {
      const root = new THREE.Group()
      const groups: THREE.Group[] = []
      let parent: THREE.Group = root
      const parts = [0.44, 0.33, 0.23]
      let offset = 0
      for (let j = 0; j < joints; j++) {
        const seg = parts[j] * len
        const jg = new THREE.Group()
        jg.position.y = -offset
        parent.add(jg)
        const g = new THREE.CylinderGeometry(0.0056 - j * 0.0011, 0.0049 - j * 0.0011, seg, 7)
        g.translate(0, -seg / 2, 0)
        jg.add(mesh(g, skin))
        const knuckle = ball(0.0062 - j * 0.001, skin)
        jg.add(knuckle)
        if (j === joints - 1) {
          const claw = mesh(new THREE.ConeGeometry(0.0042, 0.03, 5), clawMat)
          claw.rotation.x = Math.PI
          claw.position.set(0, -seg - 0.011, -0.001)
          jg.add(claw)
        }
        groups.push(jg)
        parent = jg
        offset = seg
      }
      return { root, groups }
    }
    const buildHand = (side: number): { group: THREE.Group; hand: Hand } => {
      const group = new THREE.Group()
      const palm = mesh(new THREE.BoxGeometry(0.064, 0.092, 0.02), skin)
      palm.position.y = -0.046
      group.add(palm)
      const hand: Hand = { fingers: [], thumb: [] }
      const lengths = [0.19, 0.215, 0.205, 0.16]
      for (let f = 0; f < 4; f++) {
        const fg = finger(lengths[f])
        fg.root.position.set((f - 1.5) * 0.0165 * side, -0.092, 0)
        group.add(fg.root)
        hand.fingers.push(fg.groups)
      }
      const th = finger(0.14, 2)
      th.root.position.set(side * -0.034, -0.03, -0.004)
      th.root.rotation.z = side * -0.5
      group.add(th.root)
      hand.thumb = th.groups
      return { group, hand }
    }

    // Pelvis and legs
    this.body.position.y = 1.22
    this.mesh.add(this.body)
    this.body.add(ball(0.13, skin, 1.1, 0.7, 0.8))
    for (const side of [1, -1]) {
      const hip = new THREE.Group()
      hip.position.set(side * 0.105, -0.02, 0)
      hip.add(mesh(limbGeometry(0.6, 0.06, 0.04, 0.009, 0.7), skin, true))
      const knee = new THREE.Group()
      knee.position.y = -0.6
      knee.add(ball(0.038, skin))
      knee.add(mesh(limbGeometry(0.62, 0.039, 0.022, 0.006, 0.8), skin, true))
      const foot = new THREE.Group()
      foot.position.set(0, -0.615, 0)
      foot.add(mesh(new THREE.BoxGeometry(0.058, 0.032, 0.18), skin))
      foot.children[0].position.set(0, 0, -0.05)
      for (let t = 0; t < 5; t++) {
        const toe = mesh(new THREE.BoxGeometry(0.009, 0.009, 0.04), skin)
        toe.position.set((t - 2) * 0.0115 * side, -0.004, -0.15)
        foot.add(toe)
        const nail = mesh(new THREE.BoxGeometry(0.007, 0.002, 0.008), new THREE.MeshStandardMaterial({ color: 0x3a342c }))
        nail.position.set((t - 2) * 0.0115 * side, 0.002, -0.168)
        foot.add(nail)
      }
      knee.add(foot)
      hip.add(knee)
      this.body.add(hip)
      this.legs.push({ hip, knee })
    }

    // Torso: narrow, with a visible ribcage, spine and shoulder blades
    this.body.add(this.spine)
    const torsoProfile: [number, number][] = [[0.085, 0], [0.082, 0.1], [0.095, 0.22], [0.125, 0.4], [0.15, 0.55], [0.152, 0.65], [0.12, 0.75], [0.05, 0.82]]
    const torso = mesh(new THREE.LatheGeometry(torsoProfile.map(([r, y]) => new THREE.Vector2(r, y)), 24), skin, true)
    torso.scale.z = 0.56
    this.spine.add(torso)
    const radiusAt = (y: number) => {
      for (let i = 1; i < torsoProfile.length; i++) {
        if (y <= torsoProfile[i][1]) {
          const [r0, y0] = torsoProfile[i - 1]
          const [r1, y1] = torsoProfile[i]
          return THREE.MathUtils.lerp(r0, r1, (y - y0) / (y1 - y0))
        }
      }
      return 0.05
    }
    for (let i = 0; i < 8; i++) {
      const y = 0.3 + i * 0.058
      const arc = Math.PI * (1.25 - i * 0.03)
      const ring = new THREE.Group()
      const bone = mesh(new THREE.TorusGeometry(radiusAt(y) * 1.03, 0.0066, 6, 24, arc), boneMat)
      bone.rotation.x = Math.PI / 2
      ring.add(bone)
      ring.position.y = y
      ring.rotation.y = arc / 2 + Math.PI / 2
      ring.scale.z = 0.56
      this.spine.add(ring)
    }
    for (let i = 0; i < 12; i++) {
      const y = 0.08 + i * 0.058
      const bump = ball(0.0118, boneMat, 1, 0.9, 0.9)
      bump.position.set(0, y, radiusAt(y) * 0.56 * 1.0)
      this.spine.add(bump)
    }
    for (const side of [1, -1]) {
      const blade = ball(0.05, skin, 0.9, 1.5, 0.22)
      blade.position.set(side * 0.075, 0.6, 0.082)
      blade.rotation.z = side * 0.25
      this.spine.add(blade)
      const collar = mesh(new THREE.CylinderGeometry(0.0055, 0.0045, 0.12, 6), skin)
      collar.rotation.z = Math.PI / 2 + side * 0.18
      collar.position.set(side * 0.07, 0.775, -0.04)
      this.spine.add(collar)
    }
    // Torn shirt: a ragged skirt around the waist and long dangling strips
    const shirtProfile: [number, number][] = [[0.15, 0], [0.145, 0.2], [0.13, 0.42], [0.1, 0.62]]
    const shirt = mesh(new THREE.LatheGeometry(shirtProfile.map(([r, y]) => new THREE.Vector2(r, y + 0.0)), 20, 0, Math.PI * 2), cloth)
    shirt.scale.set(1.04, 1, 0.64)
    shirt.position.y = -0.1
    this.spine.add(shirt)
    const r = rng(31337)
    for (let i = 0; i < 20; i++) {
      const a = (i / 20) * Math.PI * 2
      const len = 0.3 + r() * 0.5
      const geo = new THREE.PlaneGeometry(0.04 + r() * 0.05, len, 1, 4)
      geo.translate(0, -len / 2, 0)
      const strip = mesh(geo, cloth)
      strip.position.set(Math.cos(a) * 0.14, 0.06, Math.sin(a) * 0.092)
      strip.rotation.y = Math.PI / 2 - a
      strip.userData.base = 0.05 + r() * 0.12
      this.spine.add(strip)
      this.strips.push(strip)
    }

    // Arms, much too long, ending in articulated hands
    for (const side of [1, -1]) {
      const shoulder = new THREE.Group()
      shoulder.position.set(side * 0.185, 0.76, 0)
      shoulder.add(ball(0.04, skin))
      shoulder.add(mesh(limbGeometry(0.68, 0.039, 0.028, 0.006, 0.75), skin, true))
      const elbow = new THREE.Group()
      elbow.position.y = -0.68
      elbow.add(ball(0.027, skin))
      for (let k = 0; k < 9; k++) {
        const len = 0.07 + r() * 0.16
        const geo = new THREE.PlaneGeometry(0.011 + r() * 0.016, len, 1, 3)
        geo.translate(0, -len / 2, 0)
        const flap = mesh(geo, flapMat)
        const ang = r() * Math.PI * 2
        flap.position.set(Math.cos(ang) * 0.019, -0.1 - k * 0.07, Math.sin(ang) * 0.019)
        flap.rotation.set(0.18 + r() * 0.5, ang, 0)
        elbow.add(flap)
      }
      // One arm is longer than the other: the proportions are never quite right.
      if (side === 1) elbow.scale.y = 1.16
      elbow.add(mesh(limbGeometry(0.8, 0.027, 0.016, 0.004, 0.78), skin, true))
      const built = buildHand(side)
      built.group.position.y = -0.8
      built.group.rotation.y = side * 0.2
      elbow.add(built.group)
      shoulder.add(elbow)
      this.spine.add(shoulder)
      this.arms.push({ shoulder, elbow, hand: built.hand })
    }

    // Hands that seize the view during the kill, built like the others and fixed to the camera.
    this.grabGroup.visible = false
    this.grabLight = new THREE.PointLight(0xd8cdb8, 0, 3.2, 2)
    this.grabLight.position.set(0, 0.12, -0.15)
    this.grabGroup.add(this.grabLight)
    for (const side of [-1, 1]) {
      const built = buildHand(side)
      const forearm = mesh(limbGeometry(0.9, 0.016, 0.03, 0.004, 0.3), skin)
      forearm.rotation.x = Math.PI
      built.group.add(forearm)
      const holder = new THREE.Group()
      holder.add(built.group)
      holder.rotation.set(Math.PI / 2, side * (Math.PI / 2), 0)
      holder.scale.setScalar(1.25)
      this.grabGroup.add(holder)
      this.grab.push({ holder, side, hand: built.hand })
    }

    // Neck with tendons, then the head
    this.neck.position.set(0, 0.8, -0.012)
    const neckGeo = new THREE.CylinderGeometry(0.029, 0.04, 0.3, 10)
    neckGeo.translate(0, 0.15, 0)
    this.neck.add(mesh(neckGeo, skin, true))
    for (const side of [1, -1]) {
      const tendon = mesh(new THREE.CylinderGeometry(0.0045, 0.0045, 0.26, 5), skin)
      tendon.position.set(side * 0.017, 0.14, -0.02)
      this.neck.add(tendon)
    }
    this.head.position.set(0, 0.28, -0.02)
    const skull = mesh(skullGeometry(), skin, true)
    skull.position.y = 0.16
    this.head.add(skull)
    const onSkull = (x: number, y: number) => {
      const yn = (y - 0.16) / 0.172
      const taper = THREE.MathUtils.lerp(0.56, 1, smooth(yn, -0.95, 0.35))
      const rx = 0.1 * taper
      const zr = 0.113 * THREE.MathUtils.lerp(0.78, 1, smooth(yn, -1, 0))
      const inside = 1 - (x / rx) ** 2 - yn * yn
      return new THREE.Vector3(x, y, -zr * Math.sqrt(Math.max(0.03, inside)) - 0.0012)
    }
    for (const side of [1, -1]) {
      for (let v = 0; v < 4; v++) {
        const pts: THREE.Vector3[] = []
        let x = side * (0.012 + v * 0.011)
        let y = 0.252 + v * 0.006
        for (let k = 0; k < 6; k++) {
          pts.push(onSkull(x, y))
          x += side * (0.009 + r() * 0.011)
          y += (v % 2 ? 0.01 : -0.004) + r() * 0.011
        }
        this.head.add(mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 14, 0.0013 + r() * 0.0007, 4), veinMat))
      }
    }

    // Sunken eye sockets with wet eyes deep inside
    for (const side of [1, -1]) {
      // No lids: the eye is too large for its socket and the rim around it is raw.
      const size = side === 1 ? 1.14 : 1
      const socket = ball(0.028, black, 1, 1.15, 0.7)
      socket.position.set(side * 0.04, 0.19, -0.094)
      this.head.add(socket)
      const eye = ball(0.0168 * size, eyeMat)
      eye.position.set(side * 0.04, 0.19 - (side === 1 ? 0.004 : 0), -0.09)
      this.head.add(eye)
      const rim = mesh(new THREE.TorusGeometry(0.0182 * size, 0.0028, 6, 20), new THREE.MeshStandardMaterial({ color: 0x5c1e22, roughness: 0.3 }))
      rim.position.set(side * 0.04, 0.19 - (side === 1 ? 0.004 : 0), -0.096)
      this.head.add(rim)
      const shine = new THREE.Mesh(new THREE.SphereGeometry(0.0148 * size, 8, 6), this.eyeShine)
      shine.position.set(side * 0.04, 0.19 - (side === 1 ? 0.004 : 0), -0.101)
      this.head.add(shine)
    }
    // No nose to speak of: a flat ridge and two slits
    const ridge = mesh(new THREE.BoxGeometry(0.008, 0.05, 0.01), skin)
    ridge.position.set(0, 0.145, -0.108)
    this.head.add(ridge)
    for (const side of [1, -1]) {
      const slit = ball(0.0055, black, 0.6, 1.5, 0.5)
      slit.position.set(side * 0.0075, 0.112, -0.111)
      this.head.add(slit)
    }
    // Mouth: dark cavity, upper teeth fixed to the skull, lower teeth on the jaw
    const cavity = ball(0.05, black, 1, 0.35, 0.5)
    this.cavity = cavity
    cavity.position.set(0, 0.07, -0.082)
    this.head.add(cavity)
    const gumUpper = mesh(new THREE.BoxGeometry(0.1, 0.008, 0.016), gumMat)
    gumUpper.position.set(0, 0.0845, -0.098)
    this.head.add(gumUpper)
    for (let i = 0; i < 14; i++) {
      const w = 0.0058 + (i % 3) * 0.0005
      const tooth = mesh(new THREE.ConeGeometry(w * 0.55, 0.017 + (i % 2) * 0.006, 5), teethMat)
      tooth.rotation.x = Math.PI
      tooth.position.set((i - 6.5) * 0.0072, 0.074, -0.1 + Math.abs(i - 6.5) * 0.0012)
      this.head.add(tooth)
    }
    this.jawGroup.position.set(0, 0.1, -0.012)
    const jaw = ball(0.055, skin, 0.9, 1.15, 1.25)
    jaw.position.set(0, -0.06, -0.06)
    this.jawGroup.add(jaw)
    const gumLower = mesh(new THREE.BoxGeometry(0.09, 0.008, 0.016), gumMat)
    gumLower.position.set(0, -0.026, -0.1)
    this.jawGroup.add(gumLower)
    for (let i = 0; i < 12; i++) {
      const tooth = mesh(new THREE.ConeGeometry(0.0034, 0.015 + (i % 2) * 0.005, 5), teethMat)
      tooth.position.set((i - 5.5) * 0.0073, -0.021, -0.1 + Math.abs(i - 5.5) * 0.0012)
      this.jawGroup.add(tooth)
    }
    this.head.add(this.jawGroup)
    // Tongue, a second row of teeth, long canines and threads of saliva: all invisible when the mouth
    // is shut, all too much when it opens.
    const tongueMat = new THREE.MeshStandardMaterial({ color: 0x6b2c33, roughness: 0.32, emissive: 0x1c0507 })
    this.tongue = ball(0.034, tongueMat, 0.8, 0.28, 1.9)
    this.tongue.position.set(0, -0.03, -0.05)
    this.jawGroup.add(this.tongue)
    for (let i = 0; i < 10; i++) {
      const up = mesh(new THREE.ConeGeometry(0.0026, 0.012, 4), teethMat)
      up.rotation.x = Math.PI
      up.position.set((i - 4.5) * 0.0078, 0.07, -0.082)
      this.head.add(up)
      const low = mesh(new THREE.ConeGeometry(0.0026, 0.011, 4), teethMat)
      low.position.set((i - 4.5) * 0.0078, -0.02, -0.083)
      this.jawGroup.add(low)
    }
    for (const side of [1, -1]) {
      const fangUp = mesh(new THREE.ConeGeometry(0.0046, 0.034, 5), teethMat)
      fangUp.rotation.x = Math.PI
      fangUp.position.set(side * 0.032, 0.066, -0.102)
      this.head.add(fangUp)
      const fangLow = mesh(new THREE.ConeGeometry(0.0046, 0.03, 5), teethMat)
      fangLow.position.set(side * 0.029, -0.012, -0.102)
      this.jawGroup.add(fangLow)
    }
    const droolMat = new THREE.MeshStandardMaterial({ color: 0xd2d8d2, transparent: true, opacity: 0.5, roughness: 0.08 })
    for (let i = 0; i < 4; i++) {
      const g = new THREE.CylinderGeometry(0.0009, 0.0006, 0.06, 4)
      g.translate(0, -0.03, 0)
      const d = mesh(g, droolMat)
      d.position.set((i - 1.5) * 0.019, -0.02, -0.096)
      this.jawGroup.add(d)
      this.drool.push(d)
    }
    this.mouthAnchor.position.set(0, 0.065, -0.085)
    this.head.add(this.mouthAnchor)

    // Long wet hair that blurs the outline of the head and hangs over the face
    this.hair.position.set(0, 0.31, 0.005)
    for (let i = 0; i < 40; i++) {
      const a = r() * Math.PI * 2
      const radius = 0.052 + r() * 0.045
      const sx = Math.cos(a) * radius
      const sz = Math.sin(a) * radius * 1.05
      const length = 0.3 + r() * 0.42
      const pts = [0, 0.25, 0.55, 0.8, 1].map((t, k) => new THREE.Vector3(
        sx * (1 + k * 0.12) + (r() - 0.5) * 0.01 * k,
        -t * length - (k === 0 ? 0 : 0.0),
        sz * (1 + k * 0.1) + (a > Math.PI ? -0.01 : 0.012) * k + (r() - 0.5) * 0.01 * k,
      ))
      const tube = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 10, 0.0021 + r() * 0.0012, 4)
      this.hair.add(mesh(tube, hairMat))
    }
    this.head.add(this.hair)
    this.neck.add(this.head)
    this.spine.add(this.neck)
  }

  /** Each new one is a little different: height, thinness and pallor. It is never quite the same body. */
  private applyVariant() {
    const variants = [
      { sx: 0.8, sy: 1, tint: 0xffffff },
      { sx: 0.72, sy: 1.04, tint: 0xdfe9e6 },
      { sx: 0.86, sy: 0.97, tint: 0xffeee2 },
      { sx: 0.7, sy: 1.03, tint: 0xd6dee4 },
    ]
    const v = variants[this.generation % variants.length]
    this.baseScale.set(v.sx, v.sy, v.sx)
    this.mesh.scale.copy(this.baseScale)
    this.skinMat.color.setHex(v.tint)
  }

  private headHeight() {
    return (2.45 - this.crouch * 0.95) * this.mesh.scale.y
  }

  /** The centre of its head. Used for line of sight, sound and being looked at. */
  headPoint() {
    return this.position.clone().add(new THREE.Vector3(0, this.headHeight(), 0))
  }

  get chasing() { return this.state === 'hunt' }
  get staring() { return this.state === 'stare' }
  get stareProgress() { return this.state === 'stare' ? clamp(this.stareTime / this.stareDuration, 0, 1) : 0 }

  /* ------------------------------------------------------------ life cycle */

  reset() {
    const node = this.house.closestNode(new THREE.Vector3(7.65, -3, 7.45))
    this.position.copy(node?.p ?? new THREE.Vector3(7.65, -3, 7.45))
    this.mesh.position.copy(this.position)
    this.mesh.rotation.y = 0
    this.state = 'dormant'
    this.mesh.visible = false
    this.route = []
    this.waypoint = 0
    this.wait = 12
    this.routeTimer = 0
    this.seenFor = 0
    this.unseenFor = 99
    this.torchFor = 0
    this.lastSeenAt = -100
    this.lastSeenRoom = ''
    this.grace = 0
    this.watchTime = 0
    this.burst = 0
    this.sight = false
    this.respawnIn = 0
    this.vanishIn = 0
    this.unseenThreatFor = 0
    this.manifestationFor = 0
    this.generation = 0
    this.strikes = 0
    this.sightings = []
    this.events = []
    this.chaseLeft = 0
    this.encounterCooldown = 0
    this.stareTime = 0
    this.appeared = false
    this.clickTimer = 3
    this.dragTimer = 45
    this.jaw = 0
    this.applyVariant()
    this.speed = 0
    this.crouch = 0
    this.headYaw = 0
    this.headPitch = 0
    this.headRoll = 0
    this.grabGroup.visible = false
    this.arms.forEach((a) => { a.shoulder.visible = true })
    this.neck.scale.set(1, 1, 1)
    this.applyJaw(0)
    this.eyeShine.opacity = 0
    this.lights.presence = 0
    this.audio.setPresence(0, this.position)
  }

  /** True once when the player first lays eyes on it after a long absence. */
  consumeSight() {
    const s = this.sight
    this.sight = false
    return s
  }

  hasSighting(room: string) {
    return this.sightings.some((s) => s.room === room && this.night.elapsed - s.at < 900)
  }

  private plan(target: THREE.Vector3, interval = 4) {
    const path = this.house.path(this.position, target)
    if (path.length) path[0] = this.position.clone()
    this.route = this.smooth(path)
    this.waypoint = this.route.length > 1 ? 1 : 0
    this.routeTimer = interval
  }

  /** Is the straight line between two points free for a body this tall and wide? */
  private clear(a: THREE.Vector3, b: THREE.Vector3) {
    if (Math.abs(a.y - b.y) > 0.05) return false
    const steps = Math.ceil(a.distanceTo(b) / 0.12)
    for (let k = 1; k < steps; k++) {
      const t = k / steps
      if (this.house.blocked(a.x + (b.x - a.x) * t, a.y, a.z + (b.z - a.z) * t, 0.2, false, 1.8)) return false
    }
    return true
  }

  /**
   * The navigation grid gives staircase paths, which are up to 40% longer than a straight run.
   * Pull the path tight wherever the way is clear, so a chase is a chase and not a zigzag.
   */
  private smooth(route: THREE.Vector3[]) {
    if (route.length < 3) return route
    const out = [route[0]]
    let i = 0
    while (i < route.length - 1) {
      let j = Math.min(route.length - 1, i + 28)
      for (; j > i + 1; j--) if (this.clear(route[i], route[j])) break
      out.push(route[j])
      i = j
    }
    return out
  }

  private chooseDestination(retreat = false) {
    const start = this.house.closestNode(this.position)
    const candidates = this.house.rooms.filter((r) => r.nodes.some((id) => this.house.nodes[id].component === start?.component))
    candidates.sort((a, b) => {
      const da = a.center.distanceTo(this.player.position), db = b.center.distanceTo(this.player.position)
      return retreat ? db - da : Math.abs(da - 6) - Math.abs(db - 6)
    })
    const room = candidates[Math.floor(this.night.random() * Math.min(3, candidates.length))]
    if (!room) return
    const spots = room.nodes.filter((id) => {
      const n = this.house.nodes[id]
      return n.p.distanceTo(this.player.position) > (retreat ? 8 : 3.5) && !this.house.visible(this.player.eyePosition(), n.p.clone().add(new THREE.Vector3(0, 1.6, 0)))
    })
    const node = this.house.nodes[spots[Math.floor(this.night.random() * spots.length)]]
    this.plan(node?.p ?? room.center)
  }

  /**
   * A place from which it can stand and look at the player: in line of sight, far enough to be a
   * shape rather than a person, preferably dark and outside the field of view.
   */
  private chooseWatchSpot(closeness: number) {
    const lo = Math.max(4.5, 12 - 8 * closeness)
    const hi = 15 - 7 * closeness
    const start = this.house.closestNode(this.position)
    if (!start) return null
    const eye = this.player.eyePosition()
    const forward = new THREE.Vector3(-Math.sin(this.player.yaw), 0, -Math.cos(this.player.yaw))
    let best: THREE.Vector3 | null = null
    let bestScore = -Infinity
    for (let i = (this.night.random() * 3) | 0; i < this.house.nodes.length; i += 3) {
      const n = this.house.nodes[i]
      if (n.component !== start.component || Math.abs(n.p.y - this.player.position.y) > 1.4) continue
      const d = n.p.distanceTo(this.player.position)
      if (d < lo || d > hi) continue
      const head = n.p.clone().add(new THREE.Vector3(0, 2.4 * this.baseScale.y, 0))
      if (!this.house.visible(eye, head)) continue
      const dir = n.p.clone().sub(this.player.position).setY(0).normalize()
      const outsideView = 1 - Math.max(0, forward.dot(dir))
      const dark = 1 - clamp(this.lights.brightness(n.p.clone().add(new THREE.Vector3(0, 1, 0))) * 3, 0, 1)
      const score = outsideView * 1.1 + dark * 1.6 + this.night.random() * 0.5
      if (score > bestScore) { bestScore = score; best = n.p }
    }
    return best
  }

  private stalkCloser(closeness: number) {
    const spot = this.chooseWatchSpot(closeness)
    if (!spot) { this.state = 'roam'; this.chooseDestination(); return }
    this.state = 'stalk'
    this.plan(spot, 5)
    if (!this.route.length) { this.state = 'roam'; this.wait = 6 }
  }

  private beginWatch() {
    this.state = 'watch'
    this.watchTime = 0
    this.route = []
    this.waypoint = 0
    this.unseenFor = Math.max(0, this.unseenFor)
  }

  /** The first, second or third time the player lays eyes on it without having reported the last one. */
  private onEncounter(via: SightContext) {
    this.strikes = Math.min(3, this.strikes + 1)
    const room = this.house.roomAt(this.position)?.id ?? ''
    this.sightings.push({ room, at: this.night.elapsed })
    this.state = 'stare'
    this.stareTime = 0
    this.stareCamera = via.camera && !!via.at
    if (this.stareCamera && via.at) this.stareAt.copy(via.at)
    this.stareDuration = STARE[this.strikes - 1]
    this.stareThen = this.strikes >= 3 ? 'chase' : 'leave'
    this.route = []
    this.waypoint = 0
    this.events.push({ type: 'encounter', strikes: this.strikes, viaCamera: via.camera, room })
    this.audio.play('impact', undefined, 0.6 + this.strikes * 0.1)
    this.clickTimer = 1.2
  }

  private startChase() {
    this.state = 'hunt'
    this.chaseLeft = CHASE_SECONDS
    this.grace = 0
    this.screamTimer = 0
    this.events.push({ type: 'chaseStart' })
    this.plan(this.player.position, 0.4)
  }

  /**
   * Reporting makes it go: the lights stutter and it is simply gone. Another one comes back later in
   * the night, and the count of unreported meetings starts again from zero.
   */
  banish(seconds = 30) {
    // Reporting only removes the current manifestation. Keep strikes/sightings so the game
    // remembers that it has already fixed the player once; repeated meetings stay meaningful.
    this.chaseLeft = 0
    if (this.state === 'dormant' || this.vanishIn > 0) return false
    const room = this.house.roomAt(this.position)
    if (room) this.lights.flicker(room.id, 0.7)
    this.audio.play('thud', this.headPoint(), 0.5)
    this.vanishIn = 0.5
    // Gone for exactly as long as it was promised, give or take a breath.
    this.respawnIn = seconds
    this.unseenThreatFor = 0
    this.manifestationFor = 0
    this.grace = 0
    return true
  }

  /** A bullet found it: it stays away twice as long as after a report. */
  shot() {
    return this.banish(60)
  }

  /** Distance along the ray to the body, or null if it misses. Used for gunshots. */
  rayHit(origin: THREE.Vector3, dir: THREE.Vector3, max: number) {
    if (this.state === 'dormant' || this.vanishIn > 0) return null
    const top = this.headHeight() * 0.97
    for (let k = 0; k <= 6; k++) {
      const h = (0.15 + (top - 0.15) * (k / 6))
      const p = this.position.clone().add(new THREE.Vector3(0, h, 0))
      const to = p.clone().sub(origin)
      const t = to.dot(dir)
      if (t < 0.2 || t > max) continue
      const closest = origin.clone().addScaledVector(dir, t)
      const radius = k >= 5 ? 0.24 : 0.3
      if (closest.distanceTo(p) < radius) return { distance: t, point: p }
    }
    return null
  }

  private respawn() {
    const eye = this.player.eyePosition()
    const start = this.house.closestNode(this.player.position)
    if (!start) { this.respawnIn = 5; return }
    const minDistance = 12 - clamp(this.night.progress, 0, 1) * 4
    let best: THREE.Vector3 | null = null
    let bestScore = -Infinity
    for (let i = (this.night.random() * 4) | 0; i < this.house.nodes.length; i += 4) {
      const n = this.house.nodes[i]
      if (n.component !== start.component) continue
      const sameLevel = Math.abs(n.p.y - this.player.position.y) < 1.5
      const d = n.p.distanceTo(this.player.position)
      if (sameLevel && d < minDistance) continue
      if (this.house.visible(eye, n.p.clone().add(new THREE.Vector3(0, 1.8, 0)))) continue
      const dark = 1 - clamp(this.lights.brightness(n.p.clone().add(new THREE.Vector3(0, 1, 0))) * 3, 0, 1)
      const score = dark * 1.5 + this.night.random() + Math.min(d, 18) * 0.04
      if (score > bestScore) { bestScore = score; best = n.p }
    }
    if (!best) { this.respawnIn = 5; return }
    this.generation++
    this.applyVariant()
    this.position.copy(best)
    this.mesh.position.copy(best)
    this.mesh.rotation.y = this.night.random() * Math.PI * 2
    this.state = 'roam'
    this.mesh.visible = true
    this.grace = 14
    this.wait = 3 + this.night.random() * 4
    this.unseenThreatFor = 0
    // A manifestation is brief by design: it should feel like the house let us see it by accident.
    this.manifestationFor = 18 + this.night.random() * 18
    this.route = []
    this.waypoint = 0
    this.unseenFor = 99
    this.seenFor = 0
    this.torchFor = 0
    this.audio.play('whisper', best.clone().add(new THREE.Vector3(0, 1.8, 0)), 0.22)
  }

  disturb(position?: THREE.Vector3) {
    if (!this.appeared) return
    if (this.respawnIn > 0 || this.vanishIn > 0) return
    if (this.state === 'dormant') {
      const eye = this.headPoint()
      if (this.house.visible(this.player.eyePosition(), eye)) return
      this.state = 'roam'
      this.mesh.visible = true
    }
    if (this.state === 'retreat' || this.state === 'hunt' || this.state === 'stare' || this.state === 'devour' || this.grace > 0) return
    if (position && position.distanceTo(this.position) < 19 && this.house.occlusion(position.clone().add(new THREE.Vector3(0, 1, 0)), this.position.clone().add(new THREE.Vector3(0, 1, 0)), false) < 3) {
      this.state = 'search'
      this.plan(position)
    } else if (!this.route.length) this.chooseDestination()
  }

  /** It does not flee. It turns its back and leaves, slowly, and comes back later. */
  retreat() {
    this.state = 'retreat'
    this.grace = 26
    this.seenFor = 0
    this.torchFor = 0
    this.chooseDestination(true)
  }

  /* ------------------------------------------------------------ frame update */

  tick(dt: number, tension: number, observed: (point: THREE.Vector3) => boolean, via: SightContext) {
    this.grace = Math.max(0, this.grace - dt)
    this.encounterCooldown = Math.max(0, this.encounterCooldown - dt)
    if (this.state === 'devour') return false
    if (this.vanishIn > 0) {
      this.vanishIn -= dt
      this.clock += dt
      // The shape stutters out with the lights.
      this.mesh.visible = this.vanishIn > 0 && Math.sin(this.clock * 70) > -0.2
      this.audio.setPresence(0, this.position)
      this.lights.presence = 0
      if (this.vanishIn <= 0) {
        this.state = 'dormant'
        this.mesh.visible = false
        this.route = []
        this.waypoint = 0
        this.unseenThreatFor = 0
        this.manifestationFor = 0
      }
      return false
    }
    if (this.state === 'dormant') {
      // At 01:00, and not a minute before, it comes.
      if (!this.appeared && this.night.status === 'active' && this.night.progress >= ENTITY_START) {
        this.appeared = true
        this.respawnIn = 6 + this.night.random() * 16
      }
      if (this.respawnIn > 0 && this.night.status === 'active') {
        this.respawnIn -= dt
        if (this.respawnIn <= 0) this.respawn()
      }
      this.audio.setPresence(0, this.position)
      this.lights.presence = 0
      return false
    }
    this.mesh.visible = true
    this.routeTimer -= dt
    const phase = this.night.phase
    const closeness = clamp(this.night.progress * 1.15 + tension * 0.3, 0, 1)
    const head = this.headPoint()
    const mid = this.position.clone().add(new THREE.Vector3(0, 1.2 * this.mesh.scale.y, 0))
    const playerEye = this.player.eyePosition()
    const distance = this.position.distanceTo(this.player.position)
    const direct = distance < 18 && this.house.visible(head, playerEye)
    const seen = observed(head) || observed(mid)

    // The creature should not remain permanently on stage. It manifests, walks a little,
    // then folds back into the house. Missing it is dangerous: after a full minute unseen,
    // it stops behaving like a harmless apparition and starts a direct hunt.
    if (seen) this.unseenThreatFor = 0
    else this.unseenThreatFor += dt
    if (this.state !== 'hunt' && this.state !== 'stare' && this.unseenThreatFor >= 60 && this.night.status === 'active') {
      this.unseenThreatFor = 0
      this.manifestationFor = 0
      this.audio.play('roar', this.headPoint(), 0.72)
      this.audio.play('scream', this.headPoint(), 0.78)
      this.startChase()
    }
    if (this.state !== 'hunt' && this.state !== 'stare' && this.manifestationFor > 0) {
      this.manifestationFor -= dt
      if (this.manifestationFor <= 0) {
        // If the player never reported a sighting, the next appearance is more hostile.
        this.retreat()
        this.vanishIn = 0.65
        this.respawnIn = 32 + this.night.random() * 22
        this.audio.play('glitch', undefined, 0.35 + Math.min(0.35, this.strikes * 0.08))
      }
    }

    if (seen) {
      const returning = this.unseenFor > 5
      if (returning && this.state !== 'hunt') this.sight = true
      this.unseenFor = 0
      this.lastSeenAt = this.night.elapsed
      this.lastSeenRoom = this.house.roomAt(this.position)?.id ?? ''
      this.seenFor += dt
      if (this.player.flashlight) this.torchFor += dt
      if (returning && this.state !== 'stare' && this.state !== 'hunt' && this.encounterCooldown <= 0) this.onEncounter(via)
    } else {
      this.unseenFor += dt
      this.seenFor = Math.max(0, this.seenFor - dt)
      this.torchFor = Math.max(0, this.torchFor - dt)
    }

    // Behaviour. Staring is rooted to the spot; the chase is a straight run at the player.
    if (this.state === 'stare') {
      this.stareTime += dt
      if (this.stareTime >= this.stareDuration) {
        if (this.stareThen === 'chase') this.startChase()
        else { this.encounterCooldown = 25; this.retreat() }
      }
    } else if (this.state === 'hunt') {
      this.chaseLeft -= dt
      if (this.chaseLeft <= 0) {
        this.chaseLeft = 0
        this.events.push({ type: 'chaseEnd' })
        this.state = 'dormant'
        return false
      }
      if (this.routeTimer <= 0) this.plan(this.player.position, 0.4)
    } else if (this.state === 'watch') {
      this.watchTime += dt
      if ((!seen && this.unseenFor > 16) || this.watchTime > 50) this.stalkCloser(closeness)
      else if (seen && this.encounterCooldown > 0 && (this.torchFor > 1.9 || this.seenFor > 3.4)) this.retreat()
    } else if (this.state !== 'retreat' && distance < 2.8 && direct) {
      this.retreat()
    }

    // Movement: this frame's distance is spent across as many waypoints as it covers,
    // so the speed is the speed, whatever the spacing of the grid.
    let moving = 0
    if (this.state !== 'watch' && this.state !== 'stare') {
      if (this.waypoint >= this.route.length) {
        if (this.state === 'stalk') this.beginWatch()
        else if (this.state !== 'hunt') {
          this.wait -= dt
          if (this.wait <= 0) {
            this.wait = 8 + this.night.random() * 20
            if (phase >= 2 && this.grace === 0 && this.night.random() < 0.55) this.stalkCloser(closeness)
            else { this.state = 'roam'; this.chooseDestination() }
          }
        }
      } else {
        if (this.burst > 0) this.burst -= dt
        else if (!seen && distance > 5 && (this.state === 'roam' || this.state === 'stalk') && phase >= 3 && this.night.random() < dt * 0.012) this.burst = 1.4
        const speed = this.state === 'hunt' ? CHASE_SPEED
          : this.state === 'retreat' ? 1.25
          : this.burst > 0 && !seen ? 2.3
          : this.state === 'stalk' ? 0.8 + closeness * 0.4
          : this.state === 'search' ? 0.85 + phase * 0.04
          : 0.55 + phase * 0.045
        let remaining = dt * speed
        let travelled = 0
        for (let guard = 0; remaining > 1e-4 && this.waypoint < this.route.length && guard < 10; guard++) {
          const next = this.route[this.waypoint]
          const door = this.house.doorNear(next, 0.5)
          if (door && door.t < 0.7 && next.distanceTo(this.position) < 1.15) {
            if (!door.open) this.doors.set(door, true, this.state !== 'hunt')
            break
          }
          const direction = next.clone().sub(this.position)
          const length = direction.length()
          if (length < 0.02) { this.waypoint++; continue }
          const step = Math.min(length, remaining)
          const candidate = this.position.clone().addScaledVector(direction, step / length)
          if (this.house.blocked(candidate.x, candidate.y, candidate.z, 0.17, false, 1.8)) {
            if (this.routeTimer <= 0) {
              if (this.state === 'hunt') this.plan(this.player.position, 0.4)
              else this.chooseDestination(this.state === 'retreat')
            }
            break
          }
          this.position.copy(candidate)
          remaining -= step
          travelled += step
          if (step >= length - 1e-4) this.waypoint++
          const angle = Math.atan2(-direction.x, -direction.z)
          this.mesh.rotation.y += wrap(angle - this.mesh.rotation.y) * Math.min(1, dt * (this.state === 'hunt' ? 10 : 5))
        }
        if (travelled > 0) {
          moving = travelled / Math.max(dt, 1e-4)
          this.footstep += travelled
          if (this.footstep > (this.state === 'hunt' ? 1.5 : 0.93)) {
            this.footstep = 0
            this.audio.play('bonestep', this.position.clone().add(new THREE.Vector3(0, 0.1, 0)), this.state === 'hunt' ? 0.95 : speed > 2 ? 0.7 : 0.5)
          }
        }
      }
    }

    // Standing still, the body slowly turns to what it watches. The head gets there first.
    const lookAt = this.state === 'stare' && this.stareCamera ? this.stareAt : direct && distance < 18 ? playerEye : null
    if (moving === 0 && lookAt) {
      const facing = Math.atan2(-(lookAt.x - this.position.x), -(lookAt.z - this.position.z))
      this.mesh.rotation.y += wrap(facing - this.mesh.rotation.y) * Math.min(1, dt * (this.state === 'stare' ? 2.2 : this.state === 'watch' ? 0.9 : 0.5))
    }

    // It is far too tall for the doorways: it bends double to pass through them.
    this.stareP = this.state === 'stare' ? clamp(this.stareTime / this.stareDuration, 0, 1) : 0
    const bending = this.state === 'hunt' ? 1 : this.state === 'stare' ? this.stareP * 0.32 : this.house.doorNear(this.position, 1.15) ? 0.45 : 0
    this.pose(dt, moving, lookAt, this.state === 'hunt' ? 'chase' : this.state === 'stare' || this.state === 'watch' ? 'stare' : 'idle', bending)

    // Eyes catch the torch like an animal's: only when the beam is on it and it looks back.
    const toHead = head.clone().sub(playerEye)
    const d = Math.max(0.001, toHead.length())
    toHead.divideScalar(d)
    const forward = new THREE.Vector3(-Math.sin(this.player.yaw) * Math.cos(this.player.pitch), Math.sin(this.player.pitch), -Math.cos(this.player.yaw) * Math.cos(this.player.pitch))
    const beam = this.player.flashlight && this.player.battery > 0 ? smooth(forward.dot(toHead), 0.93, 0.985) : 0
    const entityForward = new THREE.Vector3(-Math.sin(this.mesh.rotation.y), 0, -Math.cos(this.mesh.rotation.y))
    const looking = clamp(entityForward.dot(new THREE.Vector3(-toHead.x, 0, -toHead.z).normalize()), 0, 1)
    const shine = direct && d < 20 ? beam * looking : 0
    this.eyeShine.opacity += (shine * 0.95 - this.eyeShine.opacity) * Math.min(1, dt * 8)

    // Its presence is felt before it is seen: a low pressure in the sound, a tired torch, a lamp that flinches.
    const closeness01 = clamp((12 - distance) / 12, 0, 1)
    this.audio.setPresence(closeness01 * closeness01, head)
    this.lights.presence = clamp((8 - distance) / 8, 0, 1) ** 2
    this.flickerTimer -= dt
    if (this.flickerTimer <= 0) {
      this.flickerTimer = this.state === 'hunt' ? 0.5 : 1.2 + this.rand() * 2.5
      if (distance < 11 && this.rand() < (this.state === 'hunt' ? 0.8 : 0.5)) {
        const here = this.house.roomAt(this.position)
        const there = this.house.roomAt(this.player.position)
        if (here) this.lights.flicker(here.id, 0.25 + this.rand() * 0.35)
        if (there && there.id !== here?.id && this.rand() < 0.35) this.lights.flicker(there.id, 0.2)
      }
    }

    // Voices and breath, never on a schedule the player can learn. In the chase it screams.
    if (this.state === 'hunt') {
      this.screamTimer -= dt
      if (this.screamTimer <= 0) {
        this.screamTimer = 1.5 + this.rand() * 0.9
        this.audio.play('scream', head, 1)
      }
    }
    this.whisperTimer -= dt
    if (this.whisperTimer <= 0) {
      this.whisperTimer = 20 + this.rand() * 30
      if (distance < 16 && this.state !== 'hunt') {
        this.audio.play(this.rand() < 0.4 ? 'whisperRev' : 'whisper', head, 0.28)
        if (this.rand() < 0.72) {
          const phrases = ["Je suis derrière toi.", "J'arrive.", "Chut...", "Tu ne m'as pas vu.", "J'espère que tu vas sortir."]
          this.audio.whisperPhrase(phrases[Math.floor(this.rand() * phrases.length)], 0.18 + this.strikes * 0.025)
        }
      }
    }
    // Staring, it clicks its tongue, and it does so faster the longer the stare goes on.
    if (this.state === 'stare') {
      this.clickTimer -= dt
      if (this.clickTimer <= 0) {
        this.clickTimer = (2.6 - this.stareP * 1.6) + this.rand() * 1.4
        this.audio.play('clicks', head, 0.5)
      }
    }
    // Out of sight but not far, something heavy is dragged along a floor.
    this.dragTimer -= dt
    if (this.dragTimer <= 0) {
      this.dragTimer = 40 + this.rand() * 50
      if (distance < 15 && !seen && this.state !== 'hunt' && this.state !== 'stare') this.audio.play('drag', this.position.clone().add(new THREE.Vector3(0, 0.2, 0)), 0.32)
    }
    this.raspTimer -= dt
    if (this.raspTimer <= 0) {
      this.raspTimer = this.state === 'hunt' ? 1.2 : this.state === 'stare' ? 3.4 : 4.5 + this.rand() * 3
      if (this.state === 'hunt') this.audio.play('rasp', head, 0.7)
      else if (distance < 8) this.audio.play('rasp', head, this.state === 'stare' ? 0.34 : 0.28)
    }

    return this.state === 'hunt' && distance < 0.95 && direct && this.night.status === 'active'
  }

  /** When it has the player: it walks up, tall and unhurried, and stops very close. */
  captureStep(dt: number) {
    const to = this.player.position.clone().sub(this.position)
    to.y = 0
    const d = to.length()
    let moving = 0
    if (d > 0.95) {
      this.position.addScaledVector(to, (dt * 1.4) / d)
      moving = 1.4
    }
    const facing = Math.atan2(-to.x, -to.z)
    this.mesh.rotation.y += wrap(facing - this.mesh.rotation.y) * Math.min(1, dt * 8)
    this.pose(dt, moving, this.player.eyePosition(), 'stare', 0)
  }

  private pose(dt: number, speed: number, lookAt: THREE.Vector3 | null, mode: 'idle' | 'stare' | 'chase', crouchTarget: number) {
    this.clock += dt
    const rand = this.rand

    if (mode === 'chase') {
      // A stop-motion gallop on all fours: the pose refreshes about thirteen times a second, freezes
      // without warning, and nothing in it is quite human.
      this.stutter -= dt
      if (this.stutter > 0) return
      if (rand() < dt * 2.2) { this.stutter = 0.05 + rand() * 0.2; return }
      this.stepClock += dt
      if (this.stepClock < 0.075) return
      this.stepClock = 0
      this.phase += 0.9 + rand() * 0.9
      const s = Math.sin(this.phase)
      const co = Math.cos(this.phase)
      this.crouch = 0.6
      this.body.position.y = 0.98 + Math.abs(s) * 0.1 + (rand() - 0.5) * 0.04
      this.spine.rotation.set(-(1.05 + rand() * 0.22), (rand() - 0.5) * 0.5, (rand() - 0.5) * 0.5 + s * 0.12)
      this.spine.scale.set(1 + (rand() - 0.5) * 0.08, 1 + (rand() - 0.5) * 0.12, 1)
      this.legs.forEach((leg, i) => {
        const o = i ? s : -s
        leg.hip.rotation.x = o * 1.0 + 0.45
        leg.knee.rotation.x = -(0.8 + (i ? co : -co) * 0.45 + rand() * 0.3)
      })
      this.arms.forEach((arm, i) => {
        const side = i === 0 ? 1 : -1
        const o = i ? -s : s
        arm.shoulder.visible = true
        arm.shoulder.rotation.x = 1.2 + o * 0.75 + rand() * 0.25
        arm.shoulder.rotation.z = side * (0.12 + rand() * 0.4)
        arm.elbow.rotation.x = 0.15 + Math.max(0, o) * 0.8
        arm.hand.fingers.forEach((joints) => joints.forEach((j, k) => { j.rotation.x = 0.1 + rand() * 0.5 + k * 0.1 }))
        arm.hand.thumb.forEach((j) => { j.rotation.x = rand() * 0.7 })
      })
      this.strips.forEach((strip) => { strip.rotation.x = -(0.8 + rand() * 0.7) })
      this.hair.rotation.x = -0.5 - rand() * 0.5
      this.neck.scale.set(1, 1.15, 1)
      this.neck.rotation.set(0.95 + rand() * 0.25, (rand() - 0.5) * 0.6, (rand() - 0.5) * 0.4)
      this.head.rotation.set(0.05 + (rand() - 0.5) * 0.4, (rand() - 0.5) * 0.7, (rand() > 0.5 ? 1 : -1) * (0.3 + rand() * 0.8))
      this.jaw = 1.0 + rand() * 0.55
      this.applyJaw(this.jaw)
      // The model tears and jumps on screen: random stretch, random offset.
      const stretch = rand() < 0.14
      this.mesh.scale.set(this.baseScale.x * (stretch ? 1.35 : 1), this.baseScale.y * (stretch ? 0.92 : 1), this.baseScale.z)
      this.mesh.position.copy(this.position).add(new THREE.Vector3((rand() - 0.5) * 0.18, 0, (rand() - 0.5) * 0.18))
      return
    }
    this.mesh.scale.copy(this.baseScale)

    this.crouch += (crouchTarget - this.crouch) * Math.min(1, dt * 4.5)
    this.speed += (speed - this.speed) * Math.min(1, dt * 6)
    if (this.speed > 0.05) this.phase += dt * (3.2 + this.speed * 2.2)
    const w = clamp(this.speed / 1.1, 0, 1)
    const fast = clamp(this.speed / 2.6, 0, 1)
    const c = this.crouch
    const t = this.clock
    // A walk like a puppet's: the limbs hold each pose, then jump to the next.
    const ph = this.speed > 0.05 ? Math.round(this.phase * 2.4) / 2.4 : this.phase
    const watching = mode === 'stare'
    const sp = this.stareP

    this.twitchTimer -= dt
    if (this.twitchTimer <= 0) {
      this.twitchTimer = 1.2 + rand() * 3.5
      this.twitch = 0.14
    }
    this.twitch = Math.max(0, this.twitch - dt)
    const tw = this.twitch > 0 ? 1 : 0

    this.body.position.y = 1.22 - c * 0.3 + Math.abs(Math.sin(ph)) * 0.025 * w
    this.spine.rotation.x = -(0.1 + c * 0.85 + w * 0.05 + sp * 0.3)
    this.spine.rotation.y = 0
    // Staring, it begins to shake: first a tremor, then a convulsion that builds until it moves.
    this.spine.rotation.z = Math.sin(ph) * 0.05 * w + Math.sin(t * 0.5) * 0.015 + Math.sin(t * 58) * 0.02 * sp * sp * (this.strikes >= 2 ? 1.7 : 1)
    const breath = Math.sin(t * 1.4)
    this.spine.scale.set(1 + breath * 0.012, 1 + breath * 0.01, 1 + breath * 0.022)

    this.legs.forEach((leg, i) => {
      const off = i === 0 ? 0 : Math.PI
      const swing = Math.sin(ph + off)
      const lift = Math.max(0, Math.sin(ph + off + 1.3))
      leg.hip.rotation.x = swing * 0.5 * w + 0.9 * c
      leg.knee.rotation.x = -(lift * 0.85 * w + 1.4 * c)
    })

    this.arms.forEach((arm, i) => {
      const side = i === 0 ? 1 : -1
      const swing = Math.sin(ph + (i === 0 ? Math.PI : 0))
      arm.shoulder.rotation.x = swing * 0.3 * w + c * (0.95 + swing * 0.5 * fast) + sp * 0.55
      arm.shoulder.rotation.z = side * (0.07 + Math.sin(t * 0.6 + i) * 0.02)
      arm.elbow.rotation.x = 0.12 + c * 0.35 + Math.sin(t * 0.9 + i * 2) * 0.03
      arm.hand.fingers.forEach((joints, f) => joints.forEach((j, k) => {
        j.rotation.x = 0.22 + k * 0.16 + Math.sin(t * (0.7 + sp * 3) + f + k * 0.5 + i * 2) * (0.1 + sp * 0.3) + tw * (0.3 - k * 0.06) + c * 0.2
      }))
      arm.hand.thumb.forEach((j, k) => { j.rotation.x = 0.2 + k * 0.2 + Math.sin(t * 0.8 + i) * 0.06 })
    })

    this.strips.forEach((strip, i) => {
      strip.rotation.x = -((strip.userData.base as number) + Math.sin(t * 1.3 + i * 0.9) * 0.05 + w * 0.18 + c * 0.25)
    })
    this.hair.rotation.x = Math.sin(t * 1.1) * 0.03 + w * 0.08

    // The head moves in jerks: it holds, then snaps to what it wants to look at.
    let yawTarget = Math.sin(t * 0.3) * 0.3
    let pitchTarget = -0.1
    if (lookAt) {
      const dx = lookAt.x - this.position.x
      const dz = lookAt.z - this.position.z
      yawTarget = clamp(wrap(Math.atan2(-dx, -dz) - this.mesh.rotation.y), -2.0, 2.0)
      pitchTarget = clamp(Math.atan2(lookAt.y - (this.position.y + this.headHeight()), Math.hypot(dx, dz)), -0.55, 0.6)
    }
    const snap = Math.abs(yawTarget - this.headYaw) > 0.4
    this.headYaw += (yawTarget - this.headYaw) * Math.min(1, dt * (snap ? 16 : 1.6))
    this.headPitch += (pitchTarget - this.headPitch) * Math.min(1, dt * (snap ? 12 : 2))
    const rollTarget = watching ? 0.42 + Math.sin(t * 0.5) * 0.14 + sp * 0.55 : 0.1
    this.headRoll += (rollTarget - this.headRoll) * Math.min(1, dt * 2)
    this.neck.scale.set(1, 1 + sp * 0.35, 1)
    this.neck.rotation.set(this.headPitch * 0.4 + c * 0.5, this.headYaw * 0.4, 0)
    this.head.rotation.set(this.headPitch * 0.6 + c * 0.4 - 0.12 * (1 - c), this.headYaw * 0.6 + tw * 0.08, this.headRoll + tw * 0.1)

    // The jaw hangs slack while it watches, and drops a little when the torch finds it.
    const jawTarget = watching ? 0.22 + this.eyeShine.opacity * 0.4 + sp * (this.strikes >= 3 ? 1.15 : 0.6) : 0
    this.jaw += (jawTarget - this.jaw) * Math.min(1, dt * 3)
    this.applyJaw(this.jaw + tw * 0.06)

    this.mesh.position.copy(this.position)
    if (sp > 0.3) this.mesh.position.add(new THREE.Vector3((rand() - 0.5) * 0.03 * sp * sp, 0, (rand() - 0.5) * 0.03 * sp * sp))
  }

  /** The kill begins: it is within reach; it takes up its place in front of the player, facing them. */
  beginDeath() {
    this.state = 'devour'
    this.mesh.visible = true
    this.route = []
    this.waypoint = 0
    const to = this.player.position.clone().sub(this.position)
    to.y = 0
    if (to.lengthSq() < 1e-6) to.set(0, 0, -1)
    to.normalize()
    this.position.copy(this.player.position).addScaledVector(to, -0.95)
    this.position.y = this.player.position.y
    this.mesh.rotation.y = Math.atan2(-to.x, -to.z)
    this.mesh.scale.copy(this.baseScale)
    this.mesh.position.copy(this.position)
    this.audio.setPresence(0, this.position)
    this.lights.presence = 1
  }

  /** `open`: 0 shut, 1 wide, 1.6 dislocated. The jaw drops and stretches, the mouth fills with tongue and teeth. */
  private applyJaw(open: number) {
    this.jawGroup.rotation.x = -open * 0.7
    this.jawGroup.position.set(0, 0.1 - open * 0.032, -0.012 - open * 0.018)
    this.jawGroup.scale.set(1 + open * 0.12, 1 + open * 0.3, 1 + open * 0.22)
    this.cavity.scale.set(0.05 * (1 + open * 0.3), 0.0175 + open * 0.058, 0.025 + open * 0.01)
    this.tongue.visible = open > 0.12
    for (const d of this.drool) d.scale.y = clamp(open * 1.4 - 0.2, 0.05, 2.4)
  }

  /**
   * One frame of the kill, `t` seconds in. It throws itself forward, its hands close on the view, lifts
   * it to the height of its face, the jaw comes apart and the view is drawn into the mouth. Returns the
   * camera to use, and how black and how red the screen should be.
   */
  deathFrame(dt: number, t: number, eye0: THREE.Vector3, calm: boolean) {
    const ease = (x: number) => { const k = clamp(x, 0, 1); return k * k * (3 - 2 * k) }
    const r = this.rand
    this.clock += dt
    const lunge = ease(t / 0.45)
    const lift = ease((t - 0.5) / 2.9)
    const bite = ease((t - 3.4) / 1.1)
    const thrash = bite * (calm ? 0.4 : 1)
    this.speed = 0
    this.crouch = 0.15 + lunge * 0.35
    this.body.position.y = 1.22 - lunge * 0.3 - lift * 0.08
    this.spine.rotation.set(-(0.1 + lunge * 0.62 + lift * 0.2), Math.sin(this.clock * 17) * 0.06 * lift, Math.sin(this.clock * 29) * 0.04 * lift + thrash * Math.sin(this.clock * 23) * 0.12)
    this.spine.scale.set(1, 1, 1)
    this.legs.forEach((leg, i) => { leg.hip.rotation.x = (i ? 0.6 : 0.4) * lunge; leg.knee.rotation.x = -0.9 * lunge })
    this.arms.forEach((arm, i) => {
      const side = i === 0 ? 1 : -1
      // Its own arms reach out for the first half second; after that, the hands on the screen are its hands.
      arm.shoulder.visible = t < 0.5
      arm.shoulder.rotation.x = 0.5 + lunge * 1.15
      arm.shoulder.rotation.z = side * (0.08 + lunge * 0.4)
      arm.elbow.rotation.x = 0.15 + lunge * 0.2
      arm.hand.fingers.forEach((joints) => joints.forEach((j, k) => { j.rotation.x = 0.25 + lunge * (0.7 - k * 0.15) }))
    })
    this.strips.forEach((strip) => { strip.rotation.x = -(0.7 + r() * 0.5) })
    this.hair.rotation.x = Math.sin(this.clock * 31) * 0.1
    this.neck.scale.set(1, 1 + lift * 0.45, 1)
    this.neck.rotation.set(0.2 + lift * 0.45, Math.sin(this.clock * 9) * 0.08 * lift, 0)
    this.head.rotation.set(
      0.22 + lift * 0.5 + bite * 0.15,
      Math.sin(this.clock * 13) * 0.12 * lift + thrash * Math.sin(this.clock * 37) * 0.22,
      0.2 + Math.sin(this.clock * 5) * 0.1 + thrash * Math.sin(this.clock * 29) * 0.3,
    )
    this.jaw = clamp(0.35 + lunge * 0.55 + lift * 0.55 + bite * 0.15, 0, 1.6)
    this.applyJaw(this.jaw)
    this.mesh.position.copy(this.position)
    this.mesh.updateMatrixWorld(true)

    // The view is drawn toward the mouth, then into it.
    const A = this._a
    const F = this._f
    this.mouthAnchor.getWorldPosition(A)
    this.head.getWorldQuaternion(this._q)
    F.set(0, 0, -1).applyQuaternion(this._q)
    const target = A.clone().addScaledVector(F, 0.27 - bite * 0.38)
    const pos = eye0.clone().lerp(target, lift)
    const shake = (calm ? 0.3 : 1) * (0.008 + lunge * 0.014 + lift * 0.022 + bite * 0.03)
    pos.x += (r() - 0.5) * shake
    pos.y += (r() - 0.5) * shake
    pos.z += (r() - 0.5) * shake
    const look = A.clone().addScaledVector(F, -0.32 * bite)

    // The hands slam in at the sides of the view and close.
    const grip = ease((t - 0.5) / 0.14)
    const squeeze = 0.45 + ease((t - 0.7) / 1.2) * 0.8
    this.grabGroup.visible = t >= 0.48
    this.grabLight.intensity = grip * (calm ? 1.6 : 2.6)
    this.grab.forEach((g) => {
      g.holder.position.set(g.side * (0.43 - squeeze * 0.06 + Math.sin(this.clock * 21) * 0.006 * lift), -0.98 + grip * 0.74, -0.44 + (1 - grip) * 0.2)
      g.hand.fingers.forEach((joints, f) => joints.forEach((j, k) => { j.rotation.x = 0.15 + squeeze * 0.75 + k * 0.3 + f * 0.03 }))
      g.hand.thumb.forEach((j, k) => { j.rotation.x = 0.4 + squeeze * 0.6 + k * 0.2 })
    })

    return {
      pos,
      look,
      roll: lift * 0.3 + (t < 0.5 ? (r() - 0.5) * 0.12 * (calm ? 0.3 : 1) : Math.sin(this.clock * 7) * 0.05 * lift),
      fov: lunge * 26 - bite * 34,
      fade: ease((t - 4.35) / 0.45),
      blood: ease((t - 3.5) / 1.3) * 0.92,
    }
  }

  /* ------------------------------------------------------------ persistence */

  save() {
    return { position: this.position.toArray(), state: this.state, grace: this.grace, respawn: this.respawnIn, strikes: this.strikes, sightings: this.sightings, appeared: this.appeared, unseenThreatFor: this.unseenThreatFor, manifestationFor: this.manifestationFor }
  }

  restore(data: ReturnType<EntitySystem['save']> & { respawn?: number; strikes?: number; sightings?: { room: string; at: number }[] }) {
    this.respawnIn = data.respawn ?? 0
    this.vanishIn = 0
    this.unseenThreatFor = (data as { unseenThreatFor?: number }).unseenThreatFor ?? 0
    this.manifestationFor = (data as { manifestationFor?: number }).manifestationFor ?? 0
    this.appeared = (data as { appeared?: boolean }).appeared ?? this.night.progress >= ENTITY_START
    this.strikes = Math.min(3, data.strikes ?? 0)
    this.sightings = data.sightings ?? []
    const p = new THREE.Vector3(...data.position as [number, number, number])
    this.position.copy(this.house.closestNode(p)?.p ?? p)
    this.mesh.position.copy(this.position)
    const interrupted = data.state === 'hunt' || data.state === 'watch' || data.state === 'stalk' || data.state === 'stare' || data.state === 'devour'
    this.state = interrupted ? 'roam' : data.state
    this.mesh.visible = this.state !== 'dormant'
    this.grace = Math.max(data.grace, 12)
    if (this.state !== 'dormant') this.chooseDestination()
    else if (this.appeared && this.respawnIn <= 0) this.respawnIn = 15 + this.night.random() * 15
  }
}
