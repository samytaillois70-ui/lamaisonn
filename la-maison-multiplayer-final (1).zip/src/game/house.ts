import * as THREE from 'three'
import type { Collider, HouseObject } from './builder'
import type { DoorObj, RoomRect, World } from './world'

export interface HouseRoom {
  id: string
  name: string
  level: number
  areas: RoomRect[]
  center: THREE.Vector3
  area: number
  objects: HouseObject[]
  nodes: number[]
  connections: Set<string>
  visited: boolean
  purpose: string
}

export interface NavNode {
  id: number
  p: THREE.Vector3
  neighbors: number[]
  room: string
  component: number
}

const PURPOSES: Record<string, string> = {
  Salon: 'Trois livres sont sur la table basse, dont un petit rouge. La télévision est éteinte, diode rouge allumée.',
  Cuisine: 'Trois tabourets en cuir cognac, alignés devant l’îlot. Le réfrigérateur bourdonne parfois.',
  'Hall d’entrée & escalier': 'Le terminal reste alimenté. La porte d’entrée est verrouillée pour la nuit.',
  "Hall d'entrée & escalier": 'Le terminal reste alimenté. La porte d’entrée est verrouillée pour la nuit.',
  Garage: 'La voiture ne bouge pas. Le coffre à outils rouge, à cinq tiroirs, est près de l’établi.',
  Buanderie: 'Le panier blanc contient une serviette bleue. Le chargeur est sur le plan de travail.',
  WC: 'Un petit espace pour reprendre son souffle. Une porte fermée atténue les sons.',
  'Couloir étage': 'Les cadres sont droits, avec leur passe-partout clair. Le palier relie les chambres et la salle de bain.',
  'Chambre amie': 'La chaise noire à roulettes fait face au bureau. L’armoire masque une partie de la pièce.',
  'Salle de bain': 'La serviette grise à bandes bleues est sur son anneau. Le rideau de douche reste tiré.',
  'Suite parentale': 'Deux cadres au-dessus du lit. Le fauteuil bleu porte un coussin crème.',
  Dressing: 'La boîte à bijoux en bois, fermoir en laiton, est sur l’îlot. Les armoires créent des angles morts.',
  'Sous-sol': 'Les cartons étiquetés et le bac bleu sont contre le mur. Le bois de l’escalier craque naturellement.',
  'Local technique': 'Le disjoncteur commande les lumières. Le terminal a une alimentation de secours.',
  'Escalier sous-sol': 'Le seul passage entre le garage et le sous-sol. Écoutez avant de descendre.',
}

export function pointIn(c: Collider, x: number, y: number, z: number, radius = 0.2, height = 1.72) {
  return c.active && y < c.y1 - 0.08 && y + height > c.y0 + 0.08 && x + radius > c.x1 && x - radius < c.x2 && z + radius > c.z1 && z - radius < c.z2
}

// A segment test is shared by sight, interactions and sound occlusion.
export function segmentBox(a: THREE.Vector3, end: THREE.Vector3, min: THREE.Vector3, max: THREE.Vector3) {
  let enter = 0.004
  let exit = 0.996
  for (const axis of ['x', 'y', 'z'] as const) {
    const delta = end[axis] - a[axis]
    if (Math.abs(delta) < 1e-7) {
      if (a[axis] < min[axis] || a[axis] > max[axis]) return false
    } else {
      const t1 = (min[axis] - a[axis]) / delta
      const t2 = (max[axis] - a[axis]) / delta
      enter = Math.max(enter, Math.min(t1, t2))
      exit = Math.min(exit, Math.max(t1, t2))
      if (enter > exit) return false
    }
  }
  return true
}

export class HouseSystem {
  rooms: HouseRoom[] = []
  nodes: NavNode[] = []
  doorSet: Set<Collider>
  hidingSpots: THREE.Vector3[] = []
  sightlines: { from: THREE.Vector3; to: THREE.Vector3; room: string }[] = []
  private columns = new Map<string, number[]>()
  private bins = new Map<string, Collider[]>()
  private readonly min = new THREE.Vector3()
  private readonly max = new THREE.Vector3()
  readonly step = 0.25
  readonly architectureSignature: string

  constructor(public readonly world: World) {
    this.doorSet = new Set(world.doors.map((d) => d.collider))
    const groups = new Map<string, RoomRect[]>()
    for (const r of world.rooms.filter((r) => r.name !== 'Porche')) {
      const id = `${r.level}-${r.name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-')}`
      const areas = groups.get(id) ?? []
      areas.push(r)
      groups.set(id, areas)
    }
    groups.forEach((areas, id) => {
      const r = areas[0]
      this.rooms.push({ id, name: r.name, level: r.level, areas,
        center: new THREE.Vector3((r.x1 + r.x2) / 2, r.level * 3, (r.z1 + r.z2) / 2),
        area: areas.reduce((sum, a) => sum + (a.x2 - a.x1) * (a.z2 - a.z1), 0),
        objects: [], nodes: [], connections: new Set(), visited: false,
        purpose: PURPOSES[r.name] ?? 'Observez cet espace avant de poursuivre votre ronde.',
      })
    })
    world.objects.forEach((o) => this.roomForPoint(o.origin)?.objects.push(o))
    for (const d of world.doors) d.locked = d.kind === 'garage' || d.name === "Porte d'entrée"
    this.architectureSignature = JSON.stringify({ rooms: world.rooms, openings: world.openings, surfaces: world.surfaces.map(({ x1, x2, z1, z2, h }) => [x1, x2, z1, z2, h]) })
    this.reindexColliders()
    this.analyzeNavigation()
  }

  roomAt(p: THREE.Vector3, level = Math.max(-1, Math.min(1, Math.round(p.y / 3)))) {
    return this.rooms.find((r) => r.level === level && r.areas.some((a) => p.x >= a.x1 && p.x <= a.x2 && p.z >= a.z1 && p.z <= a.z2))
  }

  roomForPoint(p: THREE.Vector3) {
    return this.roomAt(p, Math.max(-1, Math.min(1, Math.floor((p.y + 0.04) / 3))))
  }

  contains(x: number, z: number, y: number) {
    return this.rooms.some((r) => Math.abs(r.level * 3 - y) < 2.99 && r.areas.some((a) => x >= a.x1 && x <= a.x2 && z >= a.z1 && z <= a.z2))
  }

  ground(x: number, z: number, y: number) {
    let best = -Infinity
    for (const s of this.world.surfaces) {
      if (x < s.x1 || x > s.x2 || z < s.z1 || z > s.z2) continue
      const h = s.fn ? s.fn(x, z) : s.h
      if (h <= y + 0.4 && h > best) best = h
    }
    return best
  }

  reindexColliders() {
    this.bins.clear()
    for (const c of this.world.colliders) {
      if (c.x2 < 0 || c.x1 > 18 || c.z2 < 0 || c.z1 > 9) continue
      for (let x = Math.floor((c.x1 - 0.4) / 2); x <= Math.floor((c.x2 + 0.4) / 2); x++) {
        for (let z = Math.floor((c.z1 - 0.4) / 2); z <= Math.floor((c.z2 + 0.4) / 2); z++) {
          const key = `${x}:${z}`
          const bin = this.bins.get(key) ?? []
          bin.push(c)
          this.bins.set(key, bin)
        }
      }
    }
  }

  nearbyColliders(x: number, z: number) {
    return this.bins.get(`${Math.floor(x / 2)}:${Math.floor(z / 2)}`) ?? []
  }

  blocked(x: number, y: number, z: number, radius = 0.18, ignoreDoors = false, height = 1.7) {
    return this.nearbyColliders(x, z).some((c) => !(ignoreDoors && this.doorSet.has(c)) && pointIn(c, x, y, z, radius, height)) || this.openDoorContact(new THREE.Vector3(x, y, z), radius, height) !== null
  }

  // The original leaf rotates around its hinge. Test its thin oriented volume,
  // rather than treating an open door as non-existent or blocking its whole AABB.
  openDoorContact(p: THREE.Vector3, radius = 0.2, height = 1.78) {
    for (const door of this.world.doors) {
      if (door.kind !== 'door' || door.t < 0.64 || p.y > door.y + 2.05 || p.y + height < door.y + 0.05) continue
      const angle = door.group.rotation.y, cos = Math.cos(angle), sin = Math.sin(angle)
      const dx = p.x - door.group.position.x, dz = p.z - door.group.position.z
      const x = dx * cos - dz * sin, z = dx * sin + dz * cos
      const width = Math.max(door.collider.x2 - door.collider.x1, door.collider.z2 - door.collider.z1) - 0.03
      if (x + radius <= 0 || x - radius >= width || Math.abs(z) >= radius + 0.024) continue
      const penetrations = [x + radius, width - x + radius, z + radius + 0.024, radius + 0.024 - z]
      const smallest = Math.min(...penetrations), axis = penetrations.indexOf(smallest)
      const ox = axis === 0 ? -smallest : axis === 1 ? smallest : 0
      const oz = axis === 2 ? -smallest : axis === 3 ? smallest : 0
      return new THREE.Vector3(ox * cos + oz * sin, 0, -ox * sin + oz * cos)
    }
    return null
  }

  occlusion(a: THREE.Vector3, b: THREE.Vector3, furniture = true) {
    let blocks = 0
    const x1 = Math.min(a.x, b.x), x2 = Math.max(a.x, b.x)
    const z1 = Math.min(a.z, b.z), z2 = Math.max(a.z, b.z)
    for (const c of this.world.colliders) {
      if (!c.active || c.kind === 'window' || c.kind === 'door' || c.x1 > x2 || c.x2 < x1 || c.z1 > z2 || c.z2 < z1) continue
      if (!furniture && c.kind !== 'wall') continue
      this.min.set(c.x1, c.y0, c.z1)
      this.max.set(c.x2, c.y1, c.z2)
      if (segmentBox(a, b, this.min, this.max)) blocks++
      if (blocks >= 4) return blocks
    }
    for (const slab of this.world.slabs) if (segmentBox(a, b, slab.min, slab.max)) blocks++
    for (const d of this.world.doors) {
      if (d.kind === 'garage') {
        const c = d.collider
        if (c.active && segmentBox(a, b, this.min.set(c.x1, c.y0, c.z1), this.max.set(c.x2, c.y1, c.z2))) blocks++
        continue
      }
      const local = new THREE.Matrix4().makeRotationY(-d.group.rotation.y)
      const from = a.clone().sub(d.group.position).applyMatrix4(local)
      const to = b.clone().sub(d.group.position).applyMatrix4(local)
      const width = Math.max(d.collider.x2 - d.collider.x1, d.collider.z2 - d.collider.z1) - 0.03
      if (segmentBox(from, to, this.min.set(0, 0, -0.025), this.max.set(width, 2.1, 0.025))) blocks++
    }
    return blocks
  }

  visible(a: THREE.Vector3, b: THREE.Vector3) { return this.occlusion(a, b) === 0 }

  private analyzeNavigation() {
    const ramps = this.world.surfaces.filter((s) => s.fn)
    for (let ix = 0; ix < 72; ix++) for (let iz = 0; iz < 36; iz++) {
      const x = ix * this.step + 0.125, z = iz * this.step + 0.125
      const heights = new Set<number>()
      const ramp = ramps.find((s) => x >= s.x1 && x <= s.x2 && z >= s.z1 && z <= s.z2)
      for (const s of this.world.surfaces) {
        if (x < s.x1 || x > s.x2 || z < s.z1 || z > s.z2) continue
        const h = s.fn ? s.fn(x, z) : s.h
        if (h > 3.1 || h < -3.1 || !this.contains(x, z, h)) continue
        if (ramp && !s.fn) {
          const low = Math.min(ramp.fn!(ramp.x1, ramp.z1), ramp.fn!(ramp.x2, ramp.z2))
          if (Math.abs(h - low) < 0.15 && ramp.fn!(x, z) > h + 0.03) continue
        }
        heights.add(Number(h.toFixed(4)))
      }
      for (const y of heights) {
        if (this.blocked(x, y, z, 0.18, true)) continue
        const p = new THREE.Vector3(x, y, z)
        const room = this.roomAt(p)
        if (!room) continue
        const id = this.nodes.length
        this.nodes.push({ id, p, neighbors: [], room: room.id, component: -1 })
        room.nodes.push(id)
        const key = `${ix}:${iz}`
        const column = this.columns.get(key) ?? []
        column.push(id)
        this.columns.set(key, column)
      }
    }
    for (const n of this.nodes) {
      const ix = Math.round((n.p.x - 0.125) / this.step), iz = Math.round((n.p.z - 0.125) / this.step)
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        for (const id of this.columns.get(`${ix + dx}:${iz + dz}`) ?? []) {
          const other = this.nodes[id]
          if (Math.abs(other.p.y - n.p.y) > 0.35) continue
          const mid = n.p.clone().lerp(other.p, 0.5)
          if (this.blocked(mid.x, mid.y, mid.z, 0.18, true)) continue
          n.neighbors.push(id)
          if (other.room !== n.room) this.rooms.find((r) => r.id === n.room)?.connections.add(other.room)
        }
      }
    }
    let component = 0
    for (const start of this.nodes) {
      if (start.component >= 0) continue
      const queue = [start.id]
      start.component = component
      for (let head = 0; head < queue.length; head++) {
        for (const id of this.nodes[queue[head]].neighbors) {
          if (this.nodes[id].component >= 0) continue
          this.nodes[id].component = component
          queue.push(id)
        }
      }
      component++
    }
    for (const room of this.rooms) {
      const nearest = this.closestNode(room.center, room.nodes)
      if (nearest) room.center.copy(nearest.p)
      const sample = room.nodes.filter((_, i) => i % 35 === 0)
      for (const id of sample) {
        const node = this.nodes[id]
        const low = node.p.clone().add(new THREE.Vector3(0, 0.7, 0))
        let cover = 0
        for (const direction of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const end = low.clone().add(new THREE.Vector3(direction[0] * 1.8, 0, direction[1] * 1.8))
          if (!this.visible(low, end)) cover++
        }
        if (cover >= 3) this.hidingSpots.push(node.p.clone())
      }
      const a = this.nodes[room.nodes[0]], b = this.nodes[room.nodes[room.nodes.length - 1]]
      if (a && b) {
        const from = a.p.clone().add(new THREE.Vector3(0, 1.6, 0)), to = b.p.clone().add(new THREE.Vector3(0, 1.6, 0))
        if (this.visible(from, to)) this.sightlines.push({ from, to, room: room.id })
      }
    }
  }

  closestNode(p: THREE.Vector3, ids?: number[]) {
    let best: NavNode | undefined
    let distance = Infinity
    for (const entry of ids ?? this.nodes.map((n) => n.id)) {
      const node = this.nodes[entry]
      const score = (node.p.x - p.x) ** 2 + (node.p.z - p.z) ** 2 + (node.p.y - p.y) ** 2 * 8
      if (score < distance) { best = node; distance = score }
    }
    return best
  }

  path(from: THREE.Vector3, to: THREE.Vector3) {
    const start = this.closestNode(from), end = this.closestNode(to)
    if (!start || !end || start.component !== end.component) return []
    const open = new Set([start.id]), came = new Map<number, number>()
    const g = new Map([[start.id, 0]]), f = new Map([[start.id, start.p.distanceTo(end.p)]])
    let budget = 12000
    while (open.size && budget-- > 0) {
      let current = -1, best = Infinity
      open.forEach((id) => { if ((f.get(id) ?? Infinity) < best) { best = f.get(id)!; current = id } })
      if (current === end.id) {
        const result = [end.p.clone()]
        while (came.has(current)) { current = came.get(current)!; result.unshift(this.nodes[current].p.clone()) }
        return result
      }
      open.delete(current)
      for (const id of this.nodes[current].neighbors) {
        const node = this.nodes[id]
        if (this.blocked(node.p.x, node.p.y, node.p.z, 0.17, true)) continue
        const cost = g.get(current)! + this.nodes[current].p.distanceTo(node.p)
        if (cost >= (g.get(id) ?? Infinity)) continue
        came.set(id, current); g.set(id, cost); f.set(id, cost + node.p.distanceTo(end.p)); open.add(id)
      }
    }
    return []
  }

  doorNear(p: THREE.Vector3, radius = 0.85): DoorObj | undefined {
    return this.world.doors.find((d) => !d.locked && Math.abs(d.y - p.y) < 0.7 && Math.hypot(d.x - p.x, d.z - p.z) < radius)
  }

  moveObject(object: HouseObject, offset = new THREE.Vector3(), rotation = 0, visible = true) {
    object.group.position.copy(object.origin).add(offset)
    object.group.rotation.y = rotation
    object.group.visible = visible
    const transform = new THREE.Matrix4().makeRotationY(rotation)
    for (const { live, original } of object.colliders) {
      const box = new THREE.Box3(new THREE.Vector3(original.x1, original.y0, original.z1).sub(object.origin), new THREE.Vector3(original.x2, original.y1, original.z2).sub(object.origin))
      box.applyMatrix4(transform).translate(object.group.position)
      Object.assign(live, { x1: box.min.x, x2: box.max.x, y0: box.min.y, y1: box.max.y, z1: box.min.z, z2: box.max.z, active: visible })
    }
    this.reindexColliders()
  }

  audit() {
    const spawn = this.closestNode(new THREE.Vector3(8.7, 0, 7.8))
    return {
      source: 'Existing house geometry; no replacement layout',
      rooms: this.rooms.map((r) => ({ name: r.name, level: r.level, bounds: r.areas, boundingArea: r.area, walkableArea: Number((r.nodes.length * this.step ** 2).toFixed(2)), ceilingHeight: 2.8, objects: r.objects.map((o) => o.id), connections: [...r.connections], accessible: r.nodes.some((id) => this.nodes[id].component === spawn?.component) })),
      windows: this.world.openings.filter((o) => o.kind === 'window').length,
      doors: this.world.doors.length,
      staircases: this.world.surfaces.filter((s) => s.fn).map((s) => ({ x1: s.x1, x2: s.x2, z1: s.z1, z2: s.z2 })),
      walkableNodes: this.nodes.length,
      hidingCandidates: this.hidingSpots.length,
      sightlines: this.sightlines.length,
      cameras: this.world.cams.map((c) => ({ id: c.id, room: this.roomForPoint(c.pos)?.name ?? 'Exterior', position: c.pos.toArray() })),
    }
  }
}