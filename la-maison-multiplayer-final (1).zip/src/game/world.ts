import * as THREE from 'three'
import { Builder, cm, resetMaterialCache, type Collider, type MatSpec, type Surface, type HouseObject } from './builder'
import { makeTextures } from './textures'
import { createMaterials } from './materials'
import type { Ctx, Facing } from './ctx'
import { furnishGround, furnishUpper, furnishBasement, furnishGarageAndCar } from './rooms'

export interface DoorObj {
  name: string
  kind: 'door' | 'garage'
  group: THREE.Group
  collider: Collider
  open: boolean
  t: number
  theta0: number
  phi: number
  x: number
  z: number
  y: number
  locked?: boolean
  ajar?: number
}

export interface Opening {
  kind: 'door' | 'arch' | 'window' | 'garage'
  position: THREE.Vector3
  axis: 'x' | 'z'
  width: number
  height: number
  floor: number
  inward: number
}
export interface LightSrc {
  pos: THREE.Vector3
  color: THREE.Color
  intensity: number
  dist: number
}
export interface SecCam {
  id: number
  name: string
  zone: string
  pos: THREE.Vector3
  yaw: number
  pitch: number
  fov: number
  ir: boolean
  pan: number
  speed: number
}
export interface Monitor {
  name: string
  x: number
  y: number
  z: number
}
export interface Zone {
  id: number
  name: string
  x: number
  z: number
  lx: number
  lz: number
}
export interface RoomRect {
  name: string
  level: number
  x1: number
  x2: number
  z1: number
  z2: number
}
export interface World {
  root: THREE.Group
  colliders: Collider[]
  surfaces: Surface[]
  doors: DoorObj[]
  lights: LightSrc[]
  zones: Zone[]
  rooms: RoomRect[]
  cams: SecCam[]
  monitors: Monitor[]
  objects: HouseObject[]
  openings: Opening[]
  slabs: THREE.Box3[]
}

interface Op {
  c: number
  w: number
  kind: 'door' | 'arch' | 'window' | 'garage'
  h?: number
  sill?: number
  hinge?: -1 | 1
  side?: -1 | 1
  front?: boolean
  inn?: -1 | 1
  curtain?: number | null
  name?: string
}

// constantes escalier
export const SZ0 = 8.4
export const RUN = 3.9375
export const SZ1 = SZ0 - RUN
export const XW = 6.1

export type WorldProgress = (progress: number, label: string) => void | Promise<void>

const nextPaint = () => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))

export async function buildWorld(onProgress?: WorldProgress): Promise<World> {
  const checkpoint = async (progress: number, label: string) => {
    if (onProgress) await onProgress(progress, label)
    await nextPaint()
  }
  await checkpoint(6, 'Préparation des matériaux')
  resetMaterialCache()
  const T = makeTextures()
  const M = createMaterials(T)
  const colliders: Collider[] = []
  const surfaces: Surface[] = []
  const doors: DoorObj[] = []
  const lights: LightSrc[] = []
  const openings: Opening[] = []
  const slabs: THREE.Box3[] = []
  const root = new THREE.Group()
  const b = new Builder(colliders)

  let rs = 12345
  const rand = () => {
    rs = (rs * 16807) % 2147483647
    return rs / 2147483647
  }

  const addLight = (x: number, y: number, z: number, color = 0xffd8a0, intensity = 16, dist = 10) => {
    const p = new THREE.Vector3(x, y, z).applyMatrix4(b.top)
    lights.push({ pos: p, color: new THREE.Color(color), intensity, dist })
  }
  const block = (x1: number, y0: number, z1: number, x2: number, y1: number, z2: number) => {
    const ox = b.top.elements[12]
    const oy = b.top.elements[13]
    const oz = b.top.elements[14]
    colliders.push({ x1: x1 + ox, x2: x2 + ox, z1: z1 + oz, z2: z2 + oz, y0: y0 + oy, y1: y1 + oy, active: true })
  }

  /* ---------- helpers de construction ---------- */
  const slab = (
    x1: number,
    z1: number,
    x2: number,
    z2: number,
    topY: number,
    thick: number,
    topMat: THREE.Material,
    sideMat: THREE.Material = M.paint,
    surf = true,
  ) => {
    b.bb(x1, topY - thick, z1, x2, topY, z2, { py: topMat, ny: M.ceiling, sides: sideMat })
    slabs.push(new THREE.Box3(new THREE.Vector3(x1, topY - thick, z1), new THREE.Vector3(x2, topY, z2)))
    if (surf) surfaces.push({ x1, x2, z1, z2, h: topY })
  }
  const ceil = (x1: number, z1: number, x2: number, z2: number, yBottom: number, thick = 0.2) => {
    b.bb(x1, yBottom, z1, x2, yBottom + thick, z2, { ny: M.ceiling, all: M.paint })
    slabs.push(new THREE.Box3(new THREE.Vector3(x1, yBottom, z1), new THREE.Vector3(x2, yBottom + thick, z2)))
  }

  const makeLeaf = (w: number, h: number, front: boolean, mat: THREE.Material) => {
    const lb = new Builder(null)
    const pm = front ? cm(0x120b08, 0.5) : cm(0xd9d5ca, 0.55)
    lb.bb(0, 0, -0.022, w, h, 0.022, mat)
    const ins = 0.11
    for (const s of [1, -1]) {
      const z0 = s * 0.022
      const z1 = s * 0.03
      lb.bb(ins, 0.14, Math.min(z0, z1), w - ins, h * 0.46, Math.max(z0, z1), pm)
      if (front) {
        lb.bb(ins + 0.1, h * 0.54, Math.min(z0, z1), w - ins - 0.1, h - 0.22, Math.max(z0, z1), M.windowLit)
      } else {
        lb.bb(ins, h * 0.54, Math.min(z0, z1), w - ins, h - 0.14, Math.max(z0, z1), pm)
      }
      const hz = s * 0.085
      lb.bb(w - 0.14, 1.0, Math.min(z0, hz), w - 0.06, 1.035, Math.max(z0, hz), M.steel)
      lb.bb(w - 0.075, 0.97, Math.min(z0, hz), w - 0.06, 1.035, Math.max(z0, hz), M.steel)
    }
    return lb.build()
  }

  function wall(
    axis: 'x' | 'z',
    fixed: number,
    from: number,
    to: number,
    y0: number,
    y1: number,
    t: number,
    mPos: THREE.Material,
    mNeg: THREE.Material,
    ops: Op[] = [],
    o: { fl?: number; col?: boolean; ext?: [number, number]; leafMat?: THREE.Material } = {},
  ) {
    const fl = o.fl ?? y0
    const spec: MatSpec = axis === 'x' ? { all: mPos, pz: mPos, nz: mNeg } : { all: mPos, px: mPos, nx: mNeg }
    const withCol = o.col !== false
    const seg = (s1: number, s2: number, ya: number, yb: number, col = true) => {
      if (s2 - s1 < 1e-4 || yb - ya < 1e-4) return
      if (axis === 'x') b.bb(s1, ya, fixed - t / 2, s2, yb, fixed + t / 2, spec, { solid: col && withCol })
      else b.bb(fixed - t / 2, ya, s1, fixed + t / 2, yb, s2, spec, { solid: col && withCol })
      if (col && withCol) colliders[colliders.length - 1].kind = 'wall'
    }
    const fbox = (s1: number, s2: number, ya: number, yb: number, thick: number, mat: THREE.Material) => {
      if (axis === 'x') b.bb(s1, ya, fixed - thick / 2, s2, yb, fixed + thick / 2, mat)
      else b.bb(fixed - thick / 2, ya, s1, fixed + thick / 2, yb, s2, mat)
    }
    const [e0, e1] = o.ext ?? [0, 0]
    let cur = from - e0
    const end = to + e1
    const sorted = [...ops].sort((p, q) => p.c - q.c)
    for (const op of sorted) {
      openings.push({ kind: op.kind, position: new THREE.Vector3(axis === 'x' ? op.c : fixed, fl + (op.sill ?? 0), axis === 'x' ? fixed : op.c), axis, width: op.w, height: op.h ?? 2.1, floor: fl, inward: op.inn ?? 0 })
      const a = op.c - op.w / 2
      const e = op.c + op.w / 2
      seg(cur, a, y0, y1)
      if (op.kind === 'window') {
        const sy = fl + (op.sill ?? 0.9)
        const ey = sy + (op.h ?? 1.2)
        seg(a, e, y0, sy)
        seg(a, e, ey, y1)
        if (withCol) {
          if (axis === 'x') colliders.push({ x1: a, x2: e, z1: fixed - t / 2, z2: fixed + t / 2, y0: sy, y1: ey, active: true })
          else colliders.push({ x1: fixed - t / 2, x2: fixed + t / 2, z1: a, z2: e, y0: sy, y1: ey, active: true })
          colliders[colliders.length - 1].kind = 'window'
        }
        const fw = 0.05
        fbox(a, a + fw, sy, ey, t + 0.03, M.trim)
        fbox(e - fw, e, sy, ey, t + 0.03, M.trim)
        fbox(a, e, ey - fw, ey, t + 0.03, M.trim)
        fbox(a, e, sy, sy + fw, t + 0.03, M.trim)
        if (op.w > 0.95) fbox(op.c - 0.02, op.c + 0.02, sy, ey, 0.06, M.trim)
        fbox(a, e, sy + (ey - sy) / 2 - 0.02, sy + (ey - sy) / 2 + 0.02, 0.06, M.trim)
        fbox(a - 0.06, e + 0.06, sy - 0.04, sy, t + 0.14, M.trim)
        if (axis === 'x') b.bb(a, sy, fixed - 0.006, e, ey, fixed + 0.006, M.glass)
        else b.bb(fixed - 0.006, sy, a, fixed + 0.006, ey, e, M.glass)
        if (op.curtain != null && op.inn) {
          const cmat = M.curtain(op.curtain)
          const off = op.inn * (t / 2 + 0.1)
          const topY = ey + 0.2
          const botY = fl + 0.06
          const pw = op.w * 0.34
          const folds = 6
          const putFold = (s: number, wd: number, d: number) => {
            if (axis === 'x') b.bb(s, botY, fixed + off + d - 0.012, s + wd, topY, fixed + off + d + 0.012, cmat)
            else b.bb(fixed + off + d - 0.012, botY, s, fixed + off + d + 0.012, topY, s + wd, cmat)
          }
          for (const side of [0, 1]) {
            const start = side === 0 ? a - 0.22 : e + 0.22 - pw
            for (let k = 0; k < folds; k++) putFold(start + (k * pw) / folds, pw / folds, (k % 2 ? 0.035 : -0.035) * op.inn)
          }
          if (axis === 'x') b.bb(a - 0.3, topY - 0.03, fixed + off - 0.04, e + 0.3, topY + 0.01, fixed + off + 0.04, M.blackMetal)
          else b.bb(fixed + off - 0.04, topY - 0.03, a - 0.3, fixed + off + 0.04, topY + 0.01, e + 0.3, M.blackMetal)
        }
      } else {
        const dh = op.h ?? (op.kind === 'garage' ? 2.15 : 2.1)
        seg(a, e, fl + dh, y1)
        const cw = 0.07
        fbox(a - cw, a, fl, fl + dh + cw, t + 0.04, M.trim)
        fbox(e, e + cw, fl, fl + dh + cw, t + 0.04, M.trim)
        fbox(a - cw, e + cw, fl + dh, fl + dh + cw, t + 0.04, M.trim)
        if (op.kind === 'door') {
          const hinge = op.hinge ?? -1
          const side = op.side ?? 1
          const d = -hinge
          const lw = op.w - 0.03
          const leafMat = o.leafMat ?? (op.front ? cm(0x2a1b13, 0.5) : cm(0xe6e2d7, 0.5))
          const g = makeLeaf(lw, dh - 0.02, !!op.front, leafMat)
          let theta0: number
          let phi: number
          let px: number
          let pz: number
          if (axis === 'x') {
            px = op.c + hinge * (op.w / 2 - 0.015)
            pz = fixed
            theta0 = d > 0 ? 0 : Math.PI
            phi = -d * side * (Math.PI / 2) * 0.94
          } else {
            px = fixed
            pz = op.c + hinge * (op.w / 2 - 0.015)
            theta0 = (-d * Math.PI) / 2
            phi = d * side * (Math.PI / 2) * 0.94
          }
          g.position.set(px, fl + 0.01, pz)
          g.rotation.y = theta0
          const col: Collider =
            axis === 'x'
              ? { x1: a, x2: e, z1: fixed - 0.07, z2: fixed + 0.07, y0: fl, y1: fl + dh, active: true }
              : { x1: fixed - 0.07, x2: fixed + 0.07, z1: a, z2: e, y0: fl, y1: fl + dh, active: true }
          colliders.push(col)
          col.kind = 'door'
          doors.push({
            name: op.name ?? (op.front ? "Porte d'entrée" : 'Porte'),
            kind: 'door',
            group: g,
            collider: col,
            open: false,
            t: 0,
            theta0,
            phi,
            x: axis === 'x' ? op.c : fixed,
            z: axis === 'x' ? fixed : op.c,
            y: fl,
          })
          root.add(g)
        } else if (op.kind === 'garage') {
          const gb = new Builder(null)
          const w = op.w - 0.04
          const panel = cm(0xe3dfd4, 0.6)
          gb.bb(-w / 2, -dh, -0.03, w / 2, 0, 0.03, panel)
          const line = cm(0x9a968c, 0.8)
          for (let k = 1; k < 4; k++)
            for (const s of [1, -1]) gb.bb(-w / 2, -(dh * k) / 4 - 0.012, s * 0.03 - 0.002, w / 2, -(dh * k) / 4 + 0.012, s * 0.036, line)
          for (let k = 0; k < 8; k++) {
            const x0 = -w / 2 + 0.2 + k * ((w - 0.4) / 8)
            for (const s of [1, -1]) gb.bb(x0, -dh / 4 + 0.08, s * 0.03, x0 + (w - 0.4) / 8 - 0.06, -0.08, s * 0.036, M.carGlass)
          }
          const g = gb.build()
          g.position.set(op.c, fl + dh, fixed)
          const col: Collider =
            axis === 'x'
              ? { x1: a, x2: e, z1: fixed - 0.1, z2: fixed + 0.1, y0: fl, y1: fl + dh, active: true }
              : { x1: fixed - 0.1, x2: fixed + 0.1, z1: a, z2: e, y0: fl, y1: fl + dh, active: true }
          colliders.push(col)
          col.kind = 'door'
          doors.push({
            name: 'Porte de garage',
            kind: 'garage',
            group: g,
            collider: col,
            open: false,
            t: 0,
            theta0: 0,
            phi: 0,
            x: op.c,
            z: fixed,
            y: fl,
          })
          root.add(g)
        }
      }
      cur = e
    }
    seg(cur, end, y0, y1)
  }

  /* ---------- paramètres ---------- */
  const E = 0.25
  const TI = 0.12

  await checkpoint(18, 'Construction des sols et des plafonds')

  /* ===================== DALLES / SOLS ===================== */
  // sous-sol
  slab(0, 0, 9, 9, -3.0, 0.2, M.concrete, M.concreteWall)
  // rez-de-chaussée
  slab(0, 1.5, 6, 9, 0, 0.2, M.concrete, M.concreteWall)
  slab(4.5, 0, 6, 1.5, 0, 0.2, M.concrete, M.concreteWall)
  slab(0, 0, 0.3, 1.5, 0, 0.2, M.concrete, M.concreteWall)
  slab(6, 0, 8.5, 3, 0, 0.2, M.tile)
  slab(8.5, 0, 10, 3, 0, 0.2, M.tile)
  slab(6, 3, 10, 9, 0, 0.2, M.floorWood)
  slab(10, 0, 18, 9, 0, 0.2, M.floorWood)
  ceil(0, 0, 6, 9, 2.8)
  // étage (y = 3.0)
  const UF = 3.0
  slab(6, 0, 8.6, SZ1, UF, 0.2, M.floorWood)
  slab(7.5, SZ1, 8.6, 7.3, UF, 0.2, M.floorWood, M.trim)
  slab(6, 7.3, 8.6, 9, UF, 0.2, M.floorWood)
  slab(8.6, 0, 13, 4.5, UF, 0.2, M.floorWood)
  slab(8.6, 4.5, 11.6, 5.7, UF, 0.2, M.floorWood)
  slab(8.6, 5.7, 11.6, 9, UF, 0.2, M.tile)
  slab(11.6, 4.5, 18, 9, UF, 0.2, M.floorWood)
  slab(13, 0, 18, 4.5, UF, 0.2, M.floorWood)
  ceil(6, 0, 18, 9, 5.8)

  await checkpoint(30, 'Montage des murs du rez-de-chaussée')

  /* ===================== MURS RDC ===================== */
  // façade sud
  wall('x', 9, 0, 6, -0.2, 3.0, E, M.siding, M.paintGarage, [{ c: 3.0, w: 4.4, kind: 'garage', h: 2.15 }], { fl: 0, ext: [0.125, 0] })
  wall(
    'x',
    9,
    6,
    18,
    -0.2,
    3.0,
    E,
    M.siding,
    M.paint,
    [
      { c: 8.7, w: 1.0, kind: 'door', h: 2.1, front: true, hinge: 1, side: -1, name: "Porte d'entrée" },
      { c: 12.6, w: 1.6, kind: 'window', sill: 0.8, h: 1.3, inn: -1, curtain: 0xd8cebc },
      { c: 16.0, w: 2.0, kind: 'window', sill: 0.8, h: 1.3, inn: -1, curtain: 0xd8cebc },
    ],
    { fl: 0, ext: [0, 0.125] },
  )
  // façade nord
  wall('x', 0, 0, 6, -0.2, 3.0, E, M.paintGarage, M.siding, [], { fl: 0, ext: [0.125, 0] })
  wall('x', 0, 6, 8.5, -0.2, 3.0, E, M.paintLight, M.siding, [{ c: 6.8, w: 0.7, kind: 'window', sill: 1.15, h: 0.7, inn: 1 }], { fl: 0 })
  wall('x', 0, 8.5, 10, -0.2, 3.0, E, M.paintBath, M.siding, [{ c: 9.25, w: 0.4, kind: 'window', sill: 1.5, h: 0.4, inn: 1 }], { fl: 0 })
  wall('x', 0, 10, 18, -0.2, 3.0, E, M.paintLight, M.siding, [], { fl: 0, ext: [0, 0.125] })
  // ouest (garage)
  wall('z', 0, 0, 9, -0.2, 3.0, E, M.paintGarage, M.siding, [{ c: 3.0, w: 1.3, kind: 'window', sill: 1.25, h: 0.8, inn: 1 }], { fl: 0 })
  // est
  wall('z', 18, 0, 4.5, -0.2, 3.0, E, M.siding, M.paintLight, [{ c: 2.4, w: 1.4, kind: 'window', sill: 0.95, h: 1.2, inn: -1, curtain: 0xd8cebc }], { fl: 0 })
  wall('z', 18, 4.5, 9, -0.2, 3.0, E, M.siding, M.paint, [], { fl: 0 })
  // cloisons
  wall(
    'z',
    6,
    0,
    9,
    0,
    3.0,
    0.2,
    M.paint,
    M.paintGarage,
    [
      { c: 1.5, w: 0.9, kind: 'door', hinge: 1, side: -1, name: 'Porte buanderie' },
      { c: 3.5, w: 0.9, kind: 'door', hinge: 1, side: -1, name: 'Porte du garage' },
    ],
    { fl: 0 },
  )
  wall(
    'x',
    3,
    6.1,
    10,
    0,
    2.8,
    TI,
    M.paint,
    M.paintLight,
    [
      { c: 7.2, w: 0.9, kind: 'door', hinge: -1, side: -1, name: 'Porte buanderie' },
      { c: 9.25, w: 0.8, kind: 'door', hinge: 1, side: 1, name: 'Porte WC' },
    ],
    { fl: 0 },
  )
  wall('z', 8.5, 0, 3, 0, 2.8, TI, M.paintBath, M.paintLight, [], { fl: 0 })
  wall(
    'z',
    10,
    0,
    9,
    0,
    2.8,
    TI,
    M.paintLight,
    M.paint,
    [
      { c: 3.7, w: 1.0, kind: 'arch', h: 2.2 },
      { c: 7.4, w: 2.0, kind: 'arch', h: 2.2 },
    ],
    { fl: 0 },
  )

  await checkpoint(42, 'Montage des murs de l’étage')

  /* ===================== MURS ÉTAGE ===================== */
  const UH = 6.0
  wall(
    'x',
    9,
    6,
    8.6,
    UF,
    UH,
    E,
    M.siding,
    M.paint,
    [{ c: 7.35, w: 0.9, kind: 'window', sill: 0.9, h: 1.3, inn: -1, curtain: null }],
    { fl: UF, ext: [0.1, 0] },
  )
  wall('x', 9, 8.6, 11.6, UF, UH, E, M.siding, M.paintBath, [{ c: 10.7, w: 0.8, kind: 'window', sill: 1.3, h: 0.9, inn: -1, curtain: 0xcfd6da }], { fl: UF })
  wall(
    'x',
    9,
    11.6,
    18,
    UF,
    UH,
    E,
    M.siding,
    M.paintBed,
    [
      { c: 13.6, w: 1.4, kind: 'window', sill: 0.9, h: 1.4, inn: -1, curtain: 0xcfc3b0 },
      { c: 16.4, w: 1.4, kind: 'window', sill: 0.9, h: 1.4, inn: -1, curtain: 0xcfc3b0 },
    ],
    { fl: UF, ext: [0, 0.125] },
  )
  wall('x', 0, 6, 8.6, UF, UH, E, M.paint, M.siding, [{ c: 7.35, w: 0.9, kind: 'window', sill: 0.9, h: 1.3, inn: 1, curtain: null }], { fl: UF, ext: [0.1, 0] })
  wall('x', 0, 8.6, 13, UF, UH, E, M.paintBed, M.siding, [{ c: 11.4, w: 1.5, kind: 'window', sill: 0.9, h: 1.2, inn: 1, curtain: 0xb9aea0 }], { fl: UF })
  wall('x', 0, 13, 18, UF, UH, E, M.paintLight, M.siding, [], { fl: UF, ext: [0, 0.125] })
  wall('z', 18, 0, 4.5, UF, UH, E, M.siding, M.paintLight, [{ c: 1.9, w: 0.8, kind: 'window', sill: 1.0, h: 1.0, inn: -1, curtain: 0xd8cebc }], { fl: UF })
  wall('z', 18, 4.5, 9, UF, UH, E, M.siding, M.paintBed, [], { fl: UF })
  wall('z', 6, 0, 9, UF, UH, 0.2, M.paint, M.siding, [], { fl: UF })
  // cloisons étage
  wall(
    'z',
    8.6,
    0,
    9,
    UF,
    5.8,
    TI,
    M.paintBed,
    M.paint,
    [
      { c: 2.0, w: 0.9, kind: 'door', hinge: -1, side: -1, name: 'Porte chambre 1' },
      { c: 5.1, w: 1.2, kind: 'arch', h: 2.2 },
    ],
    { fl: UF },
  )
  wall('x', 4.5, 8.6, 18, UF, 5.8, TI, M.paintBed, M.paintBed, [{ c: 15.5, w: 0.9, kind: 'door', hinge: -1, side: -1, name: 'Porte dressing' }], { fl: UF })
  wall('z', 13, 0, 4.5, UF, 5.8, TI, M.paintLight, M.paintBed, [], { fl: UF })
  wall('x', 5.7, 8.6, 11.6, UF, 5.8, TI, M.paintBath, M.paint, [{ c: 10.1, w: 0.8, kind: 'door', hinge: -1, side: -1, name: 'Porte salle de bain' }], { fl: UF })
  wall('z', 11.6, 4.5, 9, UF, 5.8, TI, M.paintBed, M.paintBath, [{ c: 5.1, w: 0.9, kind: 'door', hinge: 1, side: 1, name: 'Porte suite parentale' }], { fl: UF })

  await checkpoint(52, 'Construction du sous-sol et des escaliers')

  /* ===================== SOUS-SOL ===================== */
  const FB = -3.0
  wall('x', 0, 0, 9, -3.2, 0, E, M.concreteWall, M.concreteWall, [], { fl: FB, ext: [0.125, 0.125] })
  wall('x', 9, 0, 9, -3.2, 0, E, M.concreteWall, M.concreteWall, [], { fl: FB, ext: [0.125, 0.125] })
  wall('z', 0, 0, 9, -3.2, 0, E, M.concreteWall, M.concreteWall, [], { fl: FB })
  wall('z', 9, 0, 9, -3.2, 0, E, M.concreteWall, M.concreteWall, [], { fl: FB })
  wall('x', 1.5, 1.0, 4.5, FB, -0.2, TI, M.concreteWall, M.concreteWall, [], { fl: FB, col: false })
  block(1.0, -3.0, 1.44, 4.5, 0.95, 1.56)
  block(0.3, 0.0, 1.44, 1.0, 0.95, 1.56)
  wall(
    'x',
    5.8,
    6.4,
    9,
    FB,
    -0.2,
    TI,
    M.concreteWall,
    M.concreteWall,
    [{ c: 7.7, w: 0.9, kind: 'door', hinge: -1, side: -1, name: 'Porte local technique' }],
    { fl: FB, leafMat: cm(0xb8b4aa, 0.6) },
  )
  wall('z', 6.4, 5.8, 9, FB, -0.2, TI, M.concreteWall, M.concreteWall, [], { fl: FB })

  /* ===================== ESCALIERS ===================== */
  // escalier principal (monte vers le nord, côté ouest du hall)
  const rise = 3.0 / 16
  const tread = RUN / 15
  for (let i = 0; i < 15; i++) {
    const zb = SZ0 - tread * (i + 1)
    const zf = SZ0 - tread * i
    b.bb(XW, 0, zb, 7.5, rise * (i + 1), zf, { py: M.stairWood, pz: M.trim, sides: M.paint, ny: M.paint })
    b.bb(XW, rise * (i + 1) - 0.035, zf - 0.0, 7.5, rise * (i + 1), zf + 0.03, M.stairWood)
  }
  surfaces.push({ x1: XW, x2: 7.5, z1: SZ1, z2: SZ0, h: 0, fn: (_x, z) => Math.max(0, Math.min(3, ((SZ0 - z) / RUN) * 3 - 0.09)) })
  const rot35 = Math.atan(3 / RUN)
  const rlen = Math.hypot(RUN, 3)
  b.box(7.54, 2.4, (SZ0 + SZ1) / 2, 0.06, 0.07, rlen, M.woodDark, { rot: [rot35, 0, 0] })
  b.box(6.14, 2.4, (SZ0 + SZ1) / 2, 0.05, 0.05, rlen, M.woodDark, { rot: [rot35, 0, 0] })
  for (let k = 0; k < 15; k++) {
    const z = SZ0 - tread * (k + 0.5)
    const yTop = rise * (k + 1)
    const railY = ((SZ0 - z) / RUN) * 3 + 0.9
    b.bb(7.52, yTop, z - 0.015, 7.56, railY, z + 0.015, M.trim)
    b.bb(7.52, yTop + 0.1, z + tread / 2 - 0.015, 7.56, railY - 0.04, z + tread / 2 + 0.015, M.trim)
    // supports muraux main courante
    if (k % 3 === 0) b.bb(6.1, railY - 0.04, z - 0.015, 6.14, railY, z + 0.015, M.blackMetal)
  }
  b.bb(7.46, 0, SZ0 - 0.04, 7.58, 1.1, SZ0 + 0.08, M.woodDark)
  // garde-corps étage
  for (let z = SZ1 + 0.05; z < 7.3; z += 0.14) b.bb(7.52, UF, z - 0.015, 7.56, UF + 0.9, z + 0.015, M.trim)
  b.bb(7.5, UF + 0.9, SZ1, 7.6, UF + 0.97, 7.35, M.woodDark)
  for (let x = XW + 0.1; x < 7.5; x += 0.14) b.bb(x - 0.015, UF, 7.3, x + 0.015, UF + 0.9, 7.34, M.trim)
  b.bb(XW, UF + 0.9, 7.28, 7.6, UF + 0.97, 7.36, M.woodDark)
  block(7.45, 0, SZ1, 7.55, 4.2, 7.3)
  block(7.45, 0, 7.3, 7.55, 2.9, SZ0)
  block(XW, UF, 7.25, 7.5, 4.2, 7.35)

  // escalier sous-sol (descend vers l'ouest, dans le garage)
  const BR = 3.0 / 16
  for (let i = 0; i < 15; i++) {
    const xe = 4.5 - tread * i
    const xw = 4.5 - tread * (i + 1)
    const top = -BR * (i + 1)
    b.bb(xw, FB, 0.125, xe, top, 1.44, { py: M.stairWood, nx: M.trim, sides: M.concreteWall, ny: M.concreteWall })
  }
  const bx1 = 4.5 - RUN
  surfaces.push({ x1: 0.3, x2: 4.5, z1: 0.125, z2: 1.5, h: 0, fn: (x) => Math.max(-3, Math.min(0, -3 + ((x - bx1) / RUN) * 3 - 0.09)) })
  b.box(2.4, -0.55, 0.2, rlen, 0.05, 0.05, M.woodDark, { rot: [0, 0, rot35] })
  for (let k = 0; k < 6; k++) {
    const x = 4.3 - k * 0.7
    b.bb(x - 0.02, -2.0 + k * 0.0, 0.14, x + 0.02, 0, 0.19, M.blackMetal)
  }
  // garde-corps garage au-dessus de la trémie
  b.bb(0.3, 0.9, 1.44, 4.5, 0.97, 1.56, M.woodDark)
  for (let x = 0.4; x < 4.5; x += 0.14) b.bb(x - 0.015, 0, 1.47, x + 0.015, 0.9, 1.53, M.blackMetal)

  await checkpoint(62, 'Toiture, porche et abords')

  /* ===================== TOITURE ===================== */
  const slope = Math.atan(0.5)
  b.box(8.8, 7.4, 4.5, 7.155, 0.16, 10.4, M.roof, { rot: [0, 0, slope] })
  b.box(15.2, 7.4, 4.5, 7.155, 0.16, 10.4, M.roof, { rot: [0, 0, -slope] })
  b.bb(11.85, 8.95, -0.7, 12.15, 9.12, 9.7, cm(0x17181b, 0.9))
  b.box(1.25, 3.875, 4.5, 3.913, 0.14, 10.4, M.roof, { rot: [0, 0, slope] })
  b.box(4.5, 4.0, 4.5, 3.354, 0.14, 10.4, M.roof, { rot: [0, 0, -slope] })
  // bavettes blanches
  b.box(5.55, 5.74, 4.5, 0.06, 0.12, 10.4, M.trim)
  b.box(18.45, 5.74, 4.5, 0.06, 0.12, 10.4, M.trim)
  // pignons
  const tri = (x1: number, x2: number, y0: number, apex: number, hole?: [number, number, number, number]) => {
    const s = new THREE.Shape()
    s.moveTo(x1, y0)
    s.lineTo(x2, y0)
    s.lineTo((x1 + x2) / 2, apex)
    s.lineTo(x1, y0)
    if (hole) {
      const p = new THREE.Path()
      p.moveTo(hole[0], hole[1])
      p.lineTo(hole[0], hole[3])
      p.lineTo(hole[2], hole[3])
      p.lineTo(hole[2], hole[1])
      p.lineTo(hole[0], hole[1])
      s.holes.push(p)
    }
    return new THREE.ExtrudeGeometry(s, { depth: 0.2, bevelEnabled: false })
  }
  const gA = tri(6, 18, UH, 9.0, [11.35, 6.5, 12.65, 7.8])
  b.geo(gA, [0, 0, 8.925], M.siding)
  const gB = tri(6, 18, UH, 9.0)
  b.geo(gB, [0, 0, -0.125], M.siding)
  const gC = tri(0, 6, 3.0, 4.5)
  b.geo(gC, [0, 0, 8.925], M.siding)
  b.geo(tri(0, 6, 3.0, 4.5), [0, 0, -0.125], M.siding)
  // fenêtre de pignon éclairée
  b.bb(11.4, 6.5, 8.99, 12.6, 7.75, 9.03, M.gableGlass)
  b.bb(11.3, 6.42, 9.0, 11.4, 7.82, 9.14, M.trim)
  b.bb(12.6, 6.42, 9.0, 12.7, 7.82, 9.14, M.trim)
  b.bb(11.3, 6.42, 9.0, 12.7, 6.5, 9.14, M.trim)
  b.bb(11.3, 7.75, 9.0, 12.7, 7.84, 9.14, M.trim)
  b.bb(11.97, 6.5, 9.0, 12.03, 7.75, 9.16, M.trim)
  b.bb(11.4, 7.1, 9.0, 12.6, 7.16, 9.16, M.trim)
  // cheminée
  b.bb(15.4, 5.9, 2.6, 16.4, 10.4, 3.5, M.stone, { solid: false })
  b.bb(15.3, 10.4, 2.5, 16.5, 10.55, 3.6, cm(0x3a3a3c, 0.9))

  /* ===================== PORCHE ===================== */
  slab(6, 9.1, 12.3, 11.45, 0.15, 0.5, M.tileDark, M.stone)
  slab(7.7, 11.45, 9.7, 11.9, 0.075, 0.4, M.concrete, M.stone)
  for (const cx of [6.5, 7.4, 10.3, 11.7]) {
    b.bb(cx - 0.25, 0.15, 10.65, cx + 0.25, 0.95, 11.15, M.stone, { solid: true })
    b.bb(cx - 0.17, 0.95, 10.73, cx + 0.17, 2.82, 11.07, M.trim)
    b.bb(cx - 0.24, 2.82, 10.66, cx + 0.24, 2.92, 11.14, M.trim)
  }
  b.bb(6.1, 2.88, 10.7, 12.1, 3.08, 11.1, M.trim)
  b.bb(6.0, 2.85, 9.125, 12.3, 2.9, 11.45, { ny: M.ceiling, all: M.paint })
  b.box(9.15, 3.2, 10.3, 6.6, 0.12, 2.6, M.roof, { rot: [0.146, 0, 0] })
  b.bb(5.85, 2.85, 11.45, 12.45, 3.1, 11.52, M.trim)
  b.bb(10.3, 0.88, 10.9, 11.7, 0.95, 11.0, M.trim)
  b.bb(10.3, 0.2, 10.92, 11.7, 0.26, 10.98, M.trim)
  for (let x = 10.45; x < 11.7; x += 0.14) b.bb(x - 0.015, 0.15, 10.92, x + 0.015, 0.9, 10.98, M.trim)
  block(10.3, 0.15, 10.85, 11.7, 1.0, 11.05)
  // lanternes
  const lantern = (x: number, y: number, z: number) => {
    b.bb(x - 0.07, y, z, x + 0.07, y + 0.3, z + 0.14, M.lantern)
    b.bb(x - 0.085, y + 0.3, z - 0.005, x + 0.085, y + 0.34, z + 0.155, M.blackMetal)
    b.bb(x - 0.085, y - 0.04, z - 0.005, x + 0.085, y, z + 0.155, M.blackMetal)
  }
  lantern(7.7, 1.75, 9.125)
  lantern(9.75, 1.75, 9.125)
  lantern(0.45, 1.85, 9.125)
  lantern(5.55, 1.85, 9.125)
  addLight(8.7, 2.5, 10.3, 0xffd49a, 16, 11)
  addLight(0.4, 1.9, 9.8, 0xffd49a, 9, 8)
  addLight(5.6, 1.9, 9.8, 0xffd49a, 9, 8)
  // paillasson, numéro
  b.bb(8.2, 0.15, 9.5, 9.2, 0.17, 10.1, M.rugDark)
  b.bb(8.6, 1.5, 9.125, 8.8, 1.6, 9.14, M.steel)

  /* ===================== EXTÉRIEUR ===================== */
  // pelouse (en morceaux autour de la maison pour garder la trémie du sous-sol)
  const lawn = (x1: number, z1: number, x2: number, z2: number) => {
    b.bb(x1, -1.5, z1, x2, -0.02, z2, M.grass)
    surfaces.push({ x1, x2, z1, z2, h: 0 })
  }
  lawn(-60, -60, 80, -0.1)
  lawn(-60, 9.1, 80, 26)
  lawn(-60, -0.1, -0.1, 9.1)
  lawn(18.1, -0.1, 80, 9.1)
  // trottoir & route
  b.bb(-60, -1, 26, 80, 0.04, 28.2, M.sidewalk)
  b.bb(-60, -1, 28.2, 80, -0.03, 38, M.asphalt)
  b.bb(-60, -1, 38, 80, 0.04, 40, M.sidewalk)
  b.bb(-60, -1.5, 40, 80, -0.02, 90, M.grass)
  surfaces.push({ x1: -60, x2: 80, z1: 26, z2: 40, h: 0 })
  for (let x = -58; x < 78; x += 6) b.bb(x, -0.025, 32.9, x + 3, -0.02, 33.1, M.dash)
  // allée & chemin
  b.bb(0.3, -0.1, 9.1, 5.7, 0.015, 26, M.concrete)
  b.bb(8.0, -0.1, 11.9, 9.4, 0.012, 26, M.sidewalk)
  // clôtures
  b.bb(-7.1, 0, -14, -6.9, 1.8, 26, M.fence, { solid: true })
  b.bb(24.9, 0, -14, 25.1, 1.8, 26, M.fence, { solid: true })
  b.bb(-7, 0, -14.1, 25, 1.8, -13.9, M.fence, { solid: true })
  for (let z = -14; z < 26; z += 2) {
    b.bb(-7.15, 0, z, -6.85, 1.9, z + 0.12, M.woodDark)
    b.bb(24.85, 0, z, 25.15, 1.9, z + 0.12, M.woodDark)
  }
  for (let x = -7; x < 25; x += 2) b.bb(x, 0, -14.15, x + 0.12, 1.9, -13.85, M.woodDark)

  // arbres
  const pine = (x: number, z: number, s = 1) => {
    b.cyl(x, 0, z, 0.22 * s, 2 * s, M.trunk, { seg: 8, solid: true })
    for (let k = 0; k < 5; k++) b.cone(x, 1.4 * s + k * 1.5 * s, z, (2.2 - k * 0.38) * s, 2.6 * s, k % 2 ? M.pine : M.pine2, 9)
  }
  const oak = (x: number, z: number, s = 1) => {
    b.cyl(x, 0, z, 0.3 * s, 3 * s, M.trunk, { seg: 8, solid: true })
    b.sph(x, 4.2 * s, z, 2.2 * s, M.bush2, { seg: 10 })
    b.sph(x + 1.2 * s, 3.6 * s, z + 0.4 * s, 1.6 * s, M.bush, { seg: 10 })
    b.sph(x - 1.1 * s, 3.8 * s, z - 0.5 * s, 1.7 * s, M.bush, { seg: 10 })
    b.sph(x, 5.2 * s, z + 0.3 * s, 1.5 * s, M.bush2, { seg: 10 })
  }
  pine(21, 12.5, 1.2)
  pine(-11, 15, 1.1)
  pine(-3, -8, 1.4)
  pine(14, -9, 1.2)
  pine(22, -4, 1.0)
  pine(-4.5, 22, 1)
  oak(-3.5, 14.5, 0.9)
  oak(20.8, 21, 1.0)
  oak(11, 19.5, 0.8)
  oak(-14, 4, 1.0)
  oak(-16, 20, 1.2)
  oak(30, 18, 1.2)

  // buissons + éclairage de jardin devant la façade
  const bushAt = (x: number, z: number, r = 0.55) => {
    b.sph(x, r * 0.8, z, r, rand() > 0.5 ? M.bush : M.bush2, { sy: 0.85, seg: 9, solid: true })
  }
  for (let x = 12.6; x <= 17.6; x += 0.9) bushAt(x, 9.75, 0.5)
  for (let x = 6.2; x <= 12.2; x += 1.0) if (x < 7.3 || x > 9.9) bushAt(x, 11.9 + rand() * 0.2, 0.42)
  for (const x of [0.6, 5.4]) bushAt(x, 9.7, 0.45)
  for (let x = 12.9; x <= 17.4; x += 1.1) {
    b.sph(x + 0.3, 0.2, 10.35, 0.12, M.flower, { seg: 6 })
  }
  b.bb(0.2, 0, 14, 0.5, 0.01, 14.3, M.soil)
  const pathLight = (x: number, z: number) => {
    b.cyl(x, 0, z, 0.03, 0.45, M.blackMetal, { seg: 6 })
    b.cyl(x, 0.45, z, 0.08, 0.1, M.pathLight, { seg: 8 })
    b.cyl(x, 0.55, z, 0.1, 0.03, M.blackMetal, { seg: 8 })
  }
  for (let z = 13; z <= 25; z += 3) {
    pathLight(7.55, z)
    pathLight(9.85, z)
  }
  for (const x of [13.5, 16.5]) {
    b.cyl(x, 0, 10.0, 0.05, 0.12, M.pathLight, { seg: 6 })
  }
  addLight(9, 0.8, 18, 0xffd49a, 6, 10)
  // boîte aux lettres
  b.bb(6.0, 0, 25.2, 6.08, 1.0, 25.28, M.blackMetal)
  b.bb(5.85, 1.0, 25.1, 6.25, 1.25, 25.4, M.blackMetal, { solid: true })
  // lampadaire
  b.cyl(14, 0, 26.6, 0.07, 6.2, M.blackMetal, { seg: 8, solid: true })
  b.bb(13.9, 6.1, 26.5, 14.0, 6.2, 27.6, M.blackMetal)
  b.bb(13.85, 5.95, 27.3, 14.15, 6.1, 27.7, M.streetLamp)
  addLight(14, 5.8, 27.4, 0xffc890, 28, 22)

  // maisons voisines
  const house = (x: number, z: number, w: number, d: number, rotLit: number[]) => {
    b.bb(x, 0, z, x + w, 5.2, z + d, { all: M.houseDark }, { solid: true })
    const rg = new THREE.Shape()
    rg.moveTo(0, 0)
    rg.lineTo(w + 1, 0)
    rg.lineTo((w + 1) / 2, 3)
    const eg = new THREE.ExtrudeGeometry(rg, { depth: d + 1, bevelEnabled: false })
    b.geo(eg, [x - 0.5, 5.2, z - 0.5], M.roofDark)
    for (let k = 0; k < rotLit.length; k++) {
      const wx = x + 1.2 + k * 2.4
      const lit = rotLit[k]
      const m = lit ? M.windowLit : cm(0x10141a, 0.2)
      b.bb(wx, 1.3, z + d, wx + 1.0, 2.5, z + d + 0.04, m)
      b.bb(wx, 3.3, z + d, wx + 1.0, 4.4, z + d + 0.04, lit === 2 ? M.windowLit : cm(0x10141a, 0.2))
    }
  }
  house(-22, 2, 11, 9, [1, 0, 2])
  house(29, 0, 11, 9, [0, 2, 1])
  house(-4, 46, 12, 9, [1, 1, 0])
  house(16, 46, 12, 9, [0, 2, 0])
  house(36, 46, 11, 9, [1, 0, 1])
  b.bb(-60, 0, 90, 80, 14, 92, cm(0x0a0f14, 1))

  await checkpoint(76, 'Installation du mobilier d’origine')

  /* ===================== MOBILIER ===================== */
  let pictureId = 0
  let plantId = 0
  const picture = (x: number, y: number, z: number, facing: Facing, w: number, h: number, art = 0) => {
    b.beginObject(`picture-${++pictureId}`, 'Tableau encadré', 'picture')
    const rot = facing === 'pz' ? 0 : facing === 'nz' ? Math.PI : facing === 'px' ? Math.PI / 2 : -Math.PI / 2
    b.push([x, y, z], rot)
    b.bb(-w / 2, -h / 2, -0.018, w / 2, h / 2, 0.018, cm(0x090909, 0.7))
    b.bb(-w / 2, -h / 2, 0, w / 2, h / 2, 0.035, M.frame)
    b.bb(-w / 2 + 0.045, -h / 2 + 0.045, 0.03, w / 2 - 0.045, h / 2 - 0.045, 0.04, M.linen)
    b.bb(-w / 2 + 0.085, -h / 2 + 0.085, 0.038, w / 2 - 0.085, h / 2 - 0.085, 0.046, M.art[art % 3])
    b.bb(-w / 2 + 0.1, -h / 2 + 0.1, 0.047, -w / 2 + 0.18, h / 2 - 0.12, 0.052, M.glass)
    b.pop()
    b.endObject()
  }
  const plant = (x: number, y: number, z: number, scale = 1) => {
    b.beginObject(`plant-${++plantId}`, 'Plante en pot de terre cuite')
    b.cyl(x, y - 0.025 * scale, z, 0.21 * scale, 0.035 * scale, M.pot, { seg: 14 })
    b.cyl(x, y, z, 0.16 * scale, 0.3 * scale, M.pot, { seg: 14, rTop: 0.2 * scale })
    b.cyl(x, y + 0.27 * scale, z, 0.205 * scale, 0.045 * scale, cm(0x74584a, 0.82), { seg: 14 })
    b.cyl(x, y + 0.29 * scale, z, 0.19 * scale, 0.02, M.soil, { seg: 14 })
    for (let k = 0; k < 6; k++) {
      const a = k * 1.05
      b.sph(
        x + Math.cos(a) * 0.18 * scale,
        y + (0.55 + (k % 3) * 0.2) * scale,
        z + Math.sin(a) * 0.18 * scale,
        (0.17 + (k % 2) * 0.05) * scale,
        k % 2 ? M.leaf : M.leaf2,
        { sy: 1.25, seg: 7 },
      )
    }
    b.endObject()
  }
  const lamp = (x: number, y: number, z: number, h = 0.42, light = true) => {
    b.cyl(x, y, z, 0.07, 0.04, M.blackMetal, { seg: 10 })
    b.cyl(x, y + 0.04, z, 0.02, h * 0.55, M.blackMetal, { seg: 6 })
    b.cyl(x, y + h * 0.5, z, 0.16, h * 0.5, M.shade, { seg: 12, rTop: 0.11 })
    if (light) addLight(x, y + h * 0.7, z, 0xffc880, 7, 6)
  }
  const books = (x: number, y: number, z: number, n: number, axis: 'x' | 'z', h = 0.24) => {
    const cols = [0x6b3a2e, 0x2f4a60, 0x4a5a3a, 0x8a7a5a, 0x3a3a44, 0x7a4a5a, 0xb5a58a]
    let p = 0
    for (let k = 0; k < n; k++) {
      const th = 0.03 + rand() * 0.03
      const hh = h * (0.75 + rand() * 0.3)
      const mat = cm(cols[Math.floor(rand() * cols.length)], 0.8)
      if (axis === 'x') b.bb(x + p, y, z, x + p + th, y + hh, z + 0.17, mat)
      else b.bb(x, y, z + p, x + 0.17, y + hh, z + p + th, mat)
      p += th + 0.002
    }
  }

  /* ===================== VIDÉOSURVEILLANCE ===================== */
  const cams: SecCam[] = []
  const monitors: Monitor[] = []
  const secCam = (
    name: string,
    zone: string,
    x: number,
    y: number,
    z: number,
    yaw: number,
    pitch: number,
    o: { ir?: boolean; pan?: number; speed?: number } = {},
  ) => {
    const irC = !!o.ir
    const cs = irC ? cm(0xd9dee2, 0.45, 0.2) : M.whiteGloss
    b.push([x, y, z], yaw)
    b.bb(-0.08, -0.022, -0.065, 0.08, 0.004, 0.065, M.whiteGloss)
    b.box(0, -0.07, -0.004, 0.042, 0.115, 0.042, cs, { rot: [pitch * 0.45, 0, 0] })
    b.box(0, -0.135, -0.07, 0.088, 0.078, 0.2, cs, { rot: [pitch, 0, 0] })
    b.sph(0, -0.145, -0.155, 0.038, M.black)
    b.sph(0, -0.145, -0.172, 0.026, cm(0x1b2a3a, 0.08, 0.5))
    b.sph(0.032, -0.104, -0.155, 0.012, cm(0xff2a22, 0.4, 0, 0xff0000, 3))
    b.sph(-0.032, -0.104, -0.155, 0.012, cm(0xff2a22, 0.4, 0, 0xff0000, 3))
    if (irC) {
      b.bb(-0.075, -0.175, -0.158, -0.03, -0.115, -0.15, cm(0x2a2f34, 0.6))
      b.bb(0.03, -0.175, -0.158, 0.075, -0.115, -0.15, cm(0x2a2f34, 0.6))
    }
    b.pop()
    cams.push({
      id: cams.length + 1,
      name,
      zone,
      pos: new THREE.Vector3(x, y - 0.15, z),
      yaw,
      pitch,
      fov: irC ? 72 : 82,
      ir: irC,
      pan: o.pan ?? 0,
      speed: o.speed ?? 0.22,
    })
  }
  const cctvMonitor = (name: string, x: number, y: number, z: number, yaw: number) => {
    b.push([x, y, z], yaw)
    b.bb(-0.45, -0.28, -0.02, 0.45, 0.28, 0.035, M.black)
    b.bb(-0.41, -0.245, -0.029, 0.41, 0.245, -0.019, cm(0x04070a, 0.25, 0.35))
    for (let i = 0; i < 2; i++)
      for (let j = 0; j < 2; j++) {
        const x0 = -0.4 + i * 0.405
        const y0 = -0.035 + j * 0.245
        b.bb(x0, y0, -0.035, x0 + 0.39, y0 + 0.228, -0.026, cm(0x8fd2b4, 0.4, 0, 0x2c5244, 1.1))
      }
    b.bb(-0.05, -0.34, -0.008, 0.05, -0.28, 0.016, M.blackMetal)
    b.bb(-0.3, 0.28, -0.014, 0.3, 0.31, 0.012, cm(0x101418, 0.5))
    b.pop()
    monitors.push({ name, x, y, z })
  }

  secCam('PORCHE / ENTRÉE', 'Extérieur', 6.45, 2.6, 11.15, Math.PI, -0.3, { ir: true, pan: 0.35, speed: 0.16 })
  secCam('ALLÉE / GARAGE', 'Extérieur', 17.5, 2.72, 9.2, 2.36, -0.26, { pan: 0.3, speed: 0.2 })
  secCam('JARDIN NORD', 'Extérieur', 0.45, 2.35, -0.16, 0, -0.24, { ir: true, pan: 0.4, speed: 0.13 })
  secCam('GARAGE', 'Garage', 0.2, 2.79, 8.78, -0.64, -0.24, { pan: 0.28, speed: 0.18 })
  secCam('HALL / ESCALIER', "Hall d'entrée", 6.35, 2.79, 8.75, -0.44, -0.2, { pan: 0.22, speed: 0.24 })
  secCam('CUISINE', 'Cuisine', 17.75, 2.79, 4.25, 1.12, -0.26, {})
  secCam('SALON / SÉJOUR', 'Salon', 10.3, 2.79, 4.95, -2.14, -0.22, { pan: 0.26, speed: 0.2 })
  secCam('COULOIR ÉTAGE', 'Couloir étage', 6.35, 5.79, 8.75, -0.22, -0.18, { pan: 0.3, speed: 0.17 })
  secCam('PALIER / DRESSING', 'Couloir étage', 8.5, 5.79, 4.62, 1.05, -0.2, {})
  secCam('CHAMBRE AMIE', 'Chambre amie', 12.85, 5.79, 4.35, 0.79, -0.26, {})
  secCam('SUITE PARENTALE', 'Suite parentale', 11.75, 5.79, 4.72, -2.1, -0.22, { pan: 0.24, speed: 0.21 })
  secCam('SALLE DE BAIN', 'Salle de bain', 11.5, 5.79, 5.85, 2.26, -0.24, {})
  secCam('BUANDERIE', 'Buanderie', 8.4, 2.79, 2.85, 0.67, -0.28, {})
  secCam('SOUS-SOL', 'Sous-sol', 8.72, -0.02, 8.72, 0.96, -0.32, { ir: true, pan: 0.34, speed: 0.15 })

  cctvMonitor('Écran garage', 5.9, 1.45, 2.1, Math.PI / 2)
  cctvMonitor('Écran hall', 9.93, 1.55, 6.9, Math.PI / 2)
  cctvMonitor('Écran sous-sol', 7.25, -1.75, 8.84, 0)

  const ctx: Ctx = { b, M, T, colliders, rand, addLight, picture, plant, lamp, books, block, makeLeaf }
  furnishGarageAndCar(ctx)
  await checkpoint(84, 'Garage et rez-de-chaussée')
  furnishGround(ctx)
  await checkpoint(90, 'Pièces de vie et buanderie')
  furnishUpper(ctx)
  await checkpoint(95, 'Chambres, bain et dressing')
  furnishBasement(ctx)
  await checkpoint(98, 'Sous-sol et finitions')

  root.add(b.build())

  /* ===================== ZONES / PIÈCES ===================== */
  const zones: Zone[] = [
    { id: 1, name: 'Escalier sous-sol', x: 5.4, z: 0.85, lx: 1.0, lz: 0.85 },
    { id: 2, name: 'Garage', x: 2.2, z: 8.2, lx: 4.2, lz: 4.0 },
    { id: 3, name: 'Couloir étage', x: 8.95, z: 5.1, lx: 11.5, lz: 5.1 },
    { id: 4, name: 'Buanderie', x: 7.2, z: 2.5, lx: 7.2, lz: 0.3 },
    { id: 5, name: 'Salon', x: 11.1, z: 4.9, lx: 16.5, lz: 7.4 },
    { id: 6, name: 'Cuisine', x: 16.6, z: 3.7, lx: 13.7, lz: 2.4 },
    { id: 7, name: 'Chambre amie', x: 10.3, z: 3.7, lx: 9.8, lz: 0.9 },
    { id: 8, name: 'Salle de bain', x: 10.2, z: 6.4, lx: 10.6, lz: 8.6 },
    { id: 9, name: 'Suite parentale', x: 12.4, z: 5.4, lx: 17.4, lz: 6.9 },
    { id: 10, name: 'Façade extérieure', x: 9.0, z: 19.0, lx: 9.0, lz: 9.0 },
    { id: 11, name: 'Sous-sol', x: 1.5, z: 3.0, lx: 6.0, lz: 6.5 },
  ]
  const rooms: RoomRect[] = [
    { name: 'Escalier sous-sol', level: -1, x1: 0.3, x2: 4.5, z1: 0, z2: 1.5 },
    { name: 'Local technique', level: -1, x1: 6.4, x2: 9, z1: 5.8, z2: 9 },
    { name: 'Sous-sol', level: -1, x1: 0, x2: 9, z1: 0, z2: 9 },
    { name: 'Couloir étage', level: 1, x1: 6, x2: 8.6, z1: 0, z2: 9 },
    { name: 'Couloir étage', level: 1, x1: 8.6, x2: 11.6, z1: 4.5, z2: 5.7 },
    { name: 'Chambre amie', level: 1, x1: 8.6, x2: 13, z1: 0, z2: 4.5 },
    { name: 'Salle de bain', level: 1, x1: 8.6, x2: 11.6, z1: 5.7, z2: 9 },
    { name: 'Dressing', level: 1, x1: 13, x2: 18, z1: 0, z2: 4.5 },
    { name: 'Suite parentale', level: 1, x1: 11.6, x2: 18, z1: 4.5, z2: 9 },
    { name: 'Garage', level: 0, x1: 0, x2: 6, z1: 0, z2: 9 },
    { name: 'Buanderie', level: 0, x1: 6, x2: 8.5, z1: 0, z2: 3 },
    { name: 'WC', level: 0, x1: 8.5, x2: 10, z1: 0, z2: 3 },
    { name: "Hall d'entrée & escalier", level: 0, x1: 6, x2: 10, z1: 3, z2: 9 },
    { name: 'Cuisine', level: 0, x1: 10, x2: 18, z1: 0, z2: 4.5 },
    { name: 'Salon', level: 0, x1: 10, x2: 18, z1: 4.5, z2: 9 },
    { name: 'Porche', level: 0, x1: 6, x2: 12.3, z1: 9, z2: 11.9 },
  ]

  return { root, colliders, surfaces, doors, lights, zones, rooms, cams, monitors, objects: b.objects, openings, slabs }
}
