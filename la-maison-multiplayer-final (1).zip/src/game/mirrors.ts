import * as THREE from 'three'
import { Reflector } from 'three/examples/jsm/objects/Reflector.js'

interface MirrorSpec {
  name: string
  center: [number, number, number]
  width: number
  height: number
  rotY: number
  round?: boolean
}

// Laid exactly over the existing mirror surfaces; the original geometry stays underneath.
const SPECS: MirrorSpec[] = [
  { name: 'Miroir de la salle de bain', center: [8.703, 4.675, 6.8], width: 1.0, height: 0.85, rotY: Math.PI / 2 },
  { name: 'Miroir rond du salon', center: [10.148, 1.38, 5.35], width: 0.84, height: 0.84, rotY: Math.PI / 2, round: true },
  { name: 'Miroir de la suite parentale', center: [11.703, 4.55, 7.6], width: 1.2, height: 0.9, rotY: Math.PI / 2 },
  { name: 'Miroir des WC', center: [9.918, 1.55, 2.0], width: 0.5, height: 0.7, rotY: -Math.PI / 2 },
  { name: 'Miroir du dressing', center: [17.818, 4.075, 0.8], width: 0.8, height: 1.75, rotY: -Math.PI / 2 },
]

/**
 * Real planar reflections. Only the nearest mirrors you can actually see render, because
 * each one draws the house a second time. What a mirror shows is what is really in the room.
 */
export class Mirrors {
  readonly group = new THREE.Group()
  private items: { mesh: Reflector; spec: MirrorSpec; normal: THREE.Vector3; center: THREE.Vector3 }[] = []
  enabled = true

  constructor() {
    for (const spec of SPECS) {
      const geometry = spec.round ? new THREE.CircleGeometry(spec.width / 2, 40) : new THREE.PlaneGeometry(spec.width, spec.height)
      const mesh = new Reflector(geometry, {
        color: 0xb7c0c5,
        textureWidth: spec.round ? 512 : 768,
        textureHeight: spec.round ? 512 : 768,
        clipBias: 0.003,
      })
      mesh.position.set(...spec.center)
      mesh.rotation.y = spec.rotY
      mesh.visible = false
      mesh.name = spec.name
      this.group.add(mesh)
      const normal = new THREE.Vector3(Math.sin(spec.rotY), 0, Math.cos(spec.rotY))
      this.items.push({ mesh, spec, normal, center: new THREE.Vector3(...spec.center) })
    }
    this.group.name = 'mirrors'
  }

  update(player: THREE.Vector3, eye: THREE.Vector3, active: boolean) {
    const candidates: { index: number; score: number }[] = []
    this.items.forEach((item, index) => {
      const to = eye.clone().sub(item.center)
      const distance = to.length()
      const facing = item.normal.dot(to) / Math.max(distance, 0.001)
      const sameLevel = Math.abs(item.center.y - eye.y) < 2.1
      const near = distance < 7 && facing > 0.15 && sameLevel && Math.abs(player.y - (item.center.y - 1.6)) < 2.2
      if (this.enabled && active && near) candidates.push({ index, score: distance })
    })
    candidates.sort((a, b) => a.score - b.score)
    const allowed = new Set(candidates.slice(0, 2).map((c) => c.index))
    this.items.forEach((item, index) => { item.mesh.visible = allowed.has(index) })
  }

  dispose() {
    this.items.forEach((item) => { item.mesh.geometry.dispose(); item.mesh.dispose() })
    this.group.removeFromParent()
  }
}
