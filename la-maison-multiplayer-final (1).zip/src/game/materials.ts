import * as THREE from 'three'
import { cm } from './builder'
import type { Textures } from './textures'

export function createMaterials(T: Textures) {
  const std = (o: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial({ envMapIntensity: 0.34, ...o })

  const glass = std({
    color: 0x8fa8ba,
    transparent: true,
    opacity: 0.18,
    roughness: 0.035,
    metalness: 0.15,
    envMapIntensity: 1.35,
    depthWrite: false,
  })
  glass.userData.noShadow = true

  const gableGlass = std({
    color: 0xffd9a0,
    emissive: 0xffbf70,
    emissiveIntensity: 1.3,
    roughness: 0.2,
  })

  const tvScreen = std({ color: 0x050607, roughness: 0.06, metalness: 0.45, envMapIntensity: 1.1, emissive: 0x04070c, emissiveIntensity: 1 })

  const art = [T.art1, T.art2, T.art3].map((t) => std({ map: t, bumpMap: t, bumpScale: 0.006, roughness: 0.58, envMapIntensity: 0.22 }))

  const curtainCache = new Map<number, THREE.MeshStandardMaterial>()
  const curtain = (color: number) => {
    let m = curtainCache.get(color)
    if (!m) {
      m = std({ map: T.fabric, color, roughness: 1, side: THREE.DoubleSide })
      curtainCache.set(color, m)
    }
    return m
  }

  return {
    // murs
    paint: std({ map: T.plaster, bumpMap: T.plaster, bumpScale: 0.008, color: 0xb7ad9e, roughness: 0.96, envMapIntensity: 0.16 }),
    paintLight: std({ map: T.plaster, bumpMap: T.plaster, bumpScale: 0.008, color: 0xcdc7ba, roughness: 0.96, envMapIntensity: 0.16 }),
    paintBath: std({ map: T.plaster, bumpMap: T.plaster, bumpScale: 0.007, color: 0xa7b2b4, roughness: 0.82, envMapIntensity: 0.24 }),
    paintBed: std({ map: T.plaster, bumpMap: T.plaster, bumpScale: 0.008, color: 0xa89d92, roughness: 0.96, envMapIntensity: 0.16 }),
    paintGarage: std({ map: T.plaster, bumpMap: T.plaster, bumpScale: 0.01, color: 0x9d9a92, roughness: 1, envMapIntensity: 0.1 }),
    // Slightly dingy: a ceiling above a shaded fixture receives far less light than the walls around it.
    ceiling: std({ map: T.plaster, bumpMap: T.plaster, bumpScale: 0.006, color: 0x8f8c86, roughness: 1, envMapIntensity: 0.12 }),
    trim: cm(0xe9e5dc, 0.46),
    siding: std({ map: T.siding, bumpMap: T.siding, bumpScale: 0.028, color: 0x7d8790, roughness: 0.86, envMapIntensity: 0.22 }),
    stone: std({ map: T.stone, bumpMap: T.stone, bumpScale: 0.055, roughness: 0.96, envMapIntensity: 0.14 }),
    roof: std({ map: T.roof, bumpMap: T.roof, bumpScale: 0.03, roughness: 0.94, envMapIntensity: 0.1 }),
    concreteWall: std({ map: T.concrete, bumpMap: T.concrete, bumpScale: 0.04, color: 0x8b8985, roughness: 1, envMapIntensity: 0.1 }),
    // sols
    floorWood: std({ map: T.floorWood, bumpMap: T.floorWood, bumpScale: 0.032, roughness: 1, roughnessMap: T.floorRough, envMapIntensity: 0.55 }),
    lightWood: std({ map: T.lightWood, bumpMap: T.lightWood, bumpScale: 0.02, roughness: 0.52, envMapIntensity: 0.3 }),
    tile: std({ map: T.tile, bumpMap: T.tile, bumpScale: 0.012, color: 0xcfc8bc, roughness: 1, roughnessMap: T.tileRough, envMapIntensity: 0.7 }),
    tileDark: std({ map: T.tile, bumpMap: T.tile, bumpScale: 0.012, color: 0x8d8a85, roughness: 1, roughnessMap: T.tileRough, envMapIntensity: 0.55 }),
    concrete: std({ map: T.concrete, bumpMap: T.concrete, bumpScale: 0.038, color: 0xa9a6a1, roughness: 0.88, envMapIntensity: 0.18 }),
    grass: std({ map: T.grass, bumpMap: T.grass, bumpScale: 0.025, roughness: 1, envMapIntensity: 0.05 }),
    asphalt: std({ map: T.asphalt, bumpMap: T.asphalt, bumpScale: 0.025, roughness: 0.96, envMapIntensity: 0.08 }),
    sidewalk: std({ map: T.sidewalk, bumpMap: T.sidewalk, bumpScale: 0.025, roughness: 0.94, envMapIntensity: 0.14 }),
    stairWood: std({ map: T.furnWood, bumpMap: T.furnWood, bumpScale: 0.022, color: 0xd8c0a8, roughness: 0.48, envMapIntensity: 0.3 }),
    // mobilier
    woodDark: std({ map: T.furnWood, bumpMap: T.furnWood, bumpScale: 0.024, roughness: 0.52, envMapIntensity: 0.32 }),
    woodMid: std({ map: T.lightWood, bumpMap: T.lightWood, bumpScale: 0.018, color: 0x9b7a5a, roughness: 0.54, envMapIntensity: 0.3 }),
    marble: std({ map: T.marble, bumpMap: T.marble, bumpScale: 0.005, roughness: 1, roughnessMap: T.marbleRough, metalness: 0.02, envMapIntensity: 0.9 }),
    fabricBeige: std({ map: T.fabric, bumpMap: T.fabric, bumpScale: 0.016, color: 0xcdbfa9, roughness: 1, envMapIntensity: 0.07 }),
    fabricCream: std({ map: T.fabric, bumpMap: T.fabric, bumpScale: 0.016, color: 0xe6dfd0, roughness: 1, envMapIntensity: 0.07 }),
    fabricGrey: std({ map: T.fabric, bumpMap: T.fabric, bumpScale: 0.016, color: 0x8d8a86, roughness: 1, envMapIntensity: 0.07 }),
    fabricDark: std({ map: T.fabric, bumpMap: T.fabric, bumpScale: 0.016, color: 0x4a4744, roughness: 1, envMapIntensity: 0.06 }),
    fabricBlue: std({ map: T.fabric, bumpMap: T.fabric, bumpScale: 0.016, color: 0x607585, roughness: 1, envMapIntensity: 0.08 }),
    linen: std({ map: T.fabric, bumpMap: T.fabric, bumpScale: 0.012, color: 0xf0ece4, roughness: 0.88, envMapIntensity: 0.1 }),
    rugGrey: std({ map: T.rug, bumpMap: T.rug, bumpScale: 0.026, color: 0x8a867f, roughness: 1, envMapIntensity: 0.04 }),
    rugDark: std({ map: T.rug, bumpMap: T.rug, bumpScale: 0.026, color: 0x55524e, roughness: 1, envMapIntensity: 0.04 }),
    rugRed: std({ map: T.rug, bumpMap: T.rug, bumpScale: 0.026, color: 0x8a5b52, roughness: 1, envMapIntensity: 0.04 }),
    leather: std({ map: T.leather, bumpMap: T.leather, bumpScale: 0.018, roughness: 0.58, envMapIntensity: 0.28 }),
    books: std({ map: T.shelfBooks, bumpMap: T.shelfBooks, bumpScale: 0.01, roughness: 0.82, envMapIntensity: 0.12 }),
    cabinet: cm(0xe8e4db, 0.55),
    cabinetDark: cm(0x2a2523, 0.5),
    black: cm(0x16161a, 0.45, 0.3),
    blackMetal: cm(0x222427, 0.4, 0.7),
    steel: cm(0xb7bbbf, 0.28, 0.9),
    chrome: cm(0xd0d4d8, 0.15, 1),
    white: cm(0xf2f0ea, 0.45),
    whiteGloss: cm(0xf4f4f2, 0.2),
    pot: cm(0x5b4a3e, 0.8),
    leaf: cm(0x2f5a32, 0.9),
    leaf2: cm(0x3c6e3a, 0.9),
    soil: cm(0x2b2018, 1),
    cardboard: cm(0x8d6e4b, 0.95),
    red: cm(0xa22a22, 0.5, 0.2),
    yellow: cm(0xc9a42a, 0.5, 0.3),
    blue: cm(0x2f4f78, 0.7),
    orange: cm(0xc8661d, 0.8),
    tote: cm(0x35506e, 0.6),
    pipe: cm(0xb87a4a, 0.4, 0.8),
    mirror: std({ color: 0xaab4bc, roughness: 0.025, metalness: 1, envMapIntensity: 1.5, emissive: 0x151a20, emissiveIntensity: 0.6 }),
    frame: cm(0x1d1a18, 0.42),
    carPaint: std({ color: 0x9fa2a6, roughness: 0.18, metalness: 0.72, envMapIntensity: 1.15 }),
    carGlass: std({ color: 0x0c1118, roughness: 0.05, metalness: 0.8 }),
    tire: cm(0x111113, 0.9),
    tvScreen,
    // éclairage
    bulb: cm(0xfff2d4, 0.4, 0, 0xffe2a8, 2.2),
    tube: cm(0xf2f6ff, 0.4, 0, 0xdfeaff, 2.0),
    shade: cm(0xf1d9ae, 0.9, 0, 0xffc77a, 1.0),
    lantern: cm(0xffe3b0, 0.4, 0, 0xffc877, 2.4),
    pathLight: cm(0xffe0a6, 0.4, 0, 0xffc060, 2.2),
    streetLamp: cm(0xffd9a0, 0.4, 0, 0xffbf70, 2.4),
    windowLit: cm(0xffd9a0, 0.4, 0, 0xffbf70, 1.4),
    gableGlass,
    glass,
    art,
    curtain,
    fence: std({ map: T.furnWood, color: 0x8c7d6e, roughness: 0.9 }),
    trunk: cm(0x3a2c20, 1),
    pine: cm(0x15301e, 1),
    pine2: cm(0x1c3d27, 1),
    bush: cm(0x1e3a22, 1),
    bush2: cm(0x2a4a2a, 1),
    flower: cm(0xb85a7a, 1),
    moon: cm(0xe8efff, 1, 0, 0xdfe8ff, 1.2),
    dash: cm(0xb59a2a, 0.9),
    houseDark: cm(0x2c3036, 1),
    roofDark: cm(0x1b1c20, 1),
  }
}
export type Mats = ReturnType<typeof createMaterials>
