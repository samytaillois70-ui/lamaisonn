export interface Settings {
  brightness: number
  sensitivity: number
  fov: number
  volume: number
  motion: boolean
  reducedEffects: boolean
  captions: boolean
  quality: 'balanced' | 'high' | 'ultra'
  duration: number
  intensity: number
}

export const INTENSITIES = [0.8, 1, 1.35]

export const DEFAULT_SETTINGS: Settings = {
  brightness: 1.2, sensitivity: 2, fov: 70, volume: 0.65,
  motion: true, reducedEffects: false, captions: true, quality: 'ultra', duration: 20, intensity: 1.35,
}

export function readStorage<T>(key: string): T | null {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) as T : null } catch { return null }
}
export function writeStorage(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true } catch { return false }
}
export function loadSettings(): Settings {
  const value = { ...DEFAULT_SETTINGS, ...readStorage<Partial<Settings>>('la-maison-settings-v1') }
  return {
    ...value,
    brightness: Math.max(0.8, Math.min(1.8, Number(value.brightness) || 1.2)),
    sensitivity: Math.max(0.5, Math.min(4, Number(value.sensitivity) || 2)),
    fov: Math.max(55, Math.min(90, Number(value.fov) || 70)),
    volume: Math.max(0, Math.min(1, Number(value.volume) || 0)),
    quality: ['balanced', 'high', 'ultra'].includes(value.quality) ? value.quality : 'ultra',
    duration: [12, 20, 32].includes(value.duration) ? value.duration : 20,
    intensity: INTENSITIES.includes(Number(value.intensity)) ? Number(value.intensity) : 1,
  }
}
