import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'
import type { HouseSystem } from './house'
import type { PlayerSystem } from './player'
import type { DoorObj } from './world'

export interface LightSwitch { roomId: string; position: THREE.Vector3; mesh: THREE.Group }
interface Emitter { material: THREE.MeshStandardMaterial; base: number; room?: string }

export class LightingSystem {
  switches: LightSwitch[] = []
  states = new Map<string, boolean>()
  overrides = new Map<string, boolean>()
  flickers = new Map<string, number>()
  power = true
  presence = 0
  /** 0..1: cumulative corruption caused by missed manifestations. */
  corruption = 0
  /** Gunshot flash, 1 at the moment of the shot. */
  muzzle = 0
  private muzzleLight!: THREE.PointLight
  /** Overall strength of the house lamps. Calibrated against measured luminance of the rendered rooms. */
  lampGain = 0.3
  /** Lightning, 0..1. Brightens the moonlight that comes through the windows for a fraction of a second. */
  flash = 0
  private pool: THREE.PointLight[] = []
  private assigned: number[] = []
  private emitters: Emitter[] = []
  private timer = 0
  private time = 0
  private sceneAmbient: THREE.HemisphereLight
  private moon: THREE.DirectionalLight
  private adaptation: THREE.PointLight
  private torch: THREE.SpotLight
  private environment: THREE.WebGLRenderTarget
  private accents: THREE.PointLight[] = []
  private doorGlows: { material: THREE.MeshBasicMaterial; door: DoorObj; sides: [string | undefined, string | undefined] }[] = []

  constructor(private scene: THREE.Scene, renderer: THREE.WebGLRenderer, private camera: THREE.PerspectiveCamera, private house: HouseSystem) {
    scene.background = new THREE.Color(0x070b10)
    // Cold night haze: far shapes lose contrast and fade toward the dark, which is what makes distance feel real.
    scene.fog = new THREE.FogExp2(0x070b10, 0.013)
    const generator = new THREE.PMREMGenerator(renderer)
    const roomEnvironment = new RoomEnvironment()
    this.environment = generator.fromScene(roomEnvironment, 0.05)
    scene.environment = this.environment.texture
    scene.environmentIntensity = 0.055
    roomEnvironment.dispose()
    generator.dispose()
    this.sceneAmbient = new THREE.HemisphereLight(0x6a7d9a, 0x302b23, 0.048)
    scene.add(this.sceneAmbient)
    this.moon = new THREE.DirectionalLight(0x9dadce, 0.62)
    this.moon.position.set(22, 16, 34)
    this.moon.target.position.set(10, 1, 3)
    this.moon.castShadow = true
    this.moon.shadow.mapSize.set(1024, 1024)
    Object.assign(this.moon.shadow.camera, { left: -20, right: 20, top: 18, bottom: -14, near: 1, far: 70 })
    this.moon.shadow.bias = -0.00015
    this.moon.shadow.normalBias = 0.025
    this.moon.shadow.autoUpdate = false
    this.moon.shadow.needsUpdate = true
    scene.add(this.moon, this.moon.target)
    for (let i = 0; i < 4; i++) {
      const light = new THREE.PointLight(0xffd4a0, 0, 10, 2)
      light.castShadow = true
      light.shadow.mapSize.set(i < 2 ? 512 : 256, i < 2 ? 512 : 256)
      light.shadow.camera.near = 0.06
      light.shadow.camera.far = 15
      light.shadow.bias = -0.0001
      light.shadow.normalBias = 0.025
      light.shadow.autoUpdate = false
      // A shadow-casting light with no map yet makes every draw call invalid, so the first map is forced.
      light.shadow.needsUpdate = true
      scene.add(light)
      this.pool.push(light)
    }
    this.torch = new THREE.SpotLight(0xffefda, 0, 20, 0.39, 0.88, 1.82)
    this.torch.castShadow = true
    this.torch.shadow.mapSize.set(1024, 1024)
    this.torch.shadow.camera.near = 0.045
    this.torch.shadow.camera.far = 20
    this.torch.shadow.bias = -0.00008
    this.torch.shadow.normalBias = 0.018
    this.torch.shadow.autoUpdate = false
    this.torch.shadow.needsUpdate = true
    // The beam starts at the lens of the torch the player is holding.
    this.torch.position.set(0.17, -0.165, -0.56)
    this.torch.target.position.set(0, -0.02, -7)
    const cookie = document.createElement('canvas')
    cookie.width = cookie.height = 128
    const ctx = cookie.getContext('2d')!
    const radial = ctx.createRadialGradient(64, 64, 2, 64, 64, 64)
    radial.addColorStop(0, '#ffffff'); radial.addColorStop(0.25, '#ededde'); radial.addColorStop(0.58, '#99998c'); radial.addColorStop(1, '#000000')
    ctx.fillStyle = radial; ctx.fillRect(0, 0, 128, 128)
    this.torch.map = new THREE.CanvasTexture(cookie)
    camera.add(this.torch, this.torch.target)
    this.adaptation = new THREE.PointLight(0x8c9aac, 0.14, 2.1, 2)
    camera.add(this.adaptation)
    this.muzzleLight = new THREE.PointLight(0xffd9a0, 0, 9, 2)
    this.muzzleLight.position.set(-0.17, -0.12, -0.75)
    camera.add(this.muzzleLight)
    const seen = new Set<THREE.Material>()
    house.world.root.traverse((child) => {
      if (!(child instanceof THREE.Mesh)) return
      for (const material of Array.isArray(child.material) ? child.material : [child.material]) {
        if (!(material instanceof THREE.MeshStandardMaterial) || seen.has(material)) continue
        seen.add(material)
        const p = material.userData.emitterPoint as number[] | undefined
        if (p) this.emitters.push({ material, base: material.userData.emitterBase as number, room: house.roomForPoint(new THREE.Vector3(...p as [number, number, number]))?.id })
      }
    })
    this.addSwitches()
    this.addDoorGlows()
    this.reset()
  }

  private addSwitches() {
    const plate = new THREE.MeshStandardMaterial({ color: 0xc8c2b7, roughness: 0.62 })
    const rocker = new THREE.MeshStandardMaterial({ color: 0xe0d9cf, roughness: 0.4 })
    for (const room of this.house.rooms) {
      const opening = this.house.world.openings.find((o) => {
        if (o.kind !== 'door' && o.kind !== 'arch' || Math.abs(o.floor - room.level * 3) > 0.1) return false
        return [-1, 1].some((side) => {
          const p = o.position.clone()
          p[o.axis === 'x' ? 'z' : 'x'] += side * 0.3
          return this.house.roomAt(p, room.level)?.id === room.id
        })
      })
      if (!opening) continue
      for (const side of [-1, 1]) {
        const test = opening.position.clone()
        test[opening.axis === 'x' ? 'z' : 'x'] += side * 0.35
        if (this.house.roomAt(test, room.level)?.id !== room.id) continue
        const position = opening.position.clone()
        position.y = opening.floor + 1.22
        position[opening.axis] += opening.width / 2 + 0.13
        position[opening.axis === 'x' ? 'z' : 'x'] += side * 0.132
        const group = new THREE.Group()
        const base = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.135, 0.018), plate)
        const button = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.079, 0.016), rocker)
        button.position.z = 0.013
        group.add(base, button)
        group.position.copy(position)
        group.rotation.y = opening.axis === 'x' ? (side > 0 ? 0 : Math.PI) : side * Math.PI / 2
        this.scene.add(group)
        this.switches.push({ roomId: room.id, position, mesh: group })
        break
      }
    }
  }

  /** Light leaking under closed interior doors from a lit room on either side. */
  private addDoorGlows() {
    const unit = new THREE.BoxGeometry(1, 1, 1)
    for (const door of this.house.world.doors) {
      if (door.kind !== 'door' || door.locked) continue
      const c = door.collider
      const alongX = c.x2 - c.x1 > c.z2 - c.z1
      const width = (alongX ? c.x2 - c.x1 : c.z2 - c.z1) - 0.06
      const offsets: [number, number][] = alongX ? [[0, 0.32], [0, -0.32]] : [[0.32, 0], [-0.32, 0]]
      const level = Math.round(door.y / 3)
      const sides = offsets.map(([ox, oz]) => this.house.roomAt(new THREE.Vector3(door.x + ox, door.y + 0.5, door.z + oz), level)?.id) as [string | undefined, string | undefined]
      const material = new THREE.MeshBasicMaterial({ color: 0xffd7a2, transparent: true, opacity: 0, depthWrite: false, toneMapped: false })
      const mesh = new THREE.Mesh(unit, material)
      mesh.scale.set(alongX ? width : 0.12, 0.004, alongX ? 0.12 : width)
      mesh.position.set(door.x, door.y + 0.004, door.z)
      mesh.renderOrder = 3
      this.scene.add(mesh)
      this.doorGlows.push({ material, door, sides })
    }
  }

  reset() {
    this.power = true
    this.overrides.clear()
    this.flickers.clear()
    this.states.clear()
    this.house.rooms.forEach((r) => this.states.set(r.id, ['Salon', "Hall d'entrée & escalier", 'Couloir étage', 'WC', 'Local technique'].includes(r.name)))
  }

  isOn(room?: string) { return this.power && !!room && (this.overrides.get(room) ?? this.states.get(room) ?? false) }
  toggle(room: string) { this.states.set(room, !this.isOn(room)) }
  invalidateShadows() {
    this.pool.forEach((l) => { l.shadow.needsUpdate = true })
    this.moon.shadow.needsUpdate = true
  }

  brightness(p: THREE.Vector3) {
    let light = 0.025
    for (const src of this.house.world.lights) {
      const room = this.house.roomForPoint(src.pos)
      if (!this.isOn(room?.id)) continue
      const distance = p.distanceTo(src.pos)
      if (distance > 7 || this.house.occlusion(p, src.pos, false) > 0) continue
      light += src.intensity / Math.max(1, distance * distance) * 0.06
    }
    return Math.min(1, light)
  }

  /** Keeps the beam origin at the lens when the hand pulls the torch back toward the body near a wall. */
  setTorchRetract(r: number) {
    this.torch.position.set(0.17 - r * 0.06, -0.165 - r * 0.1, -0.5 + r * 0.34)
  }

  /** Lit lamps close to a point and in the same room, for effects that should only appear where light really is. */
  litSources(p: THREE.Vector3, radius: number, limit: number) {
    const room = this.house.roomAt(p)
    const found: { pos: THREE.Vector3; d: number }[] = []
    for (const src of this.house.world.lights) {
      const d = src.pos.distanceTo(p)
      if (d > radius || Math.abs(src.pos.y - p.y) > 2.6) continue
      const r = this.house.roomForPoint(src.pos)
      if (!r || r.id !== room?.id || !this.isOn(r.id)) continue
      found.push({ pos: src.pos, d })
    }
    return found.sort((a, b) => a.d - b.d).slice(0, limit).map((f) => f.pos)
  }

  addAccent(position: THREE.Vector3) {
    const light = new THREE.PointLight(0xadc1cf, 0, 3.5)
    light.position.copy(position)
    this.scene.add(light)
    this.accents.push(light)
    return light
  }

  removeAccent(light: THREE.PointLight) {
    light.intensity = 0
    light.removeFromParent()
    this.accents = this.accents.filter((entry) => entry !== light)
  }

  tick(dt: number, player: PlayerSystem, cameraMode: boolean, preview: boolean, dawn: number, reducedEffects: boolean) {
    this.time += dt
    this.timer -= dt
    this.muzzle = Math.max(0, this.muzzle - dt * 9)
    this.muzzleLight.intensity = this.muzzle * 70
    for (const glow of this.doorGlows) {
      const lit = !glow.door.locked && glow.door.t < 0.2 && (this.isOn(glow.sides[0]) || this.isOn(glow.sides[1]))
      glow.material.opacity += ((lit ? 0.5 : 0) - glow.material.opacity) * Math.min(1, dt * 7)
    }
    const flash = this.flash
    this.scene.environmentIntensity = (preview ? 0.16 : 0.042 + dawn * 0.22) + flash * 0.35
    this.sceneAmbient.intensity = (preview ? 0.14 : 0.043 + dawn * 0.65) + flash * 0.55
    this.moon.intensity = 0.62 + dawn * 0.9 + flash * 4.2
    this.moon.color.set(flash > 0.05 ? 0xd7e3ff : dawn > 0.1 ? 0xe2ccab : 0x9dadce)
    if (dawn > 0) {
      const sky = new THREE.Color(0x172737).lerp(new THREE.Color(0xaaa08d), dawn)
      this.scene.background = sky
      if (this.scene.fog instanceof THREE.FogExp2) this.scene.fog.color.copy(sky).multiplyScalar(0.55)
    }
    const charge = THREE.MathUtils.clamp(player.battery / 100, 0, 1)
    const lowBatteryDip = !reducedEffects && player.battery > 0 && player.battery < 16
      ? 0.86 + Math.sin(this.time * 11.7) * 0.05 + Math.sin(this.time * 29.3) * 0.025
      : 1
    const handMicroMovement = reducedEffects ? 1 : 1 + Math.sin(this.time * 7.3) * 0.008 + Math.sin(this.time * 13.1) * 0.005
    // Near the creature, the beam tires and falters. Strong only when it is very close.
    const presenceDip = reducedEffects ? 1 : 1 - this.presence * (0.18 + Math.abs(Math.sin(this.time * 19)) * 0.3 * (Math.sin(this.time * 3.1) > 0.3 ? 1 : 0.2))
    const corruptionDip = reducedEffects ? 1 : 1 - this.corruption * (0.18 + Math.abs(Math.sin(this.time * 2.7)) * 0.14)
    this.torch.intensity = !preview && !cameraMode && player.flashlight && player.battery > 0
      ? 128 * (0.52 + charge * 0.48) * lowBatteryDip * handMicroMovement * presenceDip * corruptionDip : 0
    this.torch.angle = 0.39 - charge * 0.018
    this.torch.distance = 17 + charge * 3
    this.torch.shadow.needsUpdate = this.torch.intensity > 0
    this.adaptation.intensity = cameraMode ? 0.045 : player.flashlight ? 0.055 : 0.13
    this.adaptation.distance = player.flashlight ? 1.5 : 2.05
    if (this.timer <= 0) {
      this.timer = 0.28
      const viewpoint = this.camera.position
      const selected = this.house.world.lights.map((src, id) => ({ id, distance: src.pos.distanceTo(viewpoint) + Math.abs(src.pos.y - viewpoint.y) * 2 }))
        .filter(({ id }) => this.house.roomForPoint(this.house.world.lights[id].pos))
        .sort((a, b) => a.distance - b.distance).slice(0, this.pool.length)
      this.assigned = selected.map((s) => s.id)
      this.pool.forEach((lamp, i) => {
        const src = this.house.world.lights[this.assigned[i]]
        if (!src) return
        if (!lamp.position.equals(src.pos)) lamp.shadow.needsUpdate = true
        lamp.position.copy(src.pos)
        // A ceiling bulb sits a hand's width from the plaster, which would burn a hot spot there.
        // Real fixtures have a shade and a diffuser, so the light is moved down to the shade's level.
        const floor = Math.floor((src.pos.y + 0.04) / 3) * 3
        if (src.pos.y - floor > 2.25) lamp.position.y -= 0.44
        lamp.color.copy(src.color)
        lamp.distance = Math.min(10, src.dist)
      })
    }
    this.pool.forEach((lamp, i) => {
      const src = this.house.world.lights[this.assigned[i]]
      if (!src) { lamp.intensity = 0; return }
      const room = this.house.roomForPoint(src.pos)
      const on = preview ? ['Salon', "Hall d'entrée & escalier", 'Cuisine'].includes(room?.name ?? '') : this.isOn(room?.id)
      let flicker = 1
      const until = this.flickers.get(room?.id ?? '') ?? 0
      if (!reducedEffects && until > this.time) flicker = Math.sin(this.time * 18) > 0.45 ? 0.35 : 1
      const corruption = preview ? 1 : Math.max(0.55, 1 - this.corruption * 0.32)
      lamp.intensity = THREE.MathUtils.damp(lamp.intensity, on ? src.intensity * (preview ? this.lampGain * 1.75 : this.lampGain) * flicker * corruption : 0, 16, dt || 0.016)
    })
    for (const e of this.emitters) {
      if (!e.room) continue
      e.material.emissiveIntensity = e.base * (preview || this.isOn(e.room) ? 0.8 : 0.002)
    }
  }

  flicker(room: string, seconds = 0.55) { this.flickers.set(room, this.time + seconds) }

  dispose() {
    this.environment.dispose()
    this.torch.map?.dispose()
    this.torch.shadow.map?.dispose()
    this.pool.forEach((l) => l.shadow.map?.dispose())
    this.moon.shadow.map?.dispose()
  }
}