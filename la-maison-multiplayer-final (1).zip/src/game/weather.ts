import * as THREE from 'three'
import type { HouseAudio } from './audio'
import type { LightingSystem } from './lighting'

/**
 * Night weather. A steady rain that thickens toward dawn, and storms far enough away
 * that the thunder always trails the flash: one second of delay is roughly 340 m.
 */
export class Weather {
  rain = 0.55
  private nextStrike = 70
  private strike: { t: number; delay: number; thundered: boolean; double: boolean } | null = null
  private clock = 0

  constructor(private lights: LightingSystem, private audio: HouseAudio) {}

  reset() {
    this.rain = 0.55
    this.nextStrike = 60 + Math.random() * 60
    this.strike = null
    this.lights.flash = 0
  }

  tick(dt: number, progress: number, playing: boolean, reduced: boolean) {
    this.clock += dt
    // Rain drifts between light and steady, trending heavier as the night goes on.
    const target = 0.5 + progress * 0.55 + Math.sin(this.clock / 83) * 0.12 + Math.sin(this.clock / 29) * 0.05
    this.rain += (target - this.rain) * Math.min(1, dt * 0.05)
    this.audio.setRain(THREE.MathUtils.clamp(this.rain, 0.25, 1.5))

    if (playing && !this.strike) {
      this.nextStrike -= dt
      if (this.nextStrike <= 0) {
        this.nextStrike = 85 + Math.random() * 150
        this.strike = { t: 0, delay: 1.2 + Math.random() * 5.5, thundered: false, double: Math.random() < 0.4 }
      }
    }
    const s = this.strike
    if (!s) {
      this.lights.flash += (0 - this.lights.flash) * Math.min(1, dt * 18)
      return
    }
    s.t += dt
    // The flash is a very fast flicker, often twice, never a steady light.
    let flash = 0
    if (s.t < 0.09) flash = 1
    else if (s.t < 0.16) flash = 0.18
    else if (s.double && s.t < 0.27) flash = 0.85
    else if (s.t < 0.55) flash = Math.max(0, 0.3 - (s.t - 0.27) * 0.9) * (s.double ? 1 : 0.4)
    this.lights.flash = reduced ? Math.min(flash, 0.35) : flash
    if (!s.thundered && s.t >= s.delay) {
      s.thundered = true
      this.audio.play('thunder', new THREE.Vector3(10, 12, 60), 0.9)
    }
    if (s.t > s.delay + 7) this.strike = null
  }
}
