import * as THREE from 'three'

let seed = 1337
function rnd() {
  seed |= 0
  seed = (seed + 0x6d2b79f5) | 0
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296
}
const rr = (a: number, b: number) => a + rnd() * (b - a)

function mk(size: number, draw: (c: CanvasRenderingContext2D, s: number) => void, aniso = 8, srgb = true) {
  const cv = document.createElement('canvas')
  cv.width = cv.height = size
  const ctx = cv.getContext('2d')!
  draw(ctx, size)
  const t = new THREE.CanvasTexture(cv)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace
  t.anisotropy = aniso
  return t
}

function speckle(c: CanvasRenderingContext2D, s: number, n: number, light: number, dark: number, alpha = 0.08) {
  for (let i = 0; i < n; i++) {
    const v = rnd() > 0.5 ? light : dark
    c.fillStyle = `rgba(${v},${v},${v},${alpha * rnd() * 2})`
    const z = rr(1, 3)
    c.fillRect(rnd() * s, rnd() * s, z, z)
  }
}

export function makeTextures() {
  seed = 1337
  const wood = (h: number, sat: number, l: number) =>
    mk(1024, (c, s) => {
      const planks = 6
      const ph = s / planks
      for (let i = 0; i < planks; i++) {
        const li = l + rr(-4, 4)
        c.fillStyle = `hsl(${h + rr(-3, 3)},${sat}%,${li}%)`
        c.fillRect(0, i * ph, s, ph)
        for (let k = 0; k < 40; k++) {
          c.strokeStyle = `rgba(0,0,0,${rr(0.03, 0.12)})`
          c.lineWidth = rr(0.5, 1.6)
          const y = i * ph + rnd() * ph
          c.beginPath()
          c.moveTo(0, y)
          c.bezierCurveTo(s * 0.3, y + rr(-3, 3), s * 0.6, y + rr(-3, 3), s, y + rr(-2, 2))
          c.stroke()
        }
        const jx = rnd() * s
        c.fillStyle = 'rgba(0,0,0,0.55)'
        c.fillRect(jx, i * ph, 2, ph)
        c.fillStyle = 'rgba(0,0,0,0.5)'
        c.fillRect(0, i * ph, s, 2)
        c.fillStyle = 'rgba(255,255,255,0.05)'
        c.fillRect(0, i * ph + 2, s, 1)
      }
    })

  const floorWood = wood(24, 38, 20)
  const furnWood = wood(22, 35, 17)
  const lightWood = wood(30, 40, 38)

  const tile = mk(512, (c, s) => {
    c.fillStyle = '#d6d0c6'
    c.fillRect(0, 0, s, s)
    const n = 3
    const ts = s / n
    for (let i = 0; i < n; i++)
      for (let j = 0; j < n; j++) {
        const v = rr(205, 228)
        c.fillStyle = `rgb(${v},${v - 4},${v - 10})`
        c.fillRect(i * ts + 3, j * ts + 3, ts - 6, ts - 6)
      }
    speckle(c, s, 2500, 255, 80, 0.06)
  })

  const concrete = mk(1024, (c, s) => {
    c.fillStyle = '#9a9894'
    c.fillRect(0, 0, s, s)
    speckle(c, s, 14000, 255, 0, 0.09)
    for (let i = 0; i < 14; i++) {
      c.fillStyle = `rgba(0,0,0,${rr(0.02, 0.07)})`
      c.beginPath()
      c.arc(rnd() * s, rnd() * s, rr(10, 60), 0, 7)
      c.fill()
    }
    c.strokeStyle = 'rgba(0,0,0,0.25)'
    c.lineWidth = 1.5
    c.beginPath()
    let x = rnd() * s
    let y = 0
    c.moveTo(x, y)
    for (let i = 0; i < 12; i++) {
      x += rr(-18, 18)
      y += s / 12
      c.lineTo(x, y)
    }
    c.stroke()
    c.strokeRect(0, 0, s, s)
  })

  const siding = mk(512, (c, s) => {
    const n = 5
    const bh = s / n
    for (let i = 0; i < n; i++) {
      const v = rr(150, 172)
      c.fillStyle = `rgb(${v},${v + 4},${v + 10})`
      c.fillRect(0, i * bh, s, bh)
      const g = c.createLinearGradient(0, i * bh, 0, (i + 1) * bh)
      g.addColorStop(0, 'rgba(255,255,255,0.12)')
      g.addColorStop(0.8, 'rgba(0,0,0,0)')
      g.addColorStop(1, 'rgba(0,0,0,0.55)')
      c.fillStyle = g
      c.fillRect(0, i * bh, s, bh)
    }
    speckle(c, s, 3000, 255, 0, 0.05)
  })

  const stone = mk(512, (c, s) => {
    c.fillStyle = '#3d3a37'
    c.fillRect(0, 0, s, s)
    const rows = 6
    const rh = s / rows
    for (let r = 0; r < rows; r++) {
      let x = -rnd() * 60
      while (x < s) {
        const w = rr(60, 130)
        const v = rr(95, 150)
        c.fillStyle = `rgb(${v},${v - 4},${v - 10})`
        c.fillRect(x + 3, r * rh + 3, w - 6, rh - 6)
        c.fillStyle = 'rgba(0,0,0,0.18)'
        c.fillRect(x + 3, r * rh + rh - 12, w - 6, 9)
        x += w
      }
    }
    speckle(c, s, 5000, 255, 0, 0.1)
  })

  const roof = mk(512, (c, s) => {
    c.fillStyle = '#202225'
    c.fillRect(0, 0, s, s)
    const rows = 12
    const rh = s / rows
    for (let r = 0; r < rows; r++) {
      let x = -(r % 2) * 20
      while (x < s) {
        const w = 40
        const v = rr(38, 62)
        c.fillStyle = `rgb(${v},${v + 1},${v + 4})`
        c.fillRect(x + 1, r * rh + 1, w - 2, rh - 2)
        c.fillStyle = 'rgba(0,0,0,0.4)'
        c.fillRect(x + 1, r * rh + rh - 5, w - 2, 4)
        x += w
      }
    }
  })

  const grass = mk(512, (c, s) => {
    c.fillStyle = '#1f3a1c'
    c.fillRect(0, 0, s, s)
    for (let i = 0; i < 9000; i++) {
      const g = rr(40, 95)
      c.strokeStyle = `rgba(${g * 0.5},${g},${g * 0.35},0.55)`
      c.lineWidth = 1
      const x = rnd() * s
      const y = rnd() * s
      c.beginPath()
      c.moveTo(x, y)
      c.lineTo(x + rr(-3, 3), y - rr(3, 9))
      c.stroke()
    }
  })

  const asphalt = mk(512, (c, s) => {
    c.fillStyle = '#2e3033'
    c.fillRect(0, 0, s, s)
    speckle(c, s, 20000, 255, 0, 0.12)
  })

  const sidewalk = mk(512, (c, s) => {
    c.fillStyle = '#a7a5a0'
    c.fillRect(0, 0, s, s)
    speckle(c, s, 9000, 255, 0, 0.08)
    c.strokeStyle = 'rgba(0,0,0,0.35)'
    c.lineWidth = 3
    c.strokeRect(0, 0, s, s)
  })

  const marble = mk(512, (c, s) => {
    c.fillStyle = '#ece9e4'
    c.fillRect(0, 0, s, s)
    for (let i = 0; i < 14; i++) {
      c.strokeStyle = `rgba(90,95,105,${rr(0.08, 0.3)})`
      c.lineWidth = rr(0.6, 2.6)
      c.beginPath()
      let x = rnd() * s
      let y = 0
      c.moveTo(x, y)
      for (let k = 0; k < 10; k++) {
        x += rr(-40, 40)
        y += s / 10
        c.lineTo(x, y)
      }
      c.stroke()
    }
  })

  const plaster = mk(256, (c, s) => {
    c.fillStyle = '#e4e0d8'
    c.fillRect(0, 0, s, s)
    speckle(c, s, 5000, 255, 0, 0.05)
  })

  const fabric = mk(256, (c, s) => {
    c.fillStyle = '#e8e4dc'
    c.fillRect(0, 0, s, s)
    for (let i = 0; i < s; i += 3) {
      c.fillStyle = 'rgba(0,0,0,0.055)'
      c.fillRect(i, 0, 1, s)
      c.fillRect(0, i, s, 1)
      c.fillStyle = 'rgba(255,255,255,0.045)'
      c.fillRect(i + 1, 0, 1, s)
      c.fillRect(0, i + 1, s, 1)
    }
    for (let i = 0; i < 900; i++) {
      c.fillStyle = `rgba(70,64,54,${rr(0.03, 0.1)})`
      c.fillRect(rnd() * s, rnd() * s, rr(2, 6), 1)
    }
    speckle(c, s, 4000, 255, 0, 0.1)
  })

  const rug = mk(256, (c, s) => {
    c.fillStyle = '#b9b3a9'
    c.fillRect(0, 0, s, s)
    for (let i = 0; i < 5000; i++) {
      const v = rr(120, 220)
      c.fillStyle = `rgba(${v},${v - 4},${v - 8},0.3)`
      c.fillRect(rnd() * s, rnd() * s, 2, 4)
    }
  })

  const art1 = mk(256, (c, s) => {
    const g = c.createLinearGradient(0, 0, 0, s)
    g.addColorStop(0, '#d9d2c4')
    g.addColorStop(0.6, '#8f9aa0')
    g.addColorStop(1, '#3b4448')
    c.fillStyle = g
    c.fillRect(0, 0, s, s)
    c.fillStyle = '#2a3236'
    c.beginPath()
    c.moveTo(0, s * 0.75)
    for (let i = 0; i <= 8; i++) c.lineTo((i * s) / 8, s * rr(0.45, 0.7))
    c.lineTo(s, s)
    c.lineTo(0, s)
    c.fill()
  })
  const art2 = mk(256, (c, s) => {
    c.fillStyle = '#d8cfc0'
    c.fillRect(0, 0, s, s)
    for (let i = 0; i < 7; i++) {
      c.fillStyle = `hsla(${rr(15, 40)},${rr(20, 50)}%,${rr(25, 55)}%,0.8)`
      c.beginPath()
      c.arc(rnd() * s, rnd() * s, rr(25, 70), 0, 7)
      c.fill()
    }
  })
  const art3 = mk(256, (c, s) => {
    c.fillStyle = '#cfcfcf'
    c.fillRect(0, 0, s, s)
    c.fillStyle = '#222'
    c.fillRect(s * 0.18, s * 0.55, s * 0.64, s * 0.3)
    c.fillStyle = '#777'
    c.fillRect(0, s * 0.62, s, s * 0.05)
    c.fillStyle = '#eee'
    c.beginPath()
    c.arc(s * 0.7, s * 0.25, s * 0.08, 0, 7)
    c.fill()
  })

  const shelfBooks = mk(256, (c, s) => {
    c.fillStyle = '#1c1a18'
    c.fillRect(0, 0, s, s)
    let x = 0
    while (x < s) {
      const w = rr(8, 20)
      c.fillStyle = `hsl(${rr(0, 360)},${rr(10, 40)}%,${rr(20, 45)}%)`
      c.fillRect(x, rr(0, 30), w - 1, s)
      x += w
    }
  })

  const leather = mk(256, (c, s) => {
    c.fillStyle = '#4a3a30'
    c.fillRect(0, 0, s, s)
    speckle(c, s, 5000, 255, 0, 0.08)
    for (let i = 0; i < 46; i++) {
      c.strokeStyle = `rgba(20,12,8,${rr(0.05, 0.16)})`
      c.lineWidth = rr(0.5, 1.1)
      const x = rnd() * s
      const y = rnd() * s
      c.beginPath()
      c.moveTo(x, y)
      c.bezierCurveTo(x + rr(-18, 18), y + rr(-5, 5), x + rr(-24, 24), y + rr(-8, 8), x + rr(-30, 30), y + rr(-10, 10))
      c.stroke()
    }
    for (let i = 0; i < 28; i++) {
      c.fillStyle = `rgba(255,226,190,${rr(0.025, 0.07)})`
      c.beginPath()
      c.ellipse(rnd() * s, rnd() * s, rr(4, 18), rr(1, 4), rnd() * 3, 0, 7)
      c.fill()
    }
  })

  // Roughness maps (the green channel is read). They use their own generator so the colour
  // textures above, and therefore the look of the house, stay exactly as they were.
  let rs = 90210
  const r3 = () => {
    rs = (Math.imul(rs, 1664525) + 1013904223) >>> 0
    return rs / 4294967296
  }
  const ra = (a: number, b: number) => a + r3() * (b - a)
  const grey = (v: number) => `rgb(${v},${v},${v})`

  // Varnished floorboards: a worn, scuffed path where people walk, rougher plank edges,
  // glossier protected areas along the walls.
  const floorRough = mk(1024, (c, s) => {
    c.fillStyle = grey(112)
    c.fillRect(0, 0, s, s)
    for (let i = 0; i < 140; i++) {
      c.fillStyle = `rgba(${r3() > 0.5 ? '190,190,190' : '70,70,70'},${ra(0.06, 0.22)})`
      c.beginPath()
      c.ellipse(r3() * s, r3() * s, ra(18, 120), ra(4, 22), r3() * 3.14, 0, 7)
      c.fill()
    }
    for (let i = 0; i < 90; i++) {
      c.strokeStyle = `rgba(215,215,215,${ra(0.2, 0.6)})`
      c.lineWidth = ra(0.5, 1.4)
      c.beginPath()
      const x = r3() * s
      const y = r3() * s
      c.moveTo(x, y)
      c.lineTo(x + ra(-60, 60), y + ra(-14, 14))
      c.stroke()
    }
    for (let i = 0; i < 6; i++) {
      c.fillStyle = grey(205)
      c.fillRect(0, (i * s) / 6, s, 3)
    }
  }, 8, false)

  // Glazed tiles: shiny faces, matt grout, a few water and finger smudges.
  const tileRough = mk(512, (c, s) => {
    c.fillStyle = grey(232)
    c.fillRect(0, 0, s, s)
    const n = 3
    const ts = s / n
    for (let i = 0; i < n; i++)
      for (let j = 0; j < n; j++) {
        c.fillStyle = grey(Math.round(ra(48, 70)))
        c.fillRect(i * ts + 3, j * ts + 3, ts - 6, ts - 6)
      }
    for (let i = 0; i < 36; i++) {
      c.fillStyle = `rgba(160,160,160,${ra(0.08, 0.28)})`
      c.beginPath()
      c.ellipse(r3() * s, r3() * s, ra(6, 34), ra(5, 22), r3() * 3, 0, 7)
      c.fill()
    }
  }, 8, false)

  // Polished stone: very glossy, interrupted by fingerprints and cleaning streaks.
  const marbleRough = mk(512, (c, s) => {
    c.fillStyle = grey(34)
    c.fillRect(0, 0, s, s)
    for (let i = 0; i < 46; i++) {
      c.fillStyle = `rgba(170,170,170,${ra(0.1, 0.4)})`
      c.beginPath()
      c.ellipse(r3() * s, r3() * s, ra(4, 22), ra(5, 28), r3() * 3, 0, 7)
      c.fill()
    }
    for (let i = 0; i < 14; i++) {
      c.strokeStyle = `rgba(150,150,150,${ra(0.1, 0.3)})`
      c.lineWidth = ra(6, 22)
      c.beginPath()
      const x = r3() * s
      c.moveTo(x, r3() * s)
      c.lineTo(x + ra(-30, 30), r3() * s)
      c.stroke()
    }
  }, 8, false)

  return {
    floorRough,
    tileRough,
    marbleRough,
    floorWood,
    furnWood,
    lightWood,
    tile,
    concrete,
    siding,
    stone,
    roof,
    grass,
    asphalt,
    sidewalk,
    marble,
    plaster,
    fabric,
    rug,
    art1,
    art2,
    art3,
    shelfBooks,
    leather,
  }
}
export type Textures = ReturnType<typeof makeTextures>
