import * as THREE from 'three'
import type { SecCam } from './world'
import type { HouseSystem } from './house'
import type { NightSystem } from './night'

/** A camera never stays disconnected longer than this, in seconds. */
export const MAX_OUTAGE = 10

export class CameraSystem {
  feeds: SecCam[]
  selected = 0
  yawOffset = 0
  pitchOffset = 0
  zoom = 0
  autoPan = true
  transition = 0
  signal = 95
  elapsed = 0
  private downUntil: number[] = []
  private glitchUntil: number[] = []
  private nextFault = 45
  private nextGlitch = 16
  private wasDown = false
  private target = new THREE.WebGLRenderTarget(384, 216, { depthBuffer: true })
  private monitorCamera = new THREE.PerspectiveCamera(78, 16 / 9, 0.06, 65)
  private screens: THREE.Mesh[] = []
  private monitorTimer = 0
  private viewYaw = 0
  private viewPitch = 0
  private viewReady = false
  private infrared = new THREE.SpotLight(0xc8d5c8, 0, 11, 0.65, 0.8, 2)

  constructor(private scene: THREE.Scene, private renderer: THREE.WebGLRenderer, private house: HouseSystem, private night: NightSystem) {
    this.feeds = house.world.cams.filter((c) => !!house.roomForPoint(c.pos)).map((c) => ({
      ...c,
      name: c.id === 14 ? 'LOCAL TECHNIQUE' : c.id === 9 ? 'PALIER' : c.name,
      zone: house.roomForPoint(c.pos)!.name,
    }))
    this.downUntil = this.feeds.map(() => 0)
    this.glitchUntil = this.feeds.map(() => 0)
    this.monitorCamera.rotation.order = 'YXZ'
    // The infrared illuminator casts no shadow: a shadow map that is never rendered breaks every draw call.
    this.infrared.castShadow = false
    scene.add(this.infrared, this.infrared.target)
    const material = new THREE.MeshBasicMaterial({ map: this.target.texture, color: 0x97a8a6, toneMapped: false })
    house.world.monitors.forEach((m, index) => {
      const yaw = index < 2 ? Math.PI / 2 : 0
      const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 0.49), material)
      screen.position.set(m.x - Math.sin(yaw) * 0.042, m.y, m.z - Math.cos(yaw) * 0.042)
      screen.rotation.y = yaw + Math.PI
      scene.add(screen)
      this.screens.push(screen)
    })
  }

  get feed() { return this.feeds[this.selected] }
  get room() { return this.feed ? this.house.roomForPoint(this.feed.pos) : undefined }

  /** Seconds left before the selected camera reconnects. Always 0 to 10. */
  get offline() { return Math.max(0, (this.downUntil[this.selected] ?? 0) - this.elapsed) }
  /** A short burst of interference on the selected camera. */
  get glitching() { return this.offline <= 0 && (this.glitchUntil[this.selected] ?? 0) > this.elapsed }
  isDown(index: number) { return (this.downUntil[index] ?? 0) > this.elapsed }
  downList() { return this.downUntil.map((until) => until > this.elapsed) }

  select(index: number) {
    this.selected = (index + this.feeds.length) % this.feeds.length
    this.yawOffset = 0; this.pitchOffset = 0; this.zoom = 0; this.autoPan = true
    this.viewReady = false
    this.transition = 0.28
  }

  reset() {
    this.elapsed = 0
    this.downUntil = this.feeds.map(() => 0)
    this.glitchUntil = this.feeds.map(() => 0)
    this.nextFault = 45
    this.nextGlitch = 16
    this.wasDown = false
    this.select(0)
  }

  orient(camera: THREE.PerspectiveCamera, feed = this.feed, manual = true) {
    if (!feed) return
    const pan = manual && this.autoPan ? Math.sin(this.elapsed * feed.speed) * Math.min(0.3, feed.pan) : 0
    const targetYaw = feed.yaw + pan + (manual ? this.yawOffset : 0)
    const targetPitch = THREE.MathUtils.clamp(feed.pitch + (manual ? this.pitchOffset : 0), -1.2, 0.6)
    let yaw = targetYaw
    let pitch = targetPitch
    if (manual) {
      if (!this.viewReady) {
        this.viewYaw = targetYaw
        this.viewPitch = targetPitch
        this.viewReady = true
      } else {
        const blend = 0.16
        this.viewYaw += Math.atan2(Math.sin(targetYaw - this.viewYaw), Math.cos(targetYaw - this.viewYaw)) * blend
        this.viewPitch += (targetPitch - this.viewPitch) * blend
      }
      yaw = this.viewYaw
      pitch = this.viewPitch
    }
    // Place the optical center ahead of the existing casing, not inside its lens.
    camera.position.copy(feed.pos).add(new THREE.Vector3(-Math.sin(feed.yaw) * 0.27, feed.pos.y < 0 ? -0.16 : -0.025, -Math.cos(feed.yaw) * 0.27))
    camera.rotation.set(pitch, yaw, 0, 'YXZ')
    const targetFov = THREE.MathUtils.clamp(feed.fov - (manual ? this.zoom : 0), 34, 88)
    const fov = manual ? camera.fov + (targetFov - camera.fov) * 0.18 : targetFov
    if (Math.abs(camera.fov - fov) > 0.01) { camera.fov = fov; camera.updateProjectionMatrix() }
  }

  move(dx: number, dy: number) {
    this.autoPan = false
    this.yawOffset = THREE.MathUtils.clamp(this.yawOffset + dx, -0.55, 0.55)
    this.pitchOffset = THREE.MathUtils.clamp(this.pitchOffset + dy, -0.45, 0.3)
  }

  /** Interference is more likely near the creature: the camera closest to it is picked first. */
  private pickFeed(presence: THREE.Vector3 | null, bias: number) {
    if (presence && this.night.random() < bias) {
      let best = -1
      let bestDistance = 14
      this.feeds.forEach((f, i) => {
        const d = Math.hypot(f.pos.x - presence.x, f.pos.z - presence.z) + Math.abs(f.pos.y - 2.6 - presence.y) * 1.5
        if (d < bestDistance) { bestDistance = d; best = i }
      })
      if (best >= 0) return best
    }
    return Math.floor(this.night.random() * this.feeds.length)
  }

  private triggerOutage(presence: THREE.Vector3 | null) {
    this.nextFault = (24 + this.night.random() * 46) * (1 - this.night.progress * 0.45)
    if (this.downUntil.filter((t) => t > this.elapsed).length >= 2) return
    const index = this.pickFeed(presence, 0.55)
    if (this.isDown(index)) return
    const roll = this.night.random()
    const duration = roll < 0.55 ? 1.5 + this.night.random() * 3 : roll < 0.88 ? 4 + this.night.random() * 3 : 7 + this.night.random() * 2.8
    this.downUntil[index] = this.elapsed + Math.min(duration, MAX_OUTAGE - 0.2)
  }

  private triggerGlitch(presence: THREE.Vector3 | null) {
    this.nextGlitch = (9 + this.night.random() * 18) * (1 - this.night.progress * 0.35)
    const index = this.pickFeed(presence, 0.4)
    if (this.isDown(index)) return
    this.glitchUntil[index] = this.elapsed + 0.25 + this.night.random() * 0.7
  }

  tick(dt: number, active: boolean, player: THREE.Vector3, camera: THREE.PerspectiveCamera, presence: THREE.Vector3 | null = null) {
    this.elapsed += dt
    this.transition = Math.max(0, this.transition - dt)
    // Faults happen whether or not anyone is watching, from the first hour on.
    if (dt > 0 && this.night.status === 'active' && this.night.phase >= 1) {
      this.nextFault -= dt
      this.nextGlitch -= dt
      if (this.nextFault <= 0) this.triggerOutage(presence)
      if (this.nextGlitch <= 0) this.triggerGlitch(presence)
    }
    const down = this.offline > 0
    if (this.wasDown && !down) this.transition = 0.3
    this.wasDown = down
    if (active && this.feed) {
      const walls = this.house.occlusion(player.clone().add(new THREE.Vector3(0, 1.3, 0)), this.feed.pos, false)
      this.signal = Math.max(46, Math.round(97 - walls * 7 - player.distanceTo(this.feed.pos) * 0.35 - (this.glitching ? 24 : 0)))
      this.infrared.intensity = this.feed.ir && !down ? 19 : 0
      this.infrared.position.copy(camera.position)
      this.infrared.target.position.copy(camera.position).add(camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(6))
    } else this.infrared.intensity = 0
    this.monitorTimer -= dt
  }

  renderMonitors(player: THREE.Vector3, visible: boolean) {
    if (!visible || this.monitorTimer > 0 || !this.feed) return
    if (!this.house.world.monitors.some((m) => player.distanceTo(new THREE.Vector3(m.x, m.y - 1.3, m.z)) < 3.5)) return
    this.monitorTimer = 0.45
    const index = Math.floor(this.elapsed / 12) % this.feeds.length
    // A dead feed leaves the wall screen frozen on its last image.
    if (this.isDown(index)) return
    const feed = this.feeds[index]
    this.orient(this.monitorCamera, feed, false)
    this.screens.forEach((screen) => { screen.visible = false })
    const original = this.renderer.getRenderTarget()
    this.renderer.setRenderTarget(this.target)
    this.renderer.render(this.scene, this.monitorCamera)
    this.renderer.setRenderTarget(original)
    this.screens.forEach((screen) => { screen.visible = true })
  }

  dispose() { this.target.dispose() }
}
