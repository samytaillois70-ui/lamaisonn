import type { HouseSystem } from './house'
import type { PlayerSystem } from './player'

export function drawHousePlan(canvas: HTMLCanvasElement, house: HouseSystem, player: PlayerSystem, level: number) {
  const c = canvas.getContext('2d')
  if (!c) return
  const w = canvas.width, h = canvas.height
  c.clearRect(0, 0, w, h)
  const bounds = level === 1 ? [5.6, -0.4, 18.4, 9.4] : level === -1 ? [-0.4, -0.4, 9.4, 9.4] : [-0.4, -0.4, 18.4, 9.4]
  const scale = Math.min((w - 72) / (bounds[2] - bounds[0]), (h - 72) / (bounds[3] - bounds[1]))
  const ox = (w - (bounds[2] - bounds[0]) * scale) / 2, oz = (h - (bounds[3] - bounds[1]) * scale) / 2
  const X = (x: number) => ox + (x - bounds[0]) * scale
  const Z = (z: number) => oz + (z - bounds[1]) * scale
  c.strokeStyle = 'rgba(207,203,186,0.035)'; c.lineWidth = 1
  for (let x = 0; x < w; x += 24) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke() }
  for (let y = 0; y < h; y += 24) { c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke() }
  for (const r of house.rooms.filter((room) => room.level === level)) {
    for (const rect of r.areas) {
      c.fillStyle = r.visited ? 'rgba(176,167,136,0.105)' : 'rgba(105,107,100,0.045)'
      c.fillRect(X(rect.x1), Z(rect.z1), (rect.x2 - rect.x1) * scale, (rect.z2 - rect.z1) * scale)
    }
  }
  const y = level * 3
  for (const collider of house.world.colliders) {
    if (collider.kind === 'door' || !collider.active || collider.y1 <= y + 0.15 || collider.y0 >= y + 2.4 || collider.x2 > 18.15 || collider.z2 > 9.15 || collider.x1 < -0.2 || collider.z1 < -0.2) continue
    if (level === 1 && collider.x2 < 5.9 || level === -1 && collider.x1 > 9.1) continue
    c.fillStyle = collider.kind === 'wall' ? '#9b9c8f' : collider.kind === 'window' ? '#66878a' : 'rgba(140,147,140,0.19)'
    c.fillRect(X(collider.x1), Z(collider.z1), Math.max(1.5, (collider.x2 - collider.x1) * scale), Math.max(1.5, (collider.z2 - collider.z1) * scale))
  }
  for (const door of house.world.doors.filter((d) => d.y === y)) {
    const r = door.collider
    c.strokeStyle = door.locked ? '#795953' : door.open ? '#73917d' : '#bba67a'
    c.lineWidth = 2; c.beginPath()
    if (r.x2 - r.x1 > r.z2 - r.z1) { c.moveTo(X(r.x1), Z(door.z)); c.lineTo(X(r.x2), Z(door.z)) }
    else { c.moveTo(X(door.x), Z(r.z1)); c.lineTo(X(door.x), Z(r.z2)) }
    c.stroke()
  }
  c.textAlign = 'center'
  for (const r of house.rooms.filter((room) => room.level === level)) {
    const a = r.areas[0]
    if (r.name === 'Escalier sous-sol') continue
    const x = X((a.x1 + a.x2) / 2), z = Z((a.z1 + a.z2) / 2)
    c.fillStyle = r.visited ? '#d2d1c5' : '#71766d'
    c.font = `${Math.max(10, Math.min(13, scale * 0.34))}px sans-serif`
    const names: Record<string, string[]> = { "Hall d'entrée & escalier": ['HALL', 'ESCALIER'], 'Couloir étage': ['PALIER'], 'Chambre amie': ['CHAMBRE', 'AMIE'], 'Salle de bain': ['SALLE DE', 'BAIN'], 'Suite parentale': ['SUITE', 'PARENTALE'], 'Local technique': ['LOCAL', 'TECHNIQUE'] }
    const lines = names[r.name] ?? [r.name.toUpperCase()]
    lines.forEach((line, i) => c.fillText(line, x, z + i * 16 - (lines.length - 1) * 6))
  }
  for (const cam of house.world.cams) {
    if (house.roomForPoint(cam.pos)?.level !== level) continue
    c.strokeStyle = '#74928f'; c.lineWidth = 1.2
    c.strokeRect(X(cam.pos.x) - 3, Z(cam.pos.z) - 3, 6, 6)
  }
  if (Math.round(player.position.y / 3) === level) {
    c.save(); c.translate(X(player.position.x), Z(player.position.z)); c.rotate(-player.yaw)
    c.fillStyle = '#e1c399'; c.strokeStyle = '#1a1e1d'; c.lineWidth = 2
    c.beginPath(); c.moveTo(0, -9); c.lineTo(6, 7); c.lineTo(0, 4); c.lineTo(-6, 7); c.closePath(); c.fill(); c.stroke(); c.restore()
  }
  c.fillStyle = '#8b9186'; c.font = '10px monospace'; c.textAlign = 'left'
  c.fillText('N', 22, 28)
  c.strokeStyle = '#8b9186'; c.lineWidth = 1
  c.beginPath(); c.moveTo(26, 36); c.lineTo(26, 60); c.moveTo(21, 42); c.lineTo(26, 36); c.lineTo(31, 42); c.stroke()
  c.beginPath(); c.moveTo(w - 2 * scale - 30, h - 23); c.lineTo(w - 30, h - 23); c.stroke()
  c.fillText('2 m', w - 2 * scale - 30, h - 32)
}