import * as THREE from 'three'
import type { HouseSystem } from './house'
import type { LightingSystem } from './lighting'
import type { DoorObj } from './world'
import type { HouseObject } from './builder'

export interface InteractionTarget {
  id: string
  label: string
  kind: 'door' | 'switch' | 'monitor' | 'charger' | 'breaker' | 'letter' | 'object' | 'escape'
  position: THREE.Vector3
  roomId?: string
  door?: DoorObj
  object?: HouseObject
  hold?: number
  escapeId?: string
  disabled?: boolean
}

export const LETTER = [
  'Merci de garder la maison cette nuit.',
  'Les enfants sont chez leur grand-mère. Personne ne doit rentrer avant six heures. J’ai laissé les lumières du hall et du salon allumées.',
  'Faites le tour, regardez où sont les choses. Les trois tabourets sont alignés. La télévision est éteinte. Les cadres sont droits. Prenez une photo si vous hésitez.',
  'La maison travaille la nuit. Un tuyau, le réfrigérateur, une marche : tout n’est pas une anomalie. Mais si quelque chose a vraiment changé, notez la pièce et la nature du changement.',
  'La lampe se recharge dans la buanderie. Si le courant saute, le disjoncteur est au sous-sol, derrière la porte du local technique.',
  'Et si vous entendez des pas qui ne sont pas les vôtres : ne courez pas tout de suite. Éteignez la lampe. Fermez une porte. Attendez derrière quelque chose de solide.',
  'Ne laissez pas les caméras vous faire oublier la pièce dans laquelle vous vous trouvez.',
  'À demain.\nM.',
]

export class InteractionSystem {
  targets: InteractionTarget[] = []

  constructor(private house: HouseSystem, lighting: LightingSystem, scene: THREE.Scene) {
    house.world.doors.forEach((door, i) => door.name === "Porte d'entrée" ? undefined : this.targets.push({ id: `door-${i}`, kind: 'door', label: door.name, position: new THREE.Vector3(door.x, door.y + 1.05, door.z), door }))
    lighting.switches.forEach((s, i) => this.targets.push({ id: `switch-${i}`, kind: 'switch', label: 'Interrupteur', position: s.position, roomId: s.roomId }))
    house.world.monitors.forEach((m, i) => this.targets.push({ id: `monitor-${i}`, kind: 'monitor', label: 'Consulter les caméras', position: new THREE.Vector3(m.x, m.y, m.z) }))
    house.world.objects.forEach((object) => this.targets.push({ id: object.id, kind: 'object', label: object.label, position: object.origin, object }))
    this.targets.push(
      { id: 'charger', kind: 'charger', label: 'Recharger la lampe', position: new THREE.Vector3(7.1, 0.96, 0.59), hold: 6 },
      { id: 'breaker', kind: 'breaker', label: 'Réarmer le disjoncteur', position: new THREE.Vector3(8.79, -1.52, 7.5), hold: 2.5 },
      { id: 'letter', kind: 'letter', label: 'Lire la lettre', position: new THREE.Vector3(9.73, 0.84, 5.67) },
    )
    const dock = new THREE.Group()
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.045, 0.1), new THREE.MeshStandardMaterial({ color: 0x2b2b27, roughness: 0.6 }))
    const diode = new THREE.Mesh(new THREE.BoxGeometry(0.011, 0.005, 0.011), new THREE.MeshStandardMaterial({ color: 0x9aad81, emissive: 0x668345, emissiveIntensity: 0.65 }))
    diode.position.set(0.04, 0.025, 0.027)
    dock.add(base, diode)
    dock.position.set(7.1, 0.927, 0.59)
    scene.add(dock)
    const page = document.createElement('canvas'); page.width = 128; page.height = 192
    const ctx = page.getContext('2d')!
    ctx.fillStyle = '#d5cbb8'; ctx.fillRect(0, 0, 128, 192)
    ctx.fillStyle = '#504a3c'; ctx.font = '10px serif'; ctx.fillText('Pour cette nuit.', 14, 24)
    for (let i = 0; i < 13; i++) { ctx.fillStyle = '#857966'; ctx.fillRect(14, 42 + i * 9, 65 + (i % 3) * 10, 1) }
    const texture = new THREE.CanvasTexture(page); texture.colorSpace = THREE.SRGBColorSpace
    const note = new THREE.Mesh(new THREE.PlaneGeometry(0.19, 0.29), new THREE.MeshStandardMaterial({ map: texture, roughness: 1 }))
    note.rotation.x = -Math.PI / 2; note.rotation.z = 0.07
    note.position.set(9.73, 0.825, 5.67)
    scene.add(note)
  }

  pick(eye: THREE.Vector3, direction: THREE.Vector3, only?: InteractionTarget['kind']) {
    let result: InteractionTarget | null = null
    let best = -Infinity
    for (const target of this.targets) {
      if (only && target.kind !== only || target.disabled || target.object && !target.object.group.visible) continue
      const p = target.object?.group.position ?? target.position
      const to = p.clone().sub(eye)
      const distance = to.length()
      if (distance > (target.kind === 'object' ? 2.5 : 2.15)) continue
      const directionTo = to.normalize()
      const dot = direction.dot(directionTo)
      if (dot < (target.kind === 'switch' ? 0.68 : 0.82)) continue
      const end = p.clone().addScaledVector(directionTo, target.kind === 'door' ? -0.2 : -0.04)
      if (this.house.occlusion(eye, end, false) > 0) continue
      const priority = target.kind === 'object' ? -0.18 : 0
      const score = dot * 2 - distance * 0.15 + priority
      if (score > best) { best = score; result = target }
    }
    return result
  }
}