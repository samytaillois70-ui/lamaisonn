import { cm } from './builder'
import type { Ctx } from './ctx'

const P = Math.PI

function legs4(c: Ctx, x1: number, z1: number, x2: number, z2: number, h: number, t: number, mat: import('three').Material) {
  const { b } = c
  b.bb(x1, 0, z1, x1 + t, h, z1 + t, mat)
  b.bb(x2 - t, 0, z1, x2, h, z1 + t, mat)
  b.bb(x1, 0, z2 - t, x1 + t, h, z2, mat)
  b.bb(x2 - t, 0, z2 - t, x2, h, z2, mat)
}

/* ============================================================ */
export function furnishGarageAndCar(c: Ctx) {
  const { b, M, rand } = c

  // ---------- voiture (berline grise, face à la porte) ----------
  b.push([3.95, 0, 4.9], 0)
  b.bb(-0.9, 0.3, -2.35, 0.9, 0.78, 2.35, M.carPaint)
  b.bb(-0.93, 0.24, -2.2, 0.93, 0.4, 2.2, M.black)
  b.box(0, 0.79, 1.72, 1.78, 0.07, 1.25, M.carPaint, { rot: [0.09, 0, 0] })
  b.box(0, 0.8, -1.8, 1.78, 0.07, 1.15, M.carPaint, { rot: [-0.04, 0, 0] })
  b.bb(-0.77, 0.78, -0.75, 0.77, 1.3, 0.72, M.carPaint)
  b.box(0, 1.05, 1.03, 1.5, 0.03, 0.8, M.carGlass, { rot: [0.67, 0, 0] })
  b.box(0, 1.05, -1.1, 1.5, 0.03, 0.8, M.carGlass, { rot: [-0.68, 0, 0] })
  for (const s of [1, -1]) {
    b.bb(s * 0.775 - 0.01, 0.86, -0.7, s * 0.775 + 0.01, 1.25, 0.65, M.carGlass)
    b.bb(s * 0.9, 1.0, 0.5, s * 1.03, 1.1, 0.72, M.carPaint)
    for (const z of [-1.45, 1.5]) {
      b.cyl(s * 0.86, 0.34 - 0.13, z, 0.34, 0.26, M.tire, { rot: [0, 0, P / 2], seg: 16 })
      b.cyl(s * 0.86 + s * 0.02, 0.34 - 0.13, z, 0.22, 0.26, M.chrome, { rot: [0, 0, P / 2], seg: 10 })
      b.cyl(s * 0.86 + s * 0.03, 0.34 - 0.13, z, 0.08, 0.27, M.blackMetal, { rot: [0, 0, P / 2], seg: 8 })
    }
    b.bb(s * 0.5 - 0.22, 0.62, 2.33, s * 0.5 + 0.38 * s, 0.74, 2.37, cm(0xcfd6dc, 0.1, 0.6))
    b.bb(s * 0.6, 0.62, -2.37, s * 0.88, 0.74, -2.33, cm(0x6a1010, 0.3))
  }
  b.bb(-0.4, 0.42, 2.33, 0.4, 0.58, 2.37, M.black)
  b.bb(-0.2, 0.36, 2.36, 0.2, 0.46, 2.38, M.white)
  b.bb(-0.2, 0.4, -2.38, 0.2, 0.5, -2.36, M.white)
  b.bb(-0.55, 0.3, 2.33, 0.55, 0.4, 2.4, M.black)
  b.pop()
  c.block(3.0, 0, 2.5, 4.9, 1.35, 7.3)

  // ---------- établi ----------
  b.bb(0.13, 0.88, 1.8, 0.8, 0.93, 4.4, M.woodDark, { solid: true })
  legs4(c, 0.13, 1.8, 0.8, 4.4, 0.88, 0.06, M.blackMetal)
  b.bb(0.15, 0.3, 1.85, 0.78, 0.34, 4.35, M.woodMid)
  b.bb(0.13, 0.1, 3.4, 0.7, 0.3, 4.3, M.tote)
  b.bb(0.2, 0.93, 2.0, 0.34, 0.95, 2.2, M.white)
  b.bb(0.28, 0.93, 2.28, 0.42, 0.95, 2.46, M.white)
  b.bb(0.2, 0.93, 3.4, 0.6, 1.1, 3.95, M.red)
  b.bb(0.3, 1.1, 3.6, 0.5, 1.14, 3.8, M.blackMetal)
  b.bb(0.18, 0.93, 2.9, 0.34, 1.05, 3.1, M.blackMetal)
  b.cyl(0.6, 0.93, 2.4, 0.04, 0.16, M.blue, { seg: 8 })
  b.bb(0.125, 1.2, 1.8, 0.16, 2.15, 4.4, cm(0x8a7550, 0.9))
  for (let k = 0; k < 8; k++) {
    const z = 1.95 + k * 0.3
    b.bb(0.16, 1.4 + (k % 3) * 0.2, z, 0.22, 1.85 + (k % 2) * 0.1, z + 0.04, M.blackMetal)
  }
  b.bb(0.16, 1.5, 3.4, 0.3, 1.9, 3.5, M.red)

  // ---------- coffre à outils roulant ----------
  b.beginObject('garage-tools', 'Coffre à outils rouge', 'furniture')
  b.bb(0.9, 0.09, 2.0, 1.5, 1.0, 2.75, M.red, { solid: true })
  b.bb(0.87, 0.98, 1.97, 1.53, 1.04, 2.78, M.blackMetal)
  b.bb(0.94, 1.04, 2.08, 1.18, 1.07, 2.32, M.steel)
  for (let k = 0; k < 5; k++) {
    const y0 = 0.17 + k * 0.16
    b.bb(1.5, y0, 2.06, 1.525, y0 + 0.125, 2.69, cm(0x8f211c, 0.38, 0.25))
    b.bb(1.525, y0 + 0.052, 2.31, 1.545, y0 + 0.073, 2.44, M.chrome)
    b.bb(1.5, y0 + 0.135, 2.05, 1.51, y0 + 0.145, 2.7, M.black)
  }
  b.bb(1.08, 0.82, 2.755, 1.34, 0.94, 2.765, M.white)
  b.bb(1.12, 0.86, 2.766, 1.3, 0.9, 2.77, M.red)
  for (const z of [2.08, 2.67]) for (const x of [0.98, 1.42]) {
    b.sph(x, 0.075, z, 0.072, M.tire, { seg: 10 })
    b.cyl(x, 0.055, z, 0.026, 0.052, M.steel, { seg: 8 })
  }
  b.endObject()

  // ---------- étagères métalliques ----------
  for (let u = 0; u < 3; u++) {
    const z0 = 5.0 + u * 1.25
    for (const zz of [z0, z0 + 1.2]) for (const xx of [0.13, 0.56]) b.bb(xx, 0, zz, xx + 0.04, 2.0, zz + 0.04, M.blackMetal)
    for (let k = 0; k < 4; k++) {
      b.bb(0.13, 0.25 + k * 0.55, z0, 0.6, 0.28 + k * 0.55, z0 + 1.24, M.woodMid)
      const n = 2 + Math.floor(rand() * 2)
      for (let q = 0; q < n; q++) {
        const zq = z0 + 0.06 + q * 0.4
        const kind = Math.floor(rand() * 4)
        const y = 0.28 + k * 0.55
        if (kind === 0) b.bb(0.18, y, zq, 0.52, y + 0.3, zq + 0.34, M.cardboard)
        else if (kind === 1) b.bb(0.18, y, zq, 0.52, y + 0.24, zq + 0.34, M.tote)
        else if (kind === 2) b.cyl(0.35, y, zq + 0.18, 0.13, 0.28, M.blue, { seg: 10 })
        else b.bb(0.2, y, zq, 0.5, y + 0.2, zq + 0.3, M.red)
      }
    }
  }
  b.sph(0.35, 1.0 + 0.12, 5.2, 0.12, M.orange, { seg: 10 })
  c.block(0.125, 0, 5.0, 0.6, 2.0, 8.75)

  // ---------- échelle ----------
  const lad = -0.25
  for (const z of [4.6, 5.15]) {
    b.box(5.58, 1.15, z, 0.04, 2.37, 0.04, M.yellow, { rot: [0, 0, lad] })
  }
  for (let k = 0; k < 7; k++) {
    const y = 0.25 + k * 0.32
    b.box(5.3 + y * 0.2553, y, 4.875, 0.03, 0.03, 0.55, M.steel)
  }
  c.block(5.2, 0, 4.55, 5.9, 2.4, 5.2)

  // ---------- tondeuse ----------
  b.bb(1.0, 0.15, 7.7, 1.55, 0.4, 8.3, M.red, { solid: true })
  b.bb(1.0, 0.1, 7.7, 1.55, 0.15, 8.3, M.blackMetal)
  for (const x of [1.0, 1.55]) for (const z of [7.75, 8.25]) b.cyl(x, 0.0, z, 0.1, 0.06, M.tire, { seg: 10, rot: [0, 0, P / 2] })
  b.box(1.1, 0.7, 7.5, 0.03, 0.03, 0.75, M.blackMetal, { rot: [-0.7, 0, 0] })
  b.box(1.45, 0.7, 7.5, 0.03, 0.03, 0.75, M.blackMetal, { rot: [-0.7, 0, 0] })
  b.bb(1.08, 0.95, 7.2, 1.47, 0.99, 7.24, M.blackMetal)

  // ---------- poubelles, outils ----------
  for (const z of [8.35, 7.7]) {
    b.cyl(5.55, 0, z, 0.27, 0.95, cm(0x3a3d40, 0.6), { seg: 14, solid: true })
    b.cyl(5.55, 0.95, z, 0.29, 0.05, cm(0x2a2c2f, 0.6), { seg: 14 })
  }
  // rails de porte & moteur
  b.bb(2.9, 2.55, 5.0, 3.1, 2.65, 8.8, M.steel)
  b.bb(2.7, 2.42, 4.2, 3.3, 2.72, 5.0, cm(0x6f7378, 0.5, 0.5))
  b.bb(1.3, 2.74, 3.0, 1.45, 2.79, 6.2, M.tube)
  b.bb(4.7, 2.74, 3.0, 4.85, 2.79, 6.2, M.tube)
  c.addLight(3.0, 2.55, 4.0, 0xfff1dc, 20, 12)
  c.addLight(3.0, 2.55, 7.4, 0xfff1dc, 14, 9)
  // tableau d'électricité + extincteur
  b.bb(5.84, 1.2, 7.0, 5.9, 1.8, 7.5, cm(0x7a7d80, 0.5, 0.4))
  b.cyl(5.7, 0, 1.0, 0.07, 0.4, M.red, { seg: 8 })
  // tuyau d'arrosage
  b.cyl(5.7, 0.8, 6.0, 0.18, 0.1, M.leaf, { seg: 14 })
  // taches d'huile
  b.bb(3.2, 0.004, 3.0, 4.7, 0.006, 6.9, cm(0x7a7874, 1))
}

/* ============================================================ */
export function furnishGround(c: Ctx) {
  const { b, M } = c
  const lineMat = cm(0xa39f95, 0.8)
  const spots = (pts: [number, number][], y = 2.78) => {
    for (const [x, z] of pts) {
      b.cyl(x, y, z, 0.1, 0.03, M.bulb, { seg: 10 })
      b.cyl(x, y + 0.02, z, 0.13, 0.01, M.trim, { seg: 10 })
    }
  }

  /* ---------------- CUISINE ---------------- */
  // frigo
  b.bb(10.15, 0, 0.13, 11.0, 1.85, 0.8, M.steel, { solid: true })
  b.bb(10.57, 0.05, 0.8, 10.58, 1.8, 0.805, M.black)
  b.bb(10.15, 0.6, 0.8, 11.0, 0.61, 0.805, M.black)
  b.bb(10.2, 1.1, 0.8, 10.4, 1.45, 0.806, M.black)
  b.bb(10.46, 0.7, 0.8, 10.49, 1.7, 0.86, M.chrome)
  b.bb(10.66, 0.7, 0.8, 10.69, 1.7, 0.86, M.chrome)
  b.bb(10.2, 0.2, 0.8, 10.95, 0.25, 0.86, M.chrome)
  // colonne
  b.bb(11.0, 0, 0.13, 11.6, 2.3, 0.7, M.cabinet, { solid: true })
  b.bb(11.3, 0.05, 0.7, 11.31, 2.25, 0.705, lineMat)
  b.bb(11.5, 1.0, 0.7, 11.53, 1.3, 0.75, M.black)
  // meubles bas
  b.bb(11.6, 0, 0.13, 17.875, 0.86, 0.75, M.cabinet, { solid: true })
  for (let x = 12.2; x < 17.8; x += 0.6) {
    if (x > 14.3 && x < 15.2) continue
    b.bb(x - 0.005, 0.05, 0.75, x + 0.005, 0.82, 0.755, lineMat)
    b.bb(x + 0.1, 0.7, 0.75, x + 0.25, 0.72, 0.79, M.black)
  }
  b.bb(11.6, 0.86, 0.13, 17.875, 0.9, 0.8, M.marble)
  b.bb(11.6, 0.9, 0.13, 17.875, 1.5, 0.16, M.tile)
  // cuisinière
  b.bb(14.4, 0, 0.13, 15.1, 0.9, 0.78, M.steel, { solid: true })
  b.bb(14.45, 0.9, 0.2, 15.05, 0.92, 0.7, M.black)
  for (const [x, z] of [
    [14.58, 0.32],
    [14.92, 0.32],
    [14.58, 0.58],
    [14.92, 0.58],
  ])
    b.cyl(x, 0.92, z, 0.07, 0.015, M.blackMetal, { seg: 10 })
  b.bb(14.45, 0.2, 0.78, 15.05, 0.72, 0.8, M.black)
  b.bb(14.45, 0.76, 0.8, 15.05, 0.79, 0.85, M.chrome)
  b.bb(14.3, 1.55, 0.13, 15.2, 1.75, 0.6, M.steel)
  b.bb(14.6, 1.75, 0.13, 14.9, 2.8, 0.4, M.steel)
  b.bb(14.4, 1.55, 0.58, 15.1, 1.57, 0.6, M.black)
  // hauts
  b.bb(11.6, 1.5, 0.13, 14.2, 2.2, 0.45, M.cabinet, { solid: true })
  b.bb(15.3, 1.5, 0.13, 17.875, 2.2, 0.45, M.cabinet, { solid: true })
  for (let x = 12.2; x < 14.2; x += 0.65) b.bb(x, 1.55, 0.45, x + 0.01, 2.15, 0.455, lineMat)
  for (let x = 15.95; x < 17.8; x += 0.65) b.bb(x, 1.55, 0.45, x + 0.01, 2.15, 0.455, lineMat)
  b.bb(11.7, 1.47, 0.15, 14.1, 1.495, 0.3, M.bulb)
  b.bb(15.4, 1.47, 0.15, 17.8, 1.495, 0.3, M.bulb)
  // objets sur le plan de travail
  b.bb(17.2, 0.9, 0.2, 17.55, 1.28, 0.5, M.black)
  b.cyl(17.38, 0.9, 0.38, 0.06, 0.16, M.carGlass, { seg: 8 })
  b.bb(16.5, 0.9, 0.25, 16.85, 1.05, 0.5, M.steel)
  b.bb(12.0, 0.9, 0.3, 12.18, 1.15, 0.5, M.woodDark)
  for (let k = 0; k < 3; k++) b.cyl(12.55 + k * 0.2, 0.9, 0.3, 0.08, 0.2 + k * 0.03, cm(0xcfc9bd, 0.5), { seg: 10 })
  c.plant(13.5, 0.9, 0.35, 0.4)
  b.bb(15.5, 0.9, 0.2, 16.1, 0.93, 0.5, M.woodMid)
  // îlot
  b.bb(12.4, 0, 2.0, 15.8, 0.9, 3.2, M.cabinet, { solid: true })
  b.bb(12.3, 0.9, 1.95, 15.9, 0.95, 3.5, M.marble, { solid: true })
  b.bb(12.3, 0, 1.95, 12.4, 0.95, 3.5, M.marble)
  b.bb(15.8, 0, 1.95, 15.9, 0.95, 3.5, M.marble)
  for (let x = 12.9; x < 15.8; x += 0.7) {
    b.bb(x, 0.05, 1.995, x + 0.01, 0.85, 2.0, lineMat)
    b.bb(x + 0.2, 0.75, 1.995, x + 0.4, 0.77, 1.96, M.black)
  }
  b.bb(13.55, 0.945, 2.3, 14.45, 0.953, 2.8, M.steel)
  b.bb(13.62, 0.953, 2.36, 14.38, 0.955, 2.74, M.black)
  b.cyl(14.0, 0.95, 2.2, 0.014, 0.3, M.black, { seg: 8 })
  b.bb(13.99, 1.22, 2.1, 14.01, 1.25, 2.3, M.black)
  b.cyl(14.7, 0.95, 2.4, 0.035, 0.18, M.black, { seg: 8 })
  b.cyl(15.3, 0.95, 2.6, 0.015, 0.34, M.blackMetal, { seg: 6 })
  b.cyl(15.3, 1.0, 2.6, 0.07, 0.24, M.white, { seg: 12 })
  b.bb(15.0, 0.95, 2.9, 15.3, 0.97, 3.1, M.woodMid)
  b.cyl(13.1, 0.95, 3.0, 0.1, 0.1, M.whiteGloss, { seg: 12, rTop: 0.12 })
  // tabourets
  for (const x of [12.9, 14.1, 15.3]) {
    b.beginObject(`stool-${x}`, 'Tabouret de cuisine en cuir cognac', 'furniture')
    const z = 3.9
    b.cyl(x, 0.655, z, 0.205, 0.075, M.leather, { seg: 24 })
    b.sph(x, 0.715, z, 0.19, M.leather, { sy: 0.28, seg: 16 })
    b.cyl(x, 0.625, z, 0.175, 0.035, M.blackMetal, { seg: 20 })
    for (const dx of [-0.13, 0.13]) for (const dz of [-0.13, 0.13]) {
      b.bb(x + dx - 0.014, 0.035, z + dz - 0.014, x + dx + 0.014, 0.64, z + dz + 0.014, M.blackMetal)
      b.sph(x + dx, 0.025, z + dz, 0.032, M.tire, { sy: 0.45, seg: 8 })
    }
    b.cyl(x, 0.27, z, 0.165, 0.018, M.chrome, { seg: 20 })
    b.bb(x - 0.185, 0.755, z + 0.175, x + 0.185, 1.015, z + 0.225, M.leather)
    b.sph(x, 0.885, z + 0.235, 0.175, M.leather, { sx: 1.05, sy: 0.72, sz: 0.18, seg: 12 })
    b.bb(x - 0.165, 0.735, z + 0.165, x - 0.145, 0.775, z + 0.19, M.blackMetal)
    b.bb(x + 0.145, 0.735, z + 0.165, x + 0.165, 0.775, z + 0.19, M.blackMetal)
    c.block(x - 0.22, 0, z - 0.22, x + 0.22, 1.02, z + 0.24)
    b.endObject()
  }
  // suspensions
  for (const x of [13.0, 14.1, 15.2]) {
    b.bb(x - 0.006, 1.75, 2.594, x + 0.006, 2.8, 2.606, M.black)
    b.cyl(x, 1.55, 2.6, 0.17, 0.2, cm(0x1c1c1e, 0.35, 0.6), { seg: 14, rTop: 0.04 })
    b.cyl(x, 1.5, 2.6, 0.07, 0.05, M.bulb, { seg: 10 })
  }
  c.addLight(13.6, 2.2, 2.5, 0xffd9a8, 18, 10)
  c.addLight(16.8, 2.5, 2.2, 0xffd9a8, 12, 8)
  // poubelle + plante
  b.bb(17.45, 0, 3.8, 17.8, 0.7, 4.2, M.steel, { solid: true })
  c.plant(10.45, 0, 4.2, 1.1)
  spots([
    [12, 1.2],
    [14.5, 1.3],
    [17, 1.2],
    [12, 3.8],
    [16.5, 3.8],
  ])
  c.picture(17.84, 1.7, 4.35, 'nx', 0.5, 0.65, 1)

  /* ---------------- SALON ---------------- */
  b.bb(12.3, 0.003, 5.2, 16.9, 0.022, 8.7, M.rugGrey)
  b.bb(12.45, 0.022, 5.35, 16.75, 0.026, 8.55, M.rugDark)
  b.bb(12.55, 0.026, 5.45, 16.65, 0.03, 8.45, M.rugGrey)
  // canapé d'angle
  b.bb(12.0, 0, 5.5, 13.1, 0.28, 8.6, M.fabricBeige)
  for (let i = 0; i < 3; i++) b.bb(12.3, 0.28, 5.55 + i * 1.01, 13.1, 0.52, 6.55 + i * 1.01, M.fabricBeige)
  b.bb(12.0, 0.28, 5.5, 12.3, 0.9, 8.6, M.fabricBeige)
  for (let i = 0; i < 3; i++) b.box(12.42, 0.7, 6.05 + i * 1.01, 0.26, 0.45, 0.95, M.fabricBeige, { rot: [0, 0, -0.12] })
  b.bb(12.0, 0.28, 8.42, 13.1, 0.62, 8.62, M.fabricBeige)
  b.bb(13.1, 0, 5.5, 14.6, 0.28, 6.6, M.fabricBeige)
  b.bb(13.1, 0.28, 5.55, 14.6, 0.52, 6.55, M.fabricBeige)
  b.bb(13.1, 0.28, 5.5, 14.6, 0.62, 5.68, M.fabricBeige)
  c.block(12.0, 0, 5.5, 13.1, 0.9, 8.6)
  c.block(13.1, 0, 5.5, 14.6, 0.62, 6.6)
  b.box(12.62, 0.72, 6.0, 0.14, 0.42, 0.42, M.fabricGrey, { rot: [0.15, 0, -0.25] })
  b.box(12.62, 0.72, 8.0, 0.14, 0.42, 0.42, M.fabricBlue, { rot: [-0.1, 0, -0.25] })
  b.box(13.9, 0.7, 5.85, 0.4, 0.4, 0.14, M.fabricCream, { rot: [-0.25, 0.1, 0] })
  b.box(12.8, 0.55, 7.5, 0.7, 0.05, 0.7, M.fabricCream, { rot: [0.05, 0.4, 0.04] })
  b.box(13.14, 0.4, 8.3, 0.05, 0.36, 0.6, M.fabricCream, { rot: [0, 0, 0.08] })
  // table basse
  b.bb(14.6, 0.4, 6.9, 15.7, 0.44, 7.7, M.woodDark)
  legs4(c, 14.6, 6.9, 15.7, 7.7, 0.4, 0.05, M.woodDark)
  b.bb(14.65, 0.12, 6.95, 15.65, 0.15, 7.65, M.woodDark)
  c.block(14.6, 0, 6.9, 15.7, 0.45, 7.7)
  b.beginObject('living-books', 'Trois livres sur la table basse')
  // Grand livre brun, pages crème et tranche visible.
  b.bb(14.76, 0.44, 7.04, 15.12, 0.505, 7.42, cm(0xe3dcc9, 0.9))
  b.bb(14.745, 0.435, 7.025, 15.135, 0.465, 7.435, cm(0x59483a, 0.72))
  b.bb(14.745, 0.49, 7.025, 15.135, 0.515, 7.435, cm(0x3d2f27, 0.72))
  b.bb(14.79, 0.47, 7.03, 14.83, 0.49, 7.41, cm(0xc4a86a, 0.55, 0.35))
  // Livre bleu nuit posé légèrement de travers par sa forme d'origine.
  b.bb(14.83, 0.515, 7.12, 15.07, 0.545, 7.34, cm(0xdcd6c6, 0.9))
  b.bb(14.815, 0.51, 7.105, 15.085, 0.532, 7.355, cm(0x2f4356, 0.68))
  b.bb(14.815, 0.54, 7.105, 15.085, 0.56, 7.355, cm(0x243447, 0.68))
  b.bb(14.9, 0.532, 7.115, 14.94, 0.542, 7.345, cm(0xb9c0bb, 0.6, 0.5))
  // Petit livre rouge, repère visuel facile à mémoriser.
  b.bb(14.88, 0.56, 7.17, 15.04, 0.585, 7.31, cm(0xe0d8c8, 0.9))
  b.bb(14.865, 0.555, 7.155, 15.055, 0.578, 7.325, cm(0x74343a, 0.72))
  b.bb(14.865, 0.582, 7.155, 15.055, 0.598, 7.325, cm(0x5e2b31, 0.72))
  b.endObject()
  b.cyl(15.4, 0.44, 7.28, 0.06, 0.13, M.whiteGloss, { seg: 10 })
  b.sph(15.4, 0.7, 7.28, 0.1, M.leaf2, { seg: 7 })
  b.cyl(15.25, 0.44, 7.5, 0.035, 0.07, M.steel, { seg: 8 })
  // meuble TV
  b.bb(17.15, 0, 5.9, 17.875, 0.5, 8.3, M.woodMid, { solid: true })
  for (let k = 1; k < 4; k++) b.bb(17.145, 0.05, 5.9 + k * 0.6, 17.155, 0.45, 5.91 + k * 0.6, M.black)
  for (let k = 0; k < 4; k++) b.bb(17.14, 0.28, 6.1 + k * 0.6, 17.15, 0.32, 6.25 + k * 0.6, M.black)
  b.bb(17.66, 0.5, 6.95, 17.8, 0.85, 7.3, M.black)
  b.beginObject('living-tv', 'Télévision du salon', 'screen')
  b.bb(17.695, 0.845, 6.285, 17.765, 1.625, 7.965, M.black)
  b.bb(17.7, 0.875, 6.315, 17.745, 1.595, 7.935, M.tvScreen)
  b.bb(17.688, 0.9, 6.36, 17.699, 1.56, 7.88, M.glass)
  b.bb(17.742, 0.815, 7.05, 17.748, 0.838, 7.2, M.blackMetal)
  b.sph(17.69, 0.822, 7.88, 0.012, cm(0x7a2018, 0.4, 0.1, 0xff2a1a, 0.65), { seg: 8 })
  b.endObject()
  b.bb(17.76, 0.85, 6.3, 17.8, 1.62, 7.95, M.black)
  b.bb(17.52, 0.5, 6.4, 17.64, 0.58, 7.85, M.black)
  c.plant(17.45, 0.5, 5.98, 0.5)
  b.bb(17.4, 0.5, 8.0, 17.45, 0.74, 8.2, M.frame)
  // console + miroir
  b.bb(10.07, 0.78, 4.75, 10.47, 0.82, 5.95, M.woodDark)
  legs4(c, 10.07, 4.75, 10.47, 5.95, 0.78, 0.04, M.woodDark)
  c.block(10.06, 0, 4.75, 10.5, 0.85, 5.95)
  c.lamp(10.25, 0.82, 5.05, 0.4, false)
  b.bb(10.2, 0.82, 5.5, 10.4, 0.9, 5.75, M.woodMid)
  b.cyl(10.1, 1.35, 5.35, 0.46, 0.05, M.blackMetal, { seg: 24, rot: [0, 0, P / 2] })
  b.cyl(10.115, 1.35, 5.35, 0.42, 0.06, M.mirror, { seg: 24, rot: [0, 0, P / 2] })
  // bibliothèque
  for (const x of [13.4, 14.96]) b.bb(x, 0, 8.55, x + 0.04, 2.1, 8.875, M.blackMetal)
  for (let k = 0; k < 6; k++) b.bb(13.4, 0.05 + k * 0.4, 8.55, 15.0, 0.08 + k * 0.4, 8.875, M.woodDark)
  b.bb(13.44, 0.08, 8.8, 14.96, 2.05, 8.875, M.books)
  c.block(13.4, 0, 8.55, 15.0, 2.1, 8.875)
  for (let k = 0; k < 4; k++) c.books(13.5 + (k % 2) * 0.7, 0.08 + (k + 1) * 0.4, 8.6, 6, 'x', 0.28)
  b.bb(14.4, 1.28, 8.6, 14.7, 1.5, 8.82, M.frame)
  b.sph(13.8, 0.2, 8.7, 0.14, M.orange, { seg: 8 })
  // lampadaire
  b.cyl(17.5, 0, 4.78, 0.12, 0.03, M.blackMetal, { seg: 12 })
  b.cyl(17.5, 0.03, 4.78, 0.015, 1.55, M.blackMetal, { seg: 6 })
  b.cyl(17.5, 1.45, 4.78, 0.2, 0.3, M.shade, { seg: 14, rTop: 0.14 })
  c.addLight(17.5, 1.6, 4.9, 0xffc880, 10, 8)
  c.plant(17.45, 0, 8.55, 1.7)
  c.plant(10.55, 0, 8.7, 1.3)
  c.addLight(14.5, 2.55, 7.0, 0xffd2a0, 18, 11)
  b.cyl(14.5, 2.76, 7.0, 0.28, 0.04, M.bulb, { seg: 16 })
  spots([
    [12, 6],
    [16, 6],
    [12.5, 8.3],
    [16.5, 8.3],
  ])

  /* ---------------- HALL ---------------- */
  b.bb(8.15, 0.004, 3.6, 9.45, 0.02, 8.2, M.rugDark)
  b.bb(9.58, 0.78, 4.7, 9.94, 0.82, 5.9, M.woodDark)
  legs4(c, 9.58, 4.7, 9.94, 5.9, 0.78, 0.04, M.woodDark)
  c.block(9.55, 0, 4.7, 9.94, 0.85, 5.9)
  c.lamp(9.76, 0.82, 5.3, 0.42, true)
  c.picture(9.935, 1.65, 5.3, 'nx', 0.7, 0.9, 0)
  b.bb(9.3, 0, 8.3, 9.9, 0.45, 8.85, M.woodDark, { solid: true })
  b.bb(9.3, 0.45, 8.3, 9.9, 0.52, 8.85, M.fabricGrey)
  b.bb(9.4, 0.0, 8.4, 9.65, 0.1, 8.75, M.black)
  b.bb(9.9, 1.6, 8.5, 9.94, 1.66, 8.9, M.woodDark)
  b.bb(9.78, 0.9, 8.55, 9.9, 1.6, 8.72, M.fabricDark)
  c.picture(6.1, 3.7, 5.8, 'px', 0.9, 0.7, 1)
  c.picture(6.1, 2.0, 4.2, 'px', 0.5, 0.65, 2)
  c.addLight(8.9, 2.5, 6.0, 0xffd2a0, 16, 10)
  b.cyl(8.9, 2.74, 6.0, 0.22, 0.05, M.bulb, { seg: 16 })
  b.cyl(7.0, 2.74, 3.7, 0.12, 0.03, M.bulb, { seg: 12 })

  /* ---------------- BUANDERIE ---------------- */
  b.bb(6.1, 0, 0.125, 7.3, 0.86, 0.75, M.cabinet, { solid: true })
  b.bb(6.1, 0.86, 0.125, 7.3, 0.9, 0.8, M.marble)
  b.bb(6.695, 0.05, 0.75, 6.705, 0.82, 0.755, lineMat)
  b.bb(6.4, 0.9, 0.25, 7.0, 0.93, 0.65, M.whiteGloss)
  b.bb(6.45, 0.93, 0.3, 6.95, 0.935, 0.6, M.steel)
  b.cyl(6.7, 0.93, 0.18, 0.013, 0.3, M.black, { seg: 8 })
  b.bb(6.69, 1.2, 0.18, 6.71, 1.23, 0.33, M.black)
  b.cyl(7.18, 0.9, 0.3, 0.032, 0.17, M.black, { seg: 8 })
  b.cyl(6.3, 0.9, 0.55, 0.05, 0.14, M.whiteGloss, { seg: 8 })
  c.plant(6.28, 0.9, 0.3, 0.55)
  for (const [x1, x2] of [
    [7.3, 7.9],
    [7.9, 8.44],
  ]) {
    b.bb(x1, 0, 0.125, x2, 0.9, 0.7, M.white, { solid: true })
    const cx = (x1 + x2) / 2
    b.bb(x1 + 0.03, 0.78, 0.7, x2 - 0.03, 0.86, 0.71, M.black)
    b.cyl(cx, 0.4, 0.705, 0.23, 0.03, M.chrome, { seg: 20, rot: [P / 2, 0, 0] })
    b.cyl(cx, 0.4, 0.715, 0.19, 0.04, M.carGlass, { seg: 20, rot: [P / 2, 0, 0] })
    b.bb(cx - 0.02, 0.3, 0.72, cx + 0.02, 0.5, 0.735, M.steel)
  }
  b.bb(6.1, 1.55, 0.125, 8.44, 1.6, 0.4, M.woodDark)
  b.bb(6.3, 1.6, 0.2, 6.5, 1.85, 0.3, M.blue)
  b.bb(6.6, 1.6, 0.2, 6.75, 1.8, 0.3, M.white)
  b.cyl(6.95, 1.6, 0.28, 0.05, 0.2, M.red, { seg: 8 })
  b.bb(7.5, 1.6, 0.15, 8.0, 1.8, 0.38, M.woodMid)
  b.bb(8.05, 1.6, 0.15, 8.4, 1.72, 0.38, M.fabricCream)
  b.beginObject('laundry-basket', 'Panier à linge blanc et serviette bleue', 'furniture')
  c.block(6.15, 0, 2.3, 6.65, 0.72, 2.8)
  const basketMat = cm(0xd8d4c8, 0.72)
  b.bb(6.18, 0.015, 2.33, 6.62, 0.055, 2.77, basketMat)
  for (let x = 6.19; x <= 6.59; x += 0.057) {
    b.bb(x, 0.05, 2.315, x + 0.026, 0.68, 2.345, basketMat)
    b.bb(x, 0.05, 2.755, x + 0.026, 0.68, 2.785, basketMat)
  }
  for (let z = 2.36; z <= 2.72; z += 0.057) {
    b.bb(6.165, 0.05, z, 6.195, 0.68, z + 0.026, basketMat)
    b.bb(6.605, 0.05, z, 6.635, 0.68, z + 0.026, basketMat)
  }
  for (const y of [0.16, 0.38, 0.6]) {
    b.bb(6.155, y, 2.305, 6.645, y + 0.035, 2.345, basketMat)
    b.bb(6.155, y, 2.755, 6.645, y + 0.035, 2.795, basketMat)
    b.bb(6.155, y, 2.31, 6.19, y + 0.035, 2.79, basketMat)
    b.bb(6.605, y, 2.31, 6.64, y + 0.035, 2.79, basketMat)
  }
  b.bb(6.125, 0.675, 2.275, 6.675, 0.725, 2.825, cm(0xcac5ba, 0.62))
  b.bb(6.28, 0.69, 2.24, 6.36, 0.735, 2.31, basketMat)
  b.bb(6.44, 0.69, 2.79, 6.52, 0.735, 2.86, basketMat)
  b.bb(6.2, 0.7, 2.35, 6.6, 0.79, 2.75, M.fabricGrey)
  b.bb(6.25, 0.76, 2.39, 6.55, 0.84, 2.7, M.fabricBlue)
  b.bb(6.29, 0.79, 2.42, 6.51, 0.815, 2.67, M.fabricCream)
  b.endObject()
  b.cyl(7.5, 0.001, 1.9, 0.07, 0.006, M.blackMetal, { seg: 12 })
  b.cyl(8.1, 0, 2.7, 0.15, 0.3, M.blue, { seg: 12 })
  b.cyl(8.2, 0.3, 2.78, 0.012, 1.2, M.woodMid, { seg: 6 })
  c.addLight(7.2, 2.5, 1.5, 0xffe2b8, 14, 8)
  b.cyl(7.2, 2.76, 1.5, 0.2, 0.04, M.bulb, { seg: 16 })

  /* ---------------- WC ---------------- */
  b.bb(9.12, 0, 0.3, 9.38, 0.38, 0.7, M.whiteGloss)
  b.sph(9.25, 0.36, 0.52, 0.21, M.whiteGloss, { sz: 1.45, sy: 0.7, seg: 12 })
  b.bb(9.07, 0.38, 0.125, 9.43, 0.86, 0.3, M.whiteGloss)
  c.block(9.0, 0, 0.125, 9.5, 0.9, 0.85)
  b.bb(9.5, 0, 1.7, 9.94, 0.8, 2.3, M.cabinetDark, { solid: true })
  b.bb(9.5, 0.8, 1.7, 9.94, 0.83, 2.3, M.marble)
  b.cyl(9.82, 0.83, 2.0, 0.012, 0.2, M.black, { seg: 8 })
  b.bb(9.92, 1.2, 1.75, 9.94, 1.9, 2.25, M.mirror)
  c.picture(8.565, 1.7, 1.5, 'px', 0.35, 0.45, 2)
  b.bb(8.56, 0.75, 0.95, 8.64, 0.78, 1.15, M.chrome)
  c.addLight(9.25, 2.4, 1.4, 0xffe2b8, 9, 5)
  b.cyl(9.25, 2.76, 1.4, 0.12, 0.03, M.bulb, { seg: 12 })
}

/* ============================================================ */
export function furnishUpper(c: Ctx) {
  const { b, M } = c
  const lineMat = cm(0xa39f95, 0.8)
  b.push([0, 3, 0])

  /* ---------------- COULOIR (palier) ---------------- */
  b.bb(7.6, 0.004, 0.4, 8.35, 0.02, 4.1, M.rugRed)
  b.bb(6.15, 0.78, 1.0, 6.55, 0.82, 2.2, M.woodDark)
  legs4(c, 6.15, 1.0, 6.55, 2.2, 0.78, 0.04, M.woodDark)
  c.block(6.1, 0, 1.0, 6.55, 0.85, 2.2)
  c.lamp(6.35, 0.82, 1.6, 0.42, true)
  c.picture(6.1, 1.7, 1.6, 'px', 0.6, 0.8, 0)
  c.picture(8.54, 1.6, 3.4, 'nx', 0.7, 0.5, 2)
  c.picture(8.54, 1.6, 0.8, 'nx', 0.5, 0.65, 1)
  b.bb(6.15, 0, 8.0, 6.6, 0.9, 8.8, M.cabinet, { solid: true })
  b.bb(6.12, 0.9, 7.98, 6.62, 0.93, 8.82, M.marble)
  b.bb(6.35, 0.93, 8.2, 6.5, 1.15, 8.4, M.frame)
  c.plant(8.1, 0, 8.55, 1.4)
  c.addLight(7.3, 2.5, 2.4, 0xffd6a0, 14, 9)
  b.cyl(7.3, 2.76, 2.4, 0.2, 0.04, M.bulb, { seg: 14 })
  c.addLight(7.4, 2.5, 8.0, 0xffd6a0, 8, 6)
  b.cyl(7.4, 2.76, 8.0, 0.15, 0.04, M.bulb, { seg: 12 })

  /* ---------------- COULOIR est-ouest ---------------- */
  b.bb(8.7, 0.004, 4.75, 11.5, 0.02, 5.5, M.rugDark)
  b.bb(9.6, 0.78, 4.56, 10.5, 0.82, 4.92, M.woodDark)
  legs4(c, 9.6, 4.56, 10.5, 4.92, 0.78, 0.04, M.woodDark)
  c.block(9.6, 0, 4.56, 10.5, 0.85, 4.92)
  c.lamp(10.05, 0.82, 4.73, 0.42, true)
  c.picture(10.0, 1.6, 4.56, 'pz', 0.5, 0.7, 2)
  c.picture(9.0, 1.6, 5.64, 'nz', 0.45, 0.6, 0)
  c.addLight(10.0, 2.5, 5.1, 0xffd6a0, 12, 7)
  b.cyl(10.0, 2.76, 5.1, 0.15, 0.04, M.bulb, { seg: 12 })

  /* ---------------- CHAMBRE AMIE ---------------- */
  b.bb(9.3, 0.12, 0.2, 10.3, 0.36, 2.2, M.woodDark, { solid: true })
  b.bb(9.32, 0.36, 0.25, 10.28, 0.54, 2.15, M.linen)
  b.bb(9.28, 0.5, 0.95, 10.32, 0.62, 2.2, M.fabricGrey)
  b.box(9.8, 0.62, 0.55, 0.7, 0.12, 0.45, M.linen, { rot: [0.12, 0, 0] })
  b.bb(9.25, 0.1, 0.125, 10.35, 1.1, 0.2, M.woodDark)
  legs4(c, 9.3, 0.2, 10.3, 2.2, 0.12, 0.05, M.black)
  b.bb(10.4, 0, 0.13, 10.85, 0.55, 0.55, M.cabinetDark, { solid: true })
  b.bb(10.42, 0.28, 0.55, 10.83, 0.3, 0.56, M.black)
  c.lamp(10.62, 0.55, 0.34, 0.42, true)
  b.bb(10.45, 0.55, 0.4, 10.55, 0.6, 0.5, M.woodMid)
  // bureau
  b.bb(12.2, 0.74, 1.5, 12.9, 0.78, 3.9, M.cabinetDark)
  b.bb(12.2, 0, 1.5, 12.24, 0.74, 3.9, M.cabinetDark)
  b.bb(12.5, 0, 3.3, 12.9, 0.74, 3.9, M.cabinetDark)
  c.block(12.2, 0, 1.5, 12.94, 0.8, 3.9)
  b.bb(12.7, 0.95, 2.2, 12.74, 1.4, 2.95, M.tvScreen)
  b.bb(12.74, 0.78, 2.5, 12.82, 0.95, 2.65, M.black)
  b.bb(12.4, 0.78, 2.35, 12.56, 0.795, 2.8, M.black)
  c.lamp(12.7, 0.78, 1.7, 0.36, true)
  b.bb(12.35, 0.78, 3.05, 12.55, 0.8, 3.3, M.linen)
  // chaise de bureau
  b.beginObject('bedroom-chair', 'Chaise de bureau noire à roulettes', 'furniture')
  b.bb(11.55, 0.44, 2.55, 12.05, 0.52, 3.05, M.black)
  b.sph(11.8, 0.5, 2.8, 0.24, M.black, { sx: 1.05, sy: 0.24, sz: 1.05, seg: 14 })
  b.bb(11.47, 0.52, 2.57, 11.55, 1.13, 3.03, M.black)
  b.bb(11.44, 0.68, 2.61, 11.49, 1.08, 2.99, M.fabricDark)
  b.bb(11.5, 0.57, 2.52, 11.57, 1.08, 2.58, M.blackMetal)
  b.bb(11.5, 0.57, 3.02, 11.57, 1.08, 3.08, M.blackMetal)
  b.bb(11.56, 0.69, 2.5, 12.0, 0.735, 2.56, M.blackMetal)
  b.bb(11.56, 0.69, 3.04, 12.0, 0.735, 3.1, M.blackMetal)
  b.cyl(11.8, 0.12, 2.8, 0.034, 0.34, M.chrome, { seg: 10 })
  b.cyl(11.8, 0.43, 2.8, 0.055, 0.035, M.blackMetal, { seg: 10 })
  for (let k = 0; k < 5; k++) {
    const a = k / 5 * Math.PI * 2 + 0.35
    const cx = 11.8 + Math.cos(a) * 0.22
    const cz = 2.8 + Math.sin(a) * 0.22
    b.box(cx, 0.075, cz, 0.24, 0.025, 0.045, M.blackMetal, { rot: [0, -a, 0] })
    b.sph(11.8 + Math.cos(a) * 0.32, 0.045, 2.8 + Math.sin(a) * 0.32, 0.042, M.tire, { sy: 0.72, seg: 8 })
  }
  c.block(11.48, 0, 2.55, 12.05, 1.12, 3.05)
  b.endObject()
  b.bb(9.4, 0.004, 2.6, 11.5, 0.02, 4.2, M.rugGrey)
  c.picture(9.8, 1.6, 0.125, 'pz', 0.7, 0.5, 1)
  c.picture(12.9, 1.7, 1.0, 'nx', 0.45, 0.6, 0)
  // armoire
  b.bb(8.66, 0, 3.1, 9.25, 2.1, 4.44, M.cabinet, { solid: true })
  b.bb(9.25, 0.05, 3.55, 9.26, 2.05, 3.56, lineMat)
  b.bb(9.25, 0.05, 4.0, 9.26, 2.05, 4.01, lineMat)
  b.bb(9.25, 1.0, 3.45, 9.28, 1.25, 3.5, M.black)
  b.bb(9.25, 1.0, 3.6, 9.28, 1.25, 3.65, M.black)
  b.bb(10.0, 0, 4.3, 10.9, 0.6, 4.44, M.woodDark, { solid: true })
  c.books(10.1, 0.6, 4.25, 10, 'x', 0.25)
  c.addLight(10.8, 2.5, 2.4, 0xffd6a0, 14, 9)
  b.cyl(10.8, 2.76, 2.4, 0.2, 0.04, M.bulb, { seg: 14 })

  /* ---------------- SALLE DE BAIN ---------------- */
  b.bb(8.66, 0, 6.1, 9.2, 0.85, 7.5, M.cabinetDark, { solid: true })
  b.bb(9.2, 0.05, 6.55, 9.21, 0.8, 6.56, lineMat)
  b.bb(9.2, 0.05, 7.0, 9.21, 0.8, 7.01, lineMat)
  b.bb(8.66, 0.85, 6.1, 9.25, 0.89, 7.5, M.marble)
  b.bb(8.78, 0.89, 6.45, 9.1, 0.9, 7.15, M.whiteGloss)
  b.cyl(8.74, 0.9, 6.8, 0.012, 0.22, M.black, { seg: 8 })
  b.bb(8.74, 1.1, 6.8, 8.9, 1.12, 6.82, M.black)
  b.cyl(8.85, 0.89, 7.3, 0.03, 0.18, M.black, { seg: 8 })
  b.bb(8.66, 1.25, 6.3, 8.7, 2.1, 7.3, M.mirror)
  b.bb(8.655, 1.22, 6.25, 8.69, 2.14, 6.3, M.blackMetal)
  b.bb(8.655, 1.22, 7.3, 8.69, 2.14, 7.35, M.blackMetal)
  b.bb(8.655, 2.1, 6.25, 8.69, 2.14, 7.35, M.blackMetal)
  b.bb(8.655, 1.22, 6.25, 8.69, 1.26, 7.35, M.blackMetal)
  b.cyl(8.72, 1.15, 7.7, 0.07, 0.015, M.blackMetal, { seg: 14, rot: [0, 0, P / 2] })
  b.beginObject('bath-towel', 'Serviette grise à bandes bleues')
  b.bb(8.665, 0.88, 7.635, 8.715, 1.325, 7.785, M.fabricGrey)
  b.bb(8.655, 0.94, 7.65, 8.668, 0.99, 7.77, M.fabricBlue)
  b.bb(8.655, 1.02, 7.65, 8.668, 1.045, 7.77, M.fabricCream)
  b.bb(8.655, 1.22, 7.65, 8.668, 1.27, 7.77, M.fabricBlue)
  for (let z = 7.65; z <= 7.76; z += 0.018) b.bb(8.66, 0.845, z, 8.71, 0.885, z + 0.007, M.fabricCream)
  b.endObject()
  // toilette
  b.bb(9.12, 0, 8.45, 9.48, 0.36, 8.8, M.whiteGloss)
  b.sph(9.3, 0.36, 8.25, 0.21, M.whiteGloss, { sz: 1.5, sy: 0.7, seg: 12 })
  b.bb(9.1, 0.38, 8.58, 9.5, 0.86, 8.875, M.whiteGloss)
  c.block(9.05, 0, 7.9, 9.55, 0.9, 8.875)
  c.plant(9.3, 0.86, 8.72, 0.3)
  c.picture(9.3, 1.55, 8.87, 'nz', 0.5, 0.6, 2)
  // baignoire
  b.bb(9.8, 0, 8.12, 11.54, 0.56, 8.875, M.whiteGloss, { solid: true })
  b.bb(9.9, 0.56, 8.2, 11.45, 0.57, 8.8, cm(0xe6e6e2, 0.3))
  b.bb(9.8, 0.55, 8.855, 11.54, 2.0, 8.875, M.tile)
  b.bb(9.8, 0.5, 8.12, 11.54, 0.52, 8.16, M.chrome)
  b.cyl(10.0, 0.57, 8.78, 0.02, 0.18, M.chrome, { seg: 8 })
  b.bb(9.86, 1.0, 8.8, 9.9, 2.0, 8.84, M.chrome)
  b.cyl(9.88, 1.95, 8.6, 0.09, 0.03, M.chrome, { seg: 10 })
  b.bb(9.88, 1.97, 8.6, 9.9, 1.99, 8.8, M.chrome)
  b.bb(9.8, 1.95, 8.1, 11.54, 1.99, 8.14, M.chrome)
  const cur = M.curtain(0xc3beb2)
  for (let k = 0; k < 10; k++) b.bb(9.82 + k * 0.17, 0.56, 8.095 + (k % 2) * 0.03, 9.82 + k * 0.17 + 0.17, 1.95, 8.115 + (k % 2) * 0.03, cur)
  b.bb(9.8, 1.6, 8.09, 11.54, 1.75, 8.13, M.fabricGrey)
  c.block(9.8, 0, 8.05, 11.54, 1.9, 8.875)
  b.bb(9.5, 0.004, 6.9, 10.3, 0.02, 7.5, M.rugGrey)
  b.bb(10.3, 0.004, 7.65, 11.3, 0.02, 8.0, M.rugGrey)
  b.cyl(11.35, 0, 6.2, 0.15, 0.4, M.whiteGloss, { seg: 10, solid: true })
  c.addLight(10.2, 2.5, 7.2, 0xffe6c0, 14, 8)
  b.cyl(10.2, 2.76, 7.2, 0.2, 0.04, M.bulb, { seg: 14 })

  /* ---------------- SUITE PARENTALE ---------------- */
  b.bb(14.0, 0.003, 5.0, 17.2, 0.022, 8.5, M.rugGrey)
  b.bb(15.6, 0.1, 5.75, 17.8, 0.38, 7.65, M.woodDark, { solid: true })
  b.bb(17.75, 0.1, 5.6, 17.875, 1.3, 7.8, M.fabricDark)
  b.bb(15.65, 0.38, 5.8, 17.75, 0.62, 7.6, M.linen)
  b.bb(15.62, 0.56, 5.77, 17.2, 0.7, 7.63, M.fabricCream)
  b.bb(15.62, 0.7, 5.77, 16.15, 0.745, 7.63, M.fabricGrey)
  b.box(17.5, 0.8, 6.2, 0.2, 0.16, 0.72, M.linen, { rot: [0, 0, -0.3] })
  b.box(17.5, 0.8, 7.2, 0.2, 0.16, 0.72, M.linen, { rot: [0, 0, -0.3] })
  b.box(17.15, 0.76, 6.5, 0.14, 0.34, 0.34, M.fabricGrey, { rot: [0, 0, -0.35] })
  b.box(17.15, 0.76, 6.95, 0.14, 0.3, 0.3, M.fabricBlue, { rot: [0, 0, -0.35] })
  for (const z of [5.2, 7.7]) {
    b.bb(17.4, 0, z, 17.85, 0.55, z + 0.5, M.cabinetDark, { solid: true })
    b.bb(17.39, 0.3, z + 0.02, 17.4, 0.32, z + 0.48, M.black)
    c.lamp(17.62, 0.55, z + 0.25, 0.46, true)
  }
  b.bb(17.5, 0.55, 5.35, 17.65, 0.6, 5.45, M.woodMid)
  c.picture(17.84, 1.9, 6.2, 'nx', 0.45, 0.6, 0)
  c.picture(17.84, 1.9, 7.2, 'nx', 0.45, 0.6, 1)
  // commode
  b.bb(11.66, 0, 6.7, 12.2, 0.9, 8.5, M.woodDark, { solid: true })
  for (let k = 1; k < 4; k++) b.bb(12.195, 0.05 + k * 0.2, 6.75, 12.205, 0.06 + k * 0.2, 8.45, M.black)
  for (let k = 0; k < 4; k++) b.bb(12.2, 0.12 + k * 0.2, 7.5, 12.23, 0.15 + k * 0.2, 7.7, M.steel)
  b.bb(11.66, 1.1, 7.0, 11.7, 2.0, 8.2, M.mirror)
  b.bb(11.655, 1.07, 6.95, 11.69, 2.04, 7.0, M.blackMetal)
  b.bb(11.655, 1.07, 8.2, 11.69, 2.04, 8.25, M.blackMetal)
  c.plant(11.95, 0.9, 8.2, 0.4)
  b.bb(11.8, 0.9, 7.0, 12.05, 1.0, 7.35, M.woodMid)
  // fauteuil
  b.beginObject('suite-armchair', 'Fauteuil bleu et coussin crème', 'furniture')
  b.bb(14.58, 0.07, 8.13, 15.42, 0.43, 8.77, M.fabricBlue, { solid: true })
  b.sph(15.0, 0.43, 8.42, 0.31, M.fabricBlue, { sx: 1.25, sy: 0.38, sz: 1.05, seg: 14 })
  b.bb(14.58, 0.4, 8.58, 15.42, 0.98, 8.78, M.fabricBlue)
  b.sph(15.0, 0.72, 8.72, 0.31, M.fabricBlue, { sx: 1.3, sy: 0.78, sz: 0.34, seg: 14 })
  b.cyl(14.62, 0.42, 8.45, 0.085, 0.48, M.fabricBlue, { seg: 12, rot: [P / 2, 0, 0] })
  b.cyl(15.38, 0.42, 8.45, 0.085, 0.48, M.fabricBlue, { seg: 12, rot: [P / 2, 0, 0] })
  b.bb(14.72, 0.43, 8.16, 15.28, 0.56, 8.58, M.fabricCream)
  b.sph(15.0, 0.53, 8.38, 0.27, M.fabricCream, { sx: 1.05, sy: 0.32, sz: 0.78, seg: 12 })
  for (const x of [14.66, 15.34]) for (const z of [8.2, 8.7]) b.cyl(x, 0, z, 0.028, 0.09, M.woodDark, { seg: 8 })
  b.endObject()
  c.plant(17.45, 0, 8.55, 1.5)
  c.addLight(14.8, 2.5, 6.8, 0xffd6a0, 16, 11)
  b.cyl(14.8, 2.76, 6.8, 0.26, 0.04, M.bulb, { seg: 16 })

  /* ---------------- DRESSING ---------------- */
  b.bb(13.06, 0, 0.2, 13.65, 2.3, 4.4, M.cabinet, { solid: true })
  for (const z of [1.25, 2.3, 3.35]) {
    b.bb(13.645, 0.05, z, 13.655, 2.25, z + 0.012, lineMat)
    b.bb(13.65, 1.0, z - 0.08, 13.68, 1.3, z - 0.05, M.black)
    b.bb(13.65, 1.0, z + 0.05, 13.68, 1.3, z + 0.08, M.black)
  }
  b.bb(13.7, 1.7, 0.3, 17.8, 1.73, 0.33, M.chrome)
  const palette = [0x2f3a4a, 0xd9d4c6, 0x6a3b3b, 0x3b3b3e, 0x8a8f6a, 0xb9a98a, 0x1f2a30, 0xc4c0b8]
  for (let x = 13.8; x < 17.7; x += 0.075) {
    const col = cm(palette[Math.floor(c.rand() * palette.length)], 1)
    b.bb(x, 0.95 + c.rand() * 0.2, 0.25, x + 0.04, 1.7, 0.42, col)
  }
  b.bb(13.7, 0.4, 0.125, 17.8, 0.43, 0.55, M.woodMid)
  b.bb(13.7, 1.95, 0.125, 17.8, 1.98, 0.55, M.woodMid)
  for (let k = 0; k < 8; k++) {
    const col = cm(palette[k % palette.length], 1)
    b.bb(13.8 + k * 0.5, 0.43, 0.2, 14.15 + k * 0.5, 0.55, 0.5, col)
    b.bb(13.8 + k * 0.5, 1.98, 0.2, 14.15 + k * 0.5, 2.15, 0.5, M.cardboard)
  }
  c.block(13.7, 0, 0.125, 17.8, 2.0, 0.55)
  b.bb(17.4, 0, 2.7, 17.875, 1.2, 4.3, M.woodMid, { solid: true })
  for (let k = 0; k < 4; k++) {
    b.bb(17.38, 0.25 + k * 0.3, 2.72, 17.4, 0.27 + k * 0.3, 4.28, M.woodDark)
    for (let q = 0; q < 4; q++) b.bb(17.2, 0.27 + k * 0.3, 2.8 + q * 0.38, 17.38, 0.35 + k * 0.3, 3.05 + q * 0.38, M.black)
  }
  b.bb(14.8, 0, 1.9, 16.4, 0.92, 2.7, M.cabinetDark, { solid: true })
  b.bb(14.75, 0.92, 1.85, 16.45, 0.96, 2.75, M.marble)
  for (let k = 0; k < 4; k++) b.bb(14.85 + k * 0.4, 0.05, 2.7, 15.2 + k * 0.4, 0.8, 2.71, lineMat)
  b.beginObject('dressing-box', 'Boîte à bijoux en bois et laiton')
  b.bb(14.99, 0.955, 2.09, 15.36, 1.005, 2.51, M.woodDark)
  b.bb(15.015, 1.0, 2.115, 15.335, 1.035, 2.485, M.woodMid)
  b.bb(15.04, 1.018, 2.14, 15.31, 1.026, 2.46, cm(0x6e2f36, 0.9))
  b.bb(15.145, 0.975, 2.49, 15.205, 1.015, 2.515, M.chrome)
  b.sph(15.175, 0.995, 2.52, 0.017, M.chrome, { seg: 8 })
  b.bb(15.03, 0.965, 2.095, 15.08, 0.985, 2.11, M.chrome)
  b.bb(15.27, 0.965, 2.095, 15.32, 0.985, 2.11, M.chrome)
  b.endObject()
  b.bb(17.82, 0.2, 0.4, 17.875, 1.95, 1.2, M.mirror)
  b.bb(14.3, 0.004, 3.0, 16.9, 0.02, 4.2, M.rugDark)
  c.addLight(15.4, 2.5, 2.2, 0xffe6c0, 14, 9)
  b.cyl(15.4, 2.76, 2.2, 0.2, 0.04, M.bulb, { seg: 14 })
  b.pop()
}

/* ============================================================ */
export function furnishBasement(c: Ctx) {
  const { b, M } = c
  b.push([0, -3, 0])

  // table de ping-pong
  b.bb(1.4, 0.74, 3.4, 2.925, 0.78, 6.14, cm(0x1f4e3a, 0.6))
  b.bb(2.15, 0.78, 3.4, 2.17, 0.781, 6.14, M.white)
  b.bb(1.4, 0.78, 4.76, 2.925, 0.781, 4.78, M.white)
  b.bb(1.3, 0.78, 4.76, 3.03, 0.96, 4.775, cm(0xdddddd, 1))
  legs4(c, 1.45, 3.45, 2.875, 6.09, 0.74, 0.05, M.blackMetal)
  c.block(1.3, 0, 3.4, 3.03, 0.8, 6.14)
  b.cyl(1.9, 0.78, 3.7, 0.08, 0.015, M.red, { seg: 12 })
  b.sph(2.4, 0.8, 5.5, 0.02, M.white, { seg: 6 })

  // étagères nord
  for (const x of [4.9, 6.3, 7.7, 8.84]) b.bb(x, 0, 0.125, x + 0.05, 2.0, 0.6, M.blackMetal)
  for (let k = 0; k < 4; k++) {
    b.bb(4.9, 0.3 + k * 0.5, 0.125, 8.89, 0.33 + k * 0.5, 0.6, M.steel)
    for (let q = 0; q < 6; q++) {
      const x = 5.0 + q * 0.64
      const y = 0.33 + k * 0.5
      if ((q + k) % 3 === 0) b.bb(x, y, 0.18, x + 0.5, y + 0.3, 0.55, M.tote)
      else if ((q + k) % 3 === 1) b.bb(x, y, 0.18, x + 0.5, y + 0.34, 0.55, M.cardboard)
      else b.bb(x, y, 0.2, x + 0.4, y + 0.26, 0.5, M.red)
    }
  }
  c.block(4.9, 0, 0.125, 8.89, 2.0, 0.6)

  // cartons
  b.beginObject('basement-boxes', 'Cartons étiquetés et bac bleu', 'furniture')
  const tape = cm(0xb9a98e, 0.82)
  const label = cm(0xd9d5c9, 0.9)
  b.bb(0.2, 0, 6.3, 0.9, 0.5, 7.0, M.cardboard, { solid: true })
  b.bb(0.2, 0.485, 6.3, 0.9, 0.51, 7.0, tape)
  b.bb(0.48, 0.2, 6.995, 0.68, 0.38, 7.01, label)
  b.bb(0.25, 0.5, 6.35, 0.85, 0.9, 6.95, M.cardboard)
  b.bb(0.25, 0.885, 6.35, 0.85, 0.905, 6.95, tape)
  b.bb(0.36, 0.62, 6.945, 0.55, 0.76, 6.96, label)
  b.bb(0.2, 0, 7.2, 0.9, 0.5, 7.9, M.cardboard, { solid: true })
  b.bb(0.47, 0.18, 7.89, 0.7, 0.36, 7.9, label)
  b.bb(0.2, 0, 8.05, 0.85, 0.42, 8.75, M.tote, { solid: true })
  b.bb(0.17, 0.4, 8.02, 0.88, 0.46, 8.78, cm(0x29435e, 0.58))
  b.bb(0.28, 0.46, 8.12, 0.42, 0.5, 8.68, cm(0x1f344c, 0.58))
  b.bb(0.58, 0.46, 8.12, 0.72, 0.5, 8.68, cm(0x1f344c, 0.58))
  b.bb(0.22, 0.5, 8.1, 0.8, 0.82, 8.7, M.cardboard)
  b.bb(0.22, 0.8, 8.1, 0.8, 0.825, 8.7, tape)
  b.endObject()

  // poteau + poutre
  b.bb(4.42, 0, 4.52, 4.58, 2.8, 4.68, M.blackMetal, { solid: true })
  b.bb(4.35, 0, 4.45, 4.65, 0.04, 4.75, M.steel)
  b.bb(0.13, 2.62, 4.52, 6.4, 2.8, 4.68, M.steel)

  // coin sport
  b.bb(3.5, 0.0, 7.0, 4.3, 0.45, 8.0, M.blackMetal, { solid: true })
  b.bb(3.55, 0.45, 7.05, 4.25, 0.55, 7.95, M.leather)
  b.bb(3.2, 0, 8.5, 4.4, 0.6, 8.85, M.blackMetal, { solid: true })
  for (let k = 0; k < 6; k++) {
    b.sph(3.3 + k * 0.2, 0.68, 8.7, 0.08, M.tire, { seg: 7 })
  }
  b.bb(5.0, 0.003, 6.0, 5.6, 0.03, 7.8, cm(0x3d5a7a, 0.9))

  // local technique
  b.bb(7.9, 0, 6.2, 8.6, 1.5, 6.9, cm(0xc9c9c6, 0.5, 0.4), { solid: true })
  b.bb(8.0, 1.5, 6.3, 8.5, 2.7, 6.8, M.steel)
  b.cyl(6.95, 0, 7.9, 0.28, 1.5, M.whiteGloss, { seg: 14 })
  c.block(6.65, 0, 7.6, 7.25, 1.5, 8.2)
  b.cyl(6.95, 1.5, 7.9, 0.03, 1.0, M.pipe, { seg: 6 })
  b.cyl(7.7, 1.15, 8.5, 0.03, 2.4, M.pipe, { seg: 6, rot: [0, 0, P / 2] })
  b.cyl(7.3, 1.3, 8.5, 0.03, 1.1, M.blue, { seg: 6 })
  b.bb(8.82, 1.2, 7.2, 8.875, 1.8, 7.8, cm(0x7a7d80, 0.5, 0.4))
  b.bb(8.8, 1.2, 8.2, 8.875, 1.5, 8.5, M.blackMetal)
  c.addLight(7.6, 2.3, 7.4, 0xfff0d0, 10, 6)

  // ampoules suspendues + lumières
  const bulb = (x: number, z: number) => {
    b.bb(x - 0.005, 2.45, z - 0.005, x + 0.005, 2.8, z + 0.005, M.black)
    b.sph(x, 2.4, z, 0.07, M.bulb, { seg: 8 })
    b.cyl(x, 2.45, z, 0.03, 0.05, M.black, { seg: 6 })
  }
  bulb(2.5, 5.0)
  bulb(6.0, 3.0)
  bulb(1.0, 0.8)
  bulb(3.0, 1.0)
  c.addLight(2.5, 2.3, 5.0, 0xffe6c0, 16, 10)
  c.addLight(6.0, 2.3, 3.0, 0xffe6c0, 14, 9)
  c.addLight(2.0, 2.2, 0.8, 0xffe0b0, 12, 7)
  // peintures / seaux
  b.cyl(5.5, 0, 5.3, 0.15, 0.35, M.blue, { seg: 10, solid: true })
  b.cyl(5.9, 0, 5.1, 0.15, 0.35, M.red, { seg: 10, solid: true })
  b.pop()
}
