import * as THREE from 'three'

export interface Collider {
  x1: number
  x2: number
  z1: number
  z2: number
  y0: number
  y1: number
  active: boolean
  kind?: 'wall' | 'window' | 'door' | 'furniture'
}

export interface HouseObject {
  id: string
  label: string
  kind: 'picture' | 'prop' | 'furniture' | 'screen'
  group: THREE.Group
  origin: THREE.Vector3
  bounds: THREE.Box3
  colliders: { live: Collider; original: Collider }[]
}

export interface Surface {
  x1: number
  x2: number
  z1: number
  z2: number
  h: number
  fn?: (x: number, z: number) => number
}

export type Face = 'px' | 'nx' | 'py' | 'ny' | 'pz' | 'nz'
export type MatSpec = THREE.Material | Partial<Record<Face | 'all' | 'sides', THREE.Material>>

export interface BoxOpts {
  rot?: [number, number, number]
  solid?: boolean
  skip?: Face[]
}

interface Bucket {
  pos: number[]
  nor: number[]
  uv: number[]
  idx: number[]
}

const cache = new Map<string, THREE.MeshStandardMaterial>()
export const lampMats: { mat: THREE.MeshStandardMaterial; base: number }[] = []

export function resetMaterialCache() {
  cache.clear()
  lampMats.length = 0
}

export function cm(color: number, rough = 0.8, metal = 0, emissive = 0, emI = 0) {
  const key = `${color}|${rough}|${metal}|${emissive}|${emI}`
  let m = cache.get(key)
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal })
    if (emI > 0) {
      m.emissive = new THREE.Color(emissive)
      m.emissiveIntensity = emI
      lampMats.push({ mat: m, base: emI })
    }
    cache.set(key, m)
  }
  return m
}

const FACES: { f: Face; n: [number, number, number]; u: [number, number]; v: [number, number] }[] = [
  // axis index, sign for u and v
  { f: 'px', n: [1, 0, 0], u: [2, -1], v: [1, 1] },
  { f: 'nx', n: [-1, 0, 0], u: [2, 1], v: [1, 1] },
  { f: 'py', n: [0, 1, 0], u: [2, 1], v: [0, 1] },
  { f: 'ny', n: [0, -1, 0], u: [0, 1], v: [2, 1] },
  { f: 'pz', n: [0, 0, 1], u: [0, 1], v: [1, 1] },
  { f: 'nz', n: [0, 0, -1], u: [0, -1], v: [1, 1] },
]

const tmpV = new THREE.Vector3()
const tmpN = new THREE.Vector3()

export class Builder {
  buckets = new Map<THREE.Material, Bucket>()
  stack: THREE.Matrix4[] = [new THREE.Matrix4()]
  colliders: Collider[] | null
  objects: HouseObject[] = []
  private objectStack: { id: string; label: string; kind: HouseObject['kind']; buckets: Map<THREE.Material, Bucket>; start: number }[] = []
  private emitters = new Map<string, THREE.MeshStandardMaterial>()

  constructor(colliders: Collider[] | null = null) {
    this.colliders = colliders
  }

  get top() {
    return this.stack[this.stack.length - 1]
  }

  push(pos: [number, number, number] = [0, 0, 0], rotY = 0) {
    const m = new THREE.Matrix4().compose(
      new THREE.Vector3(...pos),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(0, rotY, 0)),
      new THREE.Vector3(1, 1, 1),
    )
    this.stack.push(this.top.clone().multiply(m))
  }
  pop() {
    this.stack.pop()
  }

  // Detach selected existing geometry without changing its vertices or placement.
  beginObject(id: string, label: string, kind: HouseObject['kind'] = 'prop') {
    this.objectStack.push({ id, label, kind, buckets: this.buckets, start: this.colliders?.length ?? 0 })
    this.buckets = new Map()
  }

  endObject() {
    const record = this.objectStack.pop()
    if (!record) return
    const group = this.build(false)
    const bounds = new THREE.Box3().setFromObject(group)
    const origin = bounds.getCenter(new THREE.Vector3())
    group.children.forEach((child) => {
      if (child instanceof THREE.Mesh) child.geometry.translate(-origin.x, -origin.y, -origin.z)
    })
    group.position.copy(origin)
    group.name = record.id
    group.userData.houseObject = record.id
    this.objects.push({
      id: record.id, label: record.label, kind: record.kind, group, origin, bounds,
      colliders: (this.colliders?.slice(record.start) ?? []).map((live) => ({ live, original: { ...live } })),
    })
    this.buckets = record.buckets
  }

  private localEmitter(mat: THREE.Material, x: number, y: number, z: number) {
    if (!(mat instanceof THREE.MeshStandardMaterial) || mat.emissiveIntensity <= 0 || mat.emissive.g < 0.08) return mat
    const p = new THREE.Vector3(x, y, z).applyMatrix4(this.top)
    const key = `${mat.uuid}:${p.x.toFixed(1)}:${p.y.toFixed(1)}:${p.z.toFixed(1)}`
    let copy = this.emitters.get(key)
    if (!copy) {
      copy = mat.clone()
      copy.userData.emitterPoint = p.toArray()
      copy.userData.emitterBase = copy.emissiveIntensity
      this.emitters.set(key, copy)
    }
    return copy
  }

  private bucket(m: THREE.Material) {
    let b = this.buckets.get(m)
    if (!b) {
      b = { pos: [], nor: [], uv: [], idx: [] }
      this.buckets.set(m, b)
    }
    return b
  }

  private addCollider(pts: THREE.Vector3[]) {
    if (!this.colliders) return
    let x1 = Infinity,
      x2 = -Infinity,
      y0 = Infinity,
      y1 = -Infinity,
      z1 = Infinity,
      z2 = -Infinity
    for (const p of pts) {
      x1 = Math.min(x1, p.x)
      x2 = Math.max(x2, p.x)
      y0 = Math.min(y0, p.y)
      y1 = Math.max(y1, p.y)
      z1 = Math.min(z1, p.z)
      z2 = Math.max(z2, p.z)
    }
    this.colliders.push({ x1, x2, y0, y1, z1, z2, active: true })
  }

  box(cx: number, cy: number, cz: number, w: number, h: number, d: number, spec: MatSpec, o: BoxOpts = {}) {
    const half = [w / 2, h / 2, d / 2]
    const local = new THREE.Matrix4().compose(
      new THREE.Vector3(cx, cy, cz),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(...(o.rot ?? [0, 0, 0]))),
      new THREE.Vector3(1, 1, 1),
    )
    const T = this.top.clone().multiply(local)
    const isMat = spec instanceof THREE.Material
    for (const F of FACES) {
      if (o.skip && o.skip.includes(F.f)) continue
      let mat: THREE.Material | undefined
      if (isMat) mat = spec as THREE.Material
      else {
        const s = spec as Partial<Record<string, THREE.Material>>
        const side = F.f === 'py' || F.f === 'ny' ? undefined : s.sides
        mat = s[F.f] ?? side ?? s.all
      }
      if (!mat) continue
      mat = this.localEmitter(mat, cx, cy, cz)
      const b = this.bucket(mat)
      const base = b.pos.length / 3
      const nAxis = F.n[0] !== 0 ? 0 : F.n[1] !== 0 ? 1 : 2
      const nSign = F.n[nAxis]
      tmpN.set(F.n[0], F.n[1], F.n[2]).transformDirection(T)
      const ax = Math.abs(tmpN.x),
        ay = Math.abs(tmpN.y),
        az = Math.abs(tmpN.z)
      const corners = [
        [-1, -1],
        [1, -1],
        [1, 1],
        [-1, 1],
      ]
      for (const [su, sv] of corners) {
        const p = [0, 0, 0]
        p[nAxis] = nSign * half[nAxis]
        p[F.u[0]] = su * F.u[1] * half[F.u[0]]
        p[F.v[0]] = sv * F.v[1] * half[F.v[0]]
        tmpV.set(p[0], p[1], p[2]).applyMatrix4(T)
        b.pos.push(tmpV.x, tmpV.y, tmpV.z)
        b.nor.push(tmpN.x, tmpN.y, tmpN.z)
        if (ay >= ax && ay >= az) b.uv.push(tmpV.x, tmpV.z)
        else if (ax >= az) b.uv.push(tmpV.z, tmpV.y)
        else b.uv.push(tmpV.x, tmpV.y)
      }
      b.idx.push(base, base + 1, base + 2, base, base + 2, base + 3)
    }
    if (o.solid) {
      const pts: THREE.Vector3[] = []
      for (const sx of [-1, 1])
        for (const sy of [-1, 1])
          for (const sz of [-1, 1])
            pts.push(new THREE.Vector3(sx * half[0], sy * half[1], sz * half[2]).applyMatrix4(T))
      this.addCollider(pts)
    }
  }

  /** boîte par coins min / max */
  bb(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, spec: MatSpec, o: BoxOpts = {}) {
    this.box((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2, Math.abs(x2 - x1), Math.abs(y2 - y1), Math.abs(z2 - z1), spec, o)
  }

  geo(
    g: THREE.BufferGeometry,
    pos: [number, number, number],
    mat: THREE.Material,
    o: { rot?: [number, number, number]; scale?: [number, number, number]; solid?: boolean } = {},
  ) {
    const local = new THREE.Matrix4().compose(
      new THREE.Vector3(...pos),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(...(o.rot ?? [0, 0, 0]))),
      new THREE.Vector3(...(o.scale ?? [1, 1, 1])),
    )
    const T = this.top.clone().multiply(local)
    const b = this.bucket(this.localEmitter(mat, ...pos))
    const base = b.pos.length / 3
    const p = g.getAttribute('position')
    const n = g.getAttribute('normal')
    const u = g.getAttribute('uv')
    for (let i = 0; i < p.count; i++) {
      tmpV.set(p.getX(i), p.getY(i), p.getZ(i)).applyMatrix4(T)
      b.pos.push(tmpV.x, tmpV.y, tmpV.z)
      tmpN.set(n.getX(i), n.getY(i), n.getZ(i)).transformDirection(T)
      b.nor.push(tmpN.x, tmpN.y, tmpN.z)
      b.uv.push(u ? u.getX(i) : 0, u ? u.getY(i) : 0)
    }
    if (g.index) for (let i = 0; i < g.index.count; i++) b.idx.push(base + g.index.getX(i))
    else for (let i = 0; i < p.count; i++) b.idx.push(base + i)
    if (o.solid) {
      g.computeBoundingBox()
      const bb = g.boundingBox!
      const pts: THREE.Vector3[] = []
      for (const x of [bb.min.x, bb.max.x])
        for (const y of [bb.min.y, bb.max.y])
          for (const z of [bb.min.z, bb.max.z]) pts.push(new THREE.Vector3(x, y, z).applyMatrix4(T))
      this.addCollider(pts)
    }
  }

  cyl(
    cx: number,
    y0: number,
    cz: number,
    r: number,
    h: number,
    mat: THREE.Material,
    o: { seg?: number; rTop?: number; rot?: [number, number, number]; solid?: boolean } = {},
  ) {
    const g = new THREE.CylinderGeometry(o.rTop ?? r, r, h, o.seg ?? 16)
    this.geo(g, [cx, y0 + h / 2, cz], mat, { rot: o.rot, solid: o.solid })
    g.dispose()
  }

  sph(
    cx: number,
    cy: number,
    cz: number,
    r: number,
    mat: THREE.Material,
    o: { sx?: number; sy?: number; sz?: number; seg?: number; solid?: boolean } = {},
  ) {
    const g = new THREE.SphereGeometry(1, o.seg ?? 12, Math.max(6, (o.seg ?? 12) - 4))
    this.geo(g, [cx, cy, cz], mat, { scale: [r * (o.sx ?? 1), r * (o.sy ?? 1), r * (o.sz ?? 1)], solid: o.solid })
    g.dispose()
  }

  cone(cx: number, y0: number, cz: number, r: number, h: number, mat: THREE.Material, seg = 8) {
    const g = new THREE.ConeGeometry(r, h, seg)
    this.geo(g, [cx, y0 + h / 2, cz], mat)
    g.dispose()
  }

  build(includeObjects = true): THREE.Group {
    const group = new THREE.Group()
    for (const [mat, b] of this.buckets) {
      if (!b.idx.length) continue
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.Float32BufferAttribute(b.pos, 3))
      g.setAttribute('normal', new THREE.Float32BufferAttribute(b.nor, 3))
      g.setAttribute('uv', new THREE.Float32BufferAttribute(b.uv, 2))
      g.setIndex(new THREE.BufferAttribute(new Uint32Array(b.idx), 1))
      g.computeBoundingSphere()
      const mesh = new THREE.Mesh(g, mat)
      const transparent = (mat as THREE.MeshStandardMaterial).transparent
      mesh.castShadow = !transparent && !mat.userData.noShadow
      mesh.receiveShadow = !transparent
      if (transparent) mesh.renderOrder = 2
      group.add(mesh)
    }
    if (includeObjects) this.objects.forEach((o) => group.add(o.group))
    return group
  }
}
