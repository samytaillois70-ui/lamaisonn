import * as THREE from 'three'

const HALF = Math.PI / 2

const stdCache = new Map<string, THREE.MeshStandardMaterial>()
/** Plain materials are shared: a drawer full of junk would otherwise create hundreds of identical ones. */
const std = (color: number, rough = 0.6, metal = 0, extra: THREE.MeshStandardMaterialParameters = {}) => {
  if (Object.keys(extra).length) return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, envMapIntensity: 0.6, ...extra })
  const key = `${color}|${rough}|${metal}`
  let m = stdCache.get(key)
  if (!m) { m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, envMapIntensity: 0.6 }); stdCache.set(key, m) }
  return m
}

function put(group: THREE.Group, geometry: THREE.BufferGeometry, material: THREE.Material, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(geometry, material)
  m.position.set(x, y, z)
  m.rotation.set(rx, ry, rz)
  m.castShadow = false
  m.receiveShadow = false
  group.add(m)
  return m
}

function rng(seed: number) {
  let s = seed >>> 0
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0
    return s / 4294967296
  }
}

function canvasTexture(w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void) {
  const canvas = document.createElement('canvas')
  canvas.width = w
  canvas.height = h
  draw(canvas.getContext('2d')!, w, h)
  const t = new THREE.CanvasTexture(canvas)
  t.colorSpace = THREE.SRGBColorSpace
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.anisotropy = 4
  return t
}

let handleTexture: THREE.CanvasTexture | null = null
/** Hammer handle: grain runs along the length (the texture varies around the cylinder, not along it). */
function woodHandle() {
  if (handleTexture) return handleTexture
  const r = rng(5)
  handleTexture = canvasTexture(128, 128, (c, w, h) => {
    c.fillStyle = '#8a6038'
    c.fillRect(0, 0, w, h)
    for (let i = 0; i < 110; i++) {
      c.strokeStyle = `rgba(${r() > 0.5 ? '44,26,12' : '176,132,86'},${0.1 + r() * 0.28})`
      c.lineWidth = 0.6 + r() * 1.7
      const x = r() * w
      c.beginPath()
      c.moveTo(x, 0)
      c.bezierCurveTo(x + (r() - 0.5) * 6, h * 0.33, x + (r() - 0.5) * 6, h * 0.66, x + (r() - 0.5) * 4, h)
      c.stroke()
    }
    // Sweat and dirt where a hand has held it for years.
    c.fillStyle = 'rgba(30,18,10,.32)'
    c.fillRect(0, h * 0.28, w, h * 0.34)
  })
  return handleTexture
}

let steelTexture: THREE.CanvasTexture | null = null
/** Scratched steel with orange rust blooms. */
function rustSteel() {
  if (steelTexture) return steelTexture
  const r = rng(12)
  steelTexture = canvasTexture(128, 128, (c, w, h) => {
    c.fillStyle = '#8e9296'
    c.fillRect(0, 0, w, h)
    for (let i = 0; i < 60; i++) {
      c.strokeStyle = `rgba(${r() > 0.5 ? '230,232,236' : '50,52,56'},${0.12 + r() * 0.3})`
      c.lineWidth = 0.4 + r() * 0.8
      const x = r() * w
      const y = r() * h
      const a = r() * Math.PI
      c.beginPath()
      c.moveTo(x, y)
      c.lineTo(x + Math.cos(a) * (6 + r() * 26), y + Math.sin(a) * (6 + r() * 26))
      c.stroke()
    }
    for (let i = 0; i < 18; i++) {
      c.fillStyle = `rgba(${120 + r() * 40},${58 + r() * 20},${24 + r() * 14},${0.22 + r() * 0.42})`
      c.beginPath()
      c.ellipse(r() * w, r() * h, 3 + r() * 14, 2 + r() * 9, r() * 3, 0, 7)
      c.fill()
    }
    for (let i = 0; i < 700; i++) {
      c.fillStyle = `rgba(${r() > 0.5 ? '255,255,255' : '0,0,0'},${r() * 0.1})`
      c.fillRect(r() * w, r() * h, 1, 1)
    }
  })
  return steelTexture
}

/** A claw hammer lying along the x axis, about 33 cm long, with a worn handle and a rusty head. */
export function buildHammer() {
  const g = new THREE.Group()
  const gt = woodHandle()
  const wood = new THREE.MeshStandardMaterial({ color: 0xffffff, map: gt, bumpMap: gt, bumpScale: 0.012, roughness: 0.78 })
  const rt = rustSteel()
  const steel = new THREE.MeshStandardMaterial({ color: 0xffffff, map: rt, bumpMap: rt, bumpScale: 0.012, roughness: 0.52, metalness: 0.8, envMapIntensity: 0.6 })
  const grip = std(0x1b1c1e, 0.92)
  put(g, new THREE.CylinderGeometry(0.0158, 0.0124, 0.3, 16), wood, 0, 0, 0, 0, 0, HALF)
  put(g, new THREE.CylinderGeometry(0.0166, 0.0166, 0.11, 16), grip, -0.08, 0, 0, 0, 0, HALF)
  for (let i = 0; i < 5; i++) put(g, new THREE.TorusGeometry(0.0168, 0.0013, 6, 18), std(0x2a2b2e, 0.9), -0.13 + i * 0.02, 0, 0, 0, HALF, 0)
  put(g, new THREE.BoxGeometry(0.038, 0.038, 0.036), steel, 0.155, 0, 0)
  put(g, new THREE.BoxGeometry(0.032, 0.032, 0.05), steel, 0.155, 0, 0.04)
  put(g, new THREE.CylinderGeometry(0.0195, 0.0195, 0.024, 16), steel, 0.155, 0, 0.076, HALF, 0, 0)
  const claw = put(g, new THREE.BoxGeometry(0.03, 0.026, 0.078), steel, 0.155, 0, -0.06)
  claw.rotation.x = 0.35
  put(g, new THREE.BoxGeometry(0.004, 0.014, 0.062), std(0x0e0f10, 0.5, 0.6), 0.155, 0.003, -0.06)
  return g
}

function tagTexture(text: string, bg: string, fg: string) {
  return canvasTexture(64, 96, (c, w, h) => {
    c.fillStyle = bg
    c.fillRect(0, 0, w, h)
    c.strokeStyle = fg
    c.lineWidth = 3
    c.strokeRect(4, 4, w - 8, h - 8)
    c.fillStyle = fg
    c.font = 'bold 15px sans-serif'
    c.textAlign = 'center'
    c.translate(w / 2, h / 2)
    c.rotate(-Math.PI / 2)
    c.fillText(text, 0, 5)
  })
}

/** A key with a handwritten tag, lying along x. Door keys are brass, gun keys steel, drawer keys small and silver. */
export function buildKey(kind: 'door' | 'gun' | 'drawer') {
  const g = new THREE.Group()
  const rt = rustSteel()
  const brass = kind === 'door'
    ? new THREE.MeshStandardMaterial({ color: 0xc19a46, roughness: 0.4, metalness: 0.9, bumpMap: rt, bumpScale: 0.004 })
    : kind === 'gun'
      ? new THREE.MeshStandardMaterial({ color: 0x9ea3a7, roughness: 0.34, metalness: 0.95, bumpMap: rt, bumpScale: 0.004 })
      : new THREE.MeshStandardMaterial({ color: 0xcfd2d6, roughness: 0.26, metalness: 0.95 })
  const size = kind === 'drawer' ? 0.78 : 1
  put(g, new THREE.TorusGeometry(0.0165, 0.0036, 8, 22), brass, -0.04, 0, 0, HALF, 0, 0)
  put(g, new THREE.CylinderGeometry(0.0034, 0.0034, 0.075, 8), brass, 0.005, 0, 0, 0, 0, HALF)
  for (const [x, z, w] of [[0.036, -0.0055, 0.011], [0.022, -0.0055, 0.008], [0.03, 0.0055, 0.007], [0.043, 0.0055, 0.006]] as const) {
    put(g, new THREE.BoxGeometry(w, 0.0066, 0.0068), brass, x, 0, z)
  }
  if (kind !== 'drawer') {
    const map = kind === 'door' ? tagTexture('PORTE', '#a22a22', '#f0e6d2') : tagTexture('ARMES', '#17181b', '#e0d8c4')
    const tag = put(g, new THREE.BoxGeometry(0.036, 0.0024, 0.054), new THREE.MeshStandardMaterial({ color: 0xffffff, map, roughness: 0.7 }), -0.077, 0, 0.006)
    tag.rotation.y = 0.08
    // The string the tag hangs from.
    put(g, new THREE.TorusGeometry(0.009, 0.0009, 5, 12), std(0xcfc6b0, 0.95), -0.058, 0, 0.0, HALF, 0, 0)
  }
  g.scale.setScalar(size)
  return g
}

/** A folded sheet of paper with scribbled lines and a coffee ring. */
export function buildNote() {
  const g = new THREE.Group()
  const r = rng(7)
  const texture = canvasTexture(128, 180, (c) => {
    c.fillStyle = '#d9d2bd'
    c.fillRect(0, 0, 128, 180)
    c.strokeStyle = 'rgba(60,54,44,.55)'
    c.lineWidth = 1.2
    for (let i = 0; i < 9; i++) {
      c.beginPath()
      c.moveTo(14, 26 + i * 15)
      for (let x = 14; x < 100 - r() * 24; x += 6) c.lineTo(x, 26 + i * 15 + (r() - 0.5) * 4)
      c.stroke()
    }
    c.strokeStyle = 'rgba(110,80,36,.28)'
    c.lineWidth = 3
    c.beginPath()
    c.ellipse(96, 150, 20, 17, 0.4, 0.3, 5.9)
    c.stroke()
  })
  put(g, new THREE.BoxGeometry(0.14, 0.003, 0.2), std(0xffffff, 0.95, 0, { map: texture }), 0, 0.0015, 0, 0, 0.3, 0)
  return g
}

/** A pistol pointing along -z with the origin at the centre of the grip. */
export function buildPistol() {
  const g = new THREE.Group()
  const steel = std(0x1a1c1f, 0.34, 0.86)
  const polymer = std(0x141517, 0.7, 0.1)
  const bright = std(0x6c7075, 0.3, 0.95)
  put(g, new THREE.BoxGeometry(0.03, 0.035, 0.19), steel, 0, 0.032, -0.05)
  for (let i = 0; i < 5; i++) put(g, new THREE.BoxGeometry(0.032, 0.03, 0.0035), polymer, 0, 0.034, 0.02 + i * 0.01)
  put(g, new THREE.CylinderGeometry(0.0078, 0.0078, 0.02, 12), bright, 0, 0.03, -0.152, HALF, 0, 0)
  put(g, new THREE.BoxGeometry(0.028, 0.02, 0.16), polymer, 0, 0.006, -0.03)
  const grip = put(g, new THREE.BoxGeometry(0.031, 0.105, 0.046), polymer, 0, -0.045, 0.034)
  grip.rotation.x = -0.2
  put(g, new THREE.BoxGeometry(0.0035, 0.018, 0.038), polymer, 0, -0.022, -0.036)
  put(g, new THREE.BoxGeometry(0.0035, 0.004, 0.034), polymer, 0, -0.03, -0.054)
  put(g, new THREE.BoxGeometry(0.0035, 0.018, 0.004), polymer, 0, -0.022, -0.072)
  put(g, new THREE.BoxGeometry(0.004, 0.016, 0.004), bright, 0, -0.01, -0.02)
  put(g, new THREE.BoxGeometry(0.004, 0.007, 0.006), bright, 0, 0.0525, 0.034)
  put(g, new THREE.BoxGeometry(0.004, 0.007, 0.006), bright, 0, 0.0525, -0.137)
  return g
}

/** A brass cartridge lying along x. */
export function buildCartridge() {
  const g = new THREE.Group()
  const brass = std(0xc2973e, 0.3, 0.9)
  put(g, new THREE.CylinderGeometry(0.0045, 0.0045, 0.03, 12), brass, 0, 0, 0, 0, 0, HALF)
  put(g, new THREE.CylinderGeometry(0.0048, 0.0048, 0.003, 12), std(0xa67c2e, 0.35, 0.9), -0.0155, 0, 0, 0, 0, HALF)
  put(g, new THREE.CylinderGeometry(0.0022, 0.0045, 0.012, 12), std(0xb8683a, 0.4, 0.8), 0.021, 0, 0, 0, 0, -HALF)
  return g
}

export const CLUTTER_KINDS = ['pencil', 'clip', 'battery', 'tape', 'matches', 'coin', 'screws', 'band', 'fuse', 'envelope'] as const
export type ClutterKind = (typeof CLUTTER_KINDS)[number]

let matchTexture: THREE.CanvasTexture | null = null
let envelopeTexture: THREE.CanvasTexture | null = null

/**
 * The junk that fills every real drawer. Each model rests on y = 0, so it can be set straight on the
 * bottom of a drawer. It makes a drawer look lived in, and makes the one object that matters take a look.
 */
export function buildClutter(kind: ClutterKind) {
  const g = new THREE.Group()
  switch (kind) {
    case 'pencil': {
      put(g, new THREE.CylinderGeometry(0.0036, 0.0036, 0.15, 6), std(0xd9a62a, 0.55), 0, 0.0036, 0, 0, 0, HALF)
      put(g, new THREE.ConeGeometry(0.0036, 0.016, 6), std(0xcaa176, 0.7), -0.083, 0.0036, 0, 0, 0, HALF)
      put(g, new THREE.ConeGeometry(0.0012, 0.005, 6), std(0x222222, 0.5), -0.0925, 0.0036, 0, 0, 0, HALF)
      put(g, new THREE.CylinderGeometry(0.0033, 0.0033, 0.009, 8), std(0xd68b94, 0.8), 0.079, 0.0036, 0, 0, 0, HALF)
      put(g, new THREE.CylinderGeometry(0.0038, 0.0038, 0.007, 8), std(0xaeb2b6, 0.3, 0.9), 0.0715, 0.0036, 0, 0, 0, HALF)
      break
    }
    case 'clip': {
      for (let i = 0; i < 2; i++) {
        const loop = put(g, new THREE.TorusGeometry(0.007 - i * 0.0018, 0.0007, 5, 14), std(0xb8bcc0, 0.3, 0.9), i * 0.006, 0.0007, 0, HALF, 0, 0)
        loop.scale.set(1, 1.7, 1)
      }
      break
    }
    case 'battery': {
      put(g, new THREE.CylinderGeometry(0.0075, 0.0075, 0.05, 12), std(0x1c1d1f, 0.45, 0.4), 0, 0.0075, 0, 0, 0, HALF)
      put(g, new THREE.CylinderGeometry(0.0075, 0.0075, 0.012, 12), std(0xb8793a, 0.35, 0.8), 0.019, 0.0075, 0, 0, 0, HALF)
      put(g, new THREE.CylinderGeometry(0.0028, 0.0028, 0.004, 8), std(0xc2c6ca, 0.3, 0.9), 0.027, 0.0075, 0, 0, 0, HALF)
      break
    }
    case 'tape': {
      const ring = put(g, new THREE.TorusGeometry(0.017, 0.0065, 8, 22), std(0xcfc3a4, 0.55, 0, { transparent: true, opacity: 0.92 }), 0, 0.0065, 0, HALF, 0, 0)
      ring.scale.set(1, 1, 0.85)
      put(g, new THREE.CylinderGeometry(0.0125, 0.0125, 0.012, 16, 1, true), std(0x8c7b5c, 0.9, 0, { side: THREE.DoubleSide }), 0, 0.006, 0)
      break
    }
    case 'matches': {
      if (!matchTexture) matchTexture = canvasTexture(64, 40, (c, w, h) => {
        c.fillStyle = '#b8352a'
        c.fillRect(0, 0, w, h)
        c.fillStyle = '#e8dcc0'
        c.fillRect(6, 8, w - 12, h - 16)
        c.fillStyle = '#7d2a20'
        c.font = 'bold 9px sans-serif'
        c.fillText('SAFETY', 12, 24)
      })
      put(g, new THREE.BoxGeometry(0.05, 0.012, 0.034), std(0xffffff, 0.8, 0, { map: matchTexture }), 0, 0.006, 0)
      for (let i = 0; i < 2; i++) {
        put(g, new THREE.CylinderGeometry(0.0009, 0.0009, 0.04, 5), std(0xcaa176, 0.7), -0.01 + i * 0.012, 0.0014, 0.028 + i * 0.004, 0, 0.2, HALF)
        put(g, new THREE.SphereGeometry(0.0017, 6, 5), std(0x7d1d18, 0.6), 0.011 - i * 0.012, 0.0014, 0.028 + i * 0.004)
      }
      break
    }
    case 'coin': {
      put(g, new THREE.CylinderGeometry(0.0115, 0.0115, 0.0018, 20), std(0xb8bcc0, 0.3, 0.95), 0, 0.0009, 0)
      break
    }
    case 'screws': {
      const r = rng(3)
      for (let i = 0; i < 6; i++) {
        put(g, new THREE.CylinderGeometry(0.0022, 0.0022, 0.016, 6), std(0x9ca0a4, 0.4, 0.9), (r() - 0.5) * 0.04, 0.0022, (r() - 0.5) * 0.03, 0, r() * 3, HALF)
        put(g, new THREE.CylinderGeometry(0.0042, 0.0042, 0.0018, 8), std(0xaeb2b6, 0.35, 0.9), (r() - 0.5) * 0.04, 0.0022, (r() - 0.5) * 0.03)
      }
      break
    }
    case 'band': {
      const t = put(g, new THREE.TorusGeometry(0.014, 0.0011, 5, 18), std(0xb85a3a, 0.7), 0, 0.0011, 0, HALF, 0, 0)
      t.scale.set(1.4, 1, 1)
      break
    }
    case 'fuse': {
      put(g, new THREE.CylinderGeometry(0.0045, 0.0045, 0.022, 10), std(0xd8dcd8, 0.15, 0, { transparent: true, opacity: 0.6 }), 0, 0.0045, 0, 0, 0, HALF)
      for (const s of [-1, 1]) put(g, new THREE.CylinderGeometry(0.005, 0.005, 0.005, 10), std(0xb8bcc0, 0.3, 0.9), s * 0.0125, 0.0045, 0, 0, 0, HALF)
      break
    }
    case 'envelope': {
      if (!envelopeTexture) envelopeTexture = canvasTexture(128, 80, (c, w, h) => {
        c.fillStyle = '#d6cdb4'
        c.fillRect(0, 0, w, h)
        c.strokeStyle = 'rgba(80,70,50,.45)'
        c.beginPath()
        c.moveTo(0, 0)
        c.lineTo(w / 2, h * 0.55)
        c.lineTo(w, 0)
        c.stroke()
        c.fillStyle = 'rgba(70,60,44,.55)'
        c.fillRect(w * 0.42, h * 0.72, w * 0.3, 2)
        c.fillRect(w * 0.42, h * 0.8, w * 0.2, 2)
      })
      put(g, new THREE.BoxGeometry(0.11, 0.0018, 0.07), std(0xffffff, 0.95, 0, { map: envelopeTexture }), 0, 0.0009, 0)
      break
    }
  }
  return g
}
