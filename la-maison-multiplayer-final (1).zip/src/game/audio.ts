import * as THREE from 'three'
import type { HouseSystem } from './house'

export type SoundKind =
  | 'step' | 'stepTile' | 'stepConcrete'
  | 'door' | 'knock' | 'pipe' | 'drip' | 'creak' | 'scrape' | 'thud'
  | 'static' | 'breath' | 'click' | 'hum' | 'heartbeat'
  | 'whisper' | 'rasp' | 'thunder'
  | 'gunshot' | 'scream' | 'wood' | 'beep' | 'key' | 'drawer' | 'glitch'
  | 'roar' | 'cry' | 'crunch' | 'squelch' | 'tear'
  | 'bonestep' | 'clicks' | 'musicbox' | 'impact' | 'drag' | 'lockrattle' | 'rattle' | 'whisperRev' | 'paper'

type LoopKind = 'hum' | 'wind' | 'pipe' | 'rain'
interface LoopSpec { id: string; kind: LoopKind; position: [number, number, number]; gain: number; ref?: number; rolloff?: number; max?: number }
interface Loop { id: string; source: AudioBufferSourceNode; gain: GainNode; filter: BiquadFilterNode; panner: PannerNode; base: number; position: THREE.Vector3; kind: LoopKind; lastBlocks: number }

// Permanent house sounds, each placed where the real object is: fridge in the kitchen,
// wind outside the east wall, the boiler in the technical room, pipes in the laundry.
const LOOPS: LoopSpec[] = [
  { id: 'fridge', kind: 'hum', position: [10.6, 1.0, 0.5], gain: 0.085 },
  { id: 'wind', kind: 'wind', position: [19.6, 2.1, 5.2], gain: 0.2 },
  { id: 'boiler', kind: 'hum', position: [7.3, -1.6, 7.6], gain: 0.07 },
  { id: 'pipes', kind: 'pipe', position: [6.7, 1.3, 0.6], gain: 0.03 },
  // Rain on the roof: wide and nearly constant in distance, so only the ceilings above you muffle it.
  { id: 'rain', kind: 'rain', position: [12, 7.6, 4.5], gain: 0.2, ref: 8, rolloff: 0.12, max: 60 },
]

export class HouseAudio {
  context: AudioContext | null = null
  private master?: GainNode
  private compressor?: DynamicsCompressorNode
  private ambientGain?: GainNode
  private toneGain?: GainNode
  private tone?: OscillatorNode
  private gate?: GainNode
  private muffler?: BiquadFilterNode
  private dry?: GainNode
  private wet?: GainNode
  private shaper?: WaveShaperNode
  /** 0..1: how broken the sound is. Distortion, dropouts and a wandering pitch. */
  glitch = 0
  private glitchClock = 0
  private warped = false
  private reverbIn?: GainNode
  private reverbOut?: GainNode
  private reverbTone?: BiquadFilterNode
  private presenceGain?: GainNode
  private dreadAmp?: GainNode
  private dreadFilter?: BiquadFilterNode
  private presencePanner?: PannerNode
  private presenceNodes: OscillatorNode[] = []
  private loops: Loop[] = []
  private voices = new Set<AudioBufferSourceNode>()
  private listener = new THREE.Vector3()
  private bufferCache = new Map<SoundKind, AudioBuffer>()
  volume = 0.65
  quiet = false
  private spokenWhisperAt = 0

  constructor(private house: HouseSystem) {}

  async unlock() {
    // Browsers refuse audio before a click or key press; wait for one instead of warning on every call.
    if (!this.context && typeof navigator !== 'undefined' && navigator.userActivation && !navigator.userActivation.hasBeenActive) return
    try {
      if (!this.context) {
        const a = new AudioContext()
        this.context = a
        this.master = a.createGain()
        this.compressor = a.createDynamicsCompressor()
        this.compressor.threshold.value = -20
        this.compressor.ratio.value = 6
        this.master.gain.value = this.volume
        this.gate = a.createGain()
        this.dry = a.createGain()
        this.wet = a.createGain()
        this.wet.gain.value = 0
        this.shaper = a.createWaveShaper()
        const curve = new Float32Array(1024)
        for (let i = 0; i < curve.length; i++) {
          const x = (i / (curve.length - 1)) * 2 - 1
          curve[i] = Math.sign(x) * Math.pow(Math.abs(Math.tanh(x * 5.5)), 0.7)
        }
        this.shaper.curve = curve
        this.shaper.oversample = '2x'
        this.master.connect(this.dry).connect(this.gate)
        this.master.connect(this.shaper).connect(this.wet).connect(this.gate)
        // A low-pass on the whole mix: the world goes dull and far away when the end comes.
        this.muffler = a.createBiquadFilter()
        this.muffler.type = 'lowpass'
        this.muffler.frequency.value = 22000
        this.gate.connect(this.muffler).connect(this.compressor).connect(a.destination)
        this.ambientGain = a.createGain()
        this.ambientGain.gain.value = 1
        this.ambientGain.connect(this.master)
        this.toneGain = a.createGain()
        this.toneGain.gain.value = 0
        this.toneGain.connect(this.master)
        this.tone = a.createOscillator()
        this.tone.type = 'sine'
        this.tone.frequency.value = 4300
        this.tone.connect(this.toneGain)
        this.tone.start()
        this.createReverb()
        this.createLoops()
        this.createPresence()
        this.createDread()
      }
      if (this.context.state === 'suspended') await this.context.resume()
    } catch { /* Silent play remains available if browser audio is blocked. */ }
  }

  setVolume(value: number) {
    this.volume = value
    if (this.master && this.context) this.master.gain.setTargetAtTime(value, this.context.currentTime, 0.1)
  }

  setPaused(paused: boolean) {
    this.quiet = paused
    if (this.master && this.context) this.master.gain.setTargetAtTime(paused ? 0 : this.volume, this.context.currentTime, 0.12)
  }

  /** Ambient level, 0 during a dynamic silence. Heartbeat and breath are not affected. */
  setAmbient(level: number) {
    if (this.ambientGain && this.context) this.ambientGain.gain.setTargetAtTime(level, this.context.currentTime, 0.18)
  }

  /** Very quiet high tone, used for tinnitus under strong stress. Capped by the caller. */
  setTone(level: number) {
    if (this.toneGain && this.context) this.toneGain.gain.setTargetAtTime(Math.min(0.012, level), this.context.currentTime, 0.3)
  }

  /** Room acoustics: a convolution reverb whose wet level and brightness follow the listener's room. */
  private createReverb() {
    const a = this.context!
    const seconds = 2.6
    const length = Math.floor(a.sampleRate * seconds)
    const impulse = a.createBuffer(2, length, a.sampleRate)
    for (let c = 0; c < 2; c++) {
      const data = impulse.getChannelData(c)
      let low = 0
      for (let i = 0; i < length; i++) {
        const t = i / a.sampleRate
        // Dense early reflections, then an exponential tail that loses highs as it decays.
        const noise = Math.random() * 2 - 1
        low += (noise - low) * Math.min(1, 0.9 - t * 0.28)
        data[i] = (noise * 0.35 + low * 0.65) * Math.exp(-t * 2.6) * (i < 900 ? i / 900 : 1)
      }
    }
    const convolver = a.createConvolver()
    convolver.buffer = impulse
    this.reverbIn = a.createGain()
    this.reverbIn.gain.value = 1
    this.reverbTone = a.createBiquadFilter()
    this.reverbTone.type = 'lowpass'
    this.reverbTone.frequency.value = 4000
    this.reverbOut = a.createGain()
    this.reverbOut.gain.value = 0.18
    this.reverbIn.connect(convolver).connect(this.reverbTone).connect(this.reverbOut).connect(this.master!)
  }

  /** wet 0..1: how much of the room is heard. bright: high-frequency content of the tail in Hz. */
  setReverb(wet: number, bright: number) {
    if (!this.reverbOut || !this.reverbTone || !this.context) return
    this.reverbOut.gain.setTargetAtTime(wet, this.context.currentTime, 0.4)
    this.reverbTone.frequency.setTargetAtTime(bright, this.context.currentTime, 0.4)
  }

  /** Rain intensity, 0..1.5. Scales the roof loop; the rest of the mix is untouched. */
  setRain(level: number) {
    const loop = this.loops.find((l) => l.id === 'rain')
    if (!loop || !this.context) return
    loop.base = 0.2 * level
    loop.lastBlocks = -1
  }

  /** 0 = clear, 1 = as if heard through a wall and a pillow. */
  setMuffle(level: number) {
    const a = this.context
    if (!a || !this.muffler) return
    const l = Math.max(0, Math.min(1, level))
    this.muffler.frequency.setTargetAtTime(220 + 21800 * Math.pow(1 - l, 3), a.currentTime, 0.12)
  }

  /** Everything sounds wrong: a hard distortion, sudden dropouts and a pitch that drifts. */
  setGlitch(level: number) {
    this.glitch = Math.max(0, Math.min(1, level))
    const a = this.context
    if (!a || !this.wet || !this.dry) return
    this.wet.gain.setTargetAtTime(this.glitch * 0.9, a.currentTime, 0.04)
    this.dry.gain.setTargetAtTime(1 - this.glitch * 0.45, a.currentTime, 0.04)
  }

  tick(dt: number) {
    const a = this.context
    if (!a || !this.gate) return
    this.glitchClock -= dt
    if (this.glitch > 0.02) {
      if (this.glitchClock <= 0) {
        this.glitchClock = 0.04 + Math.random() * 0.12
        this.gate.gain.setTargetAtTime(Math.random() < 0.18 * this.glitch ? 0 : 1, a.currentTime, 0.004)
        const warp = Math.max(0.35, 1 + (Math.random() - 0.5) * 1.2 * this.glitch - (Math.random() < 0.1 ? 0.5 : 0))
        for (const loop of this.loops) loop.source.playbackRate.setTargetAtTime(warp, a.currentTime, 0.02)
        this.warped = true
      }
    } else if (this.warped) {
      this.warped = false
      this.gate.gain.setTargetAtTime(1, a.currentTime, 0.02)
      for (const loop of this.loops) loop.source.playbackRate.setTargetAtTime(1, a.currentTime, 0.2)
    }
  }

  heartbeat(strength: number) {
    this.play('heartbeat', undefined, strength)
  }

  /** Optional browser voice layer for rare, short French whispers. It is intentionally sparse. */
  whisperPhrase(text: string, strength = 0.22) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window) || this.quiet) return
    const now = performance.now()
    if (now < this.spokenWhisperAt) return
    this.spokenWhisperAt = now + 18000
    try {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'fr-FR'
      utterance.rate = 0.62
      utterance.pitch = 0.35
      utterance.volume = Math.min(0.38, Math.max(0.04, strength))
      window.speechSynthesis.speak(utterance)
    } catch { /* Voice synthesis is optional; the procedural audio remains. */ }
  }

  /**
   * A low pressure in the sound that follows the creature. It is felt more than heard:
   * sub tones that beat against each other, with no melody and no obvious source.
   */
  setPresence(level: number, position: THREE.Vector3) {
    if (!this.presenceGain || !this.presencePanner || !this.context) return
    this.presenceGain.gain.setTargetAtTime(this.quiet ? 0 : Math.min(1, level) * 0.075, this.context.currentTime, 0.5)
    this.presencePanner.positionX.value = position.x
    this.presencePanner.positionY.value = position.y
    this.presencePanner.positionZ.value = position.z
  }

  /**
   * A dissonant drone under everything: a minor second and its harmonics through a slow filter, with a
   * tremolo too slow to notice. It follows the player's stress and goes with the ambience in a silence.
   */
  private createDread() {
    const a = this.context!
    const amp = a.createGain()
    amp.gain.value = 0
    const filter = a.createBiquadFilter()
    filter.type = 'lowpass'
    filter.frequency.value = 180
    filter.Q.value = 2.5
    const trem = a.createGain()
    trem.gain.value = 0.75
    const lfo = a.createOscillator()
    lfo.frequency.value = 0.11
    const lfoDepth = a.createGain()
    lfoDepth.gain.value = 0.25
    lfo.connect(lfoDepth).connect(trem.gain)
    lfo.start()
    this.presenceNodes.push(lfo)
    const tones: [OscillatorType, number, number][] = [['sine', 55, 1], ['sine', 58.27, 0.9], ['triangle', 110.4, 0.35], ['triangle', 116.8, 0.3], ['sawtooth', 164.8, 0.07], ['sawtooth', 174.6, 0.06], ['sine', 2093, 0.012]]
    for (const [type, frequency, level] of tones) {
      const osc = a.createOscillator()
      osc.type = type
      osc.frequency.value = frequency
      const g = a.createGain()
      g.gain.value = level
      osc.connect(g).connect(filter)
      osc.start()
      this.presenceNodes.push(osc)
    }
    filter.connect(trem).connect(amp).connect(this.ambientGain!)
    this.dreadAmp = amp
    this.dreadFilter = filter
  }

  /** 0..1: how heavy the drone is. */
  setDread(level: number) {
    if (!this.dreadAmp || !this.dreadFilter || !this.context) return
    const l = Math.max(0, Math.min(1, level))
    const t = this.context.currentTime
    this.dreadAmp.gain.setTargetAtTime(this.quiet ? 0 : l * l * 0.08, t, 0.6)
    this.dreadFilter.frequency.setTargetAtTime(150 + l * 650, t, 0.6)
  }

  private createPresence() {
    const a = this.context!
    const gain = a.createGain()
    gain.gain.value = 0
    const panner = a.createPanner()
    panner.panningModel = 'HRTF'
    panner.distanceModel = 'inverse'
    panner.refDistance = 2
    panner.maxDistance = 30
    panner.rolloffFactor = 0.6
    const low = a.createBiquadFilter()
    low.type = 'lowpass'
    low.frequency.value = 180
    const tones: [OscillatorType, number, number][] = [['sine', 37, 1], ['sine', 40.6, 0.9], ['sawtooth', 74.2, 0.2], ['sine', 111, 0.1]]
    for (const [type, frequency, level] of tones) {
      const osc = a.createOscillator()
      osc.type = type
      osc.frequency.value = frequency
      const oscGain = a.createGain()
      oscGain.gain.value = level
      osc.connect(oscGain).connect(low)
      osc.start()
      this.presenceNodes.push(osc)
    }
    low.connect(gain).connect(panner).connect(this.master!)
    this.presenceGain = gain
    this.presencePanner = panner
  }

  update(position: THREE.Vector3, yaw: number) {
    this.listener.copy(position)
    const a = this.context
    if (!a) return
    const l = a.listener
    if (l.positionX) {
      l.positionX.value = position.x; l.positionY.value = position.y; l.positionZ.value = position.z
      l.forwardX.value = -Math.sin(yaw); l.forwardY.value = 0; l.forwardZ.value = -Math.cos(yaw)
      l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0
    } else {
      l.setPosition(position.x, position.y, position.z)
      l.setOrientation(-Math.sin(yaw), 0, -Math.cos(yaw), 0, 1, 0)
    }
  }

  /** Re-evaluates walls and doors between the listener and each permanent source. */
  updateLoops() {
    const a = this.context
    if (!a) return
    for (const loop of this.loops) {
      const blocks = this.house.occlusion(this.listener, loop.position, false)
      if (blocks === loop.lastBlocks) continue
      loop.lastBlocks = blocks
      const cutoff = loop.kind === 'rain' ? Math.max(650, 4200 / (1 + blocks * 1.05)) : blocks ? Math.max(180, 1900 / (1 + blocks * 1.6)) : 2400
      loop.filter.frequency.setTargetAtTime(cutoff, a.currentTime, 0.25)
      loop.gain.gain.setTargetAtTime(loop.base * Math.pow(0.6, blocks), a.currentTime, 0.25)
    }
  }

  private createLoops() {
    const a = this.context!
    for (const spec of LOOPS) {
      const source = a.createBufferSource()
      source.buffer = this.loopBuffer(spec.kind)
      source.loop = true
      const filter = a.createBiquadFilter()
      filter.type = 'lowpass'
      filter.frequency.value = spec.kind === 'rain' ? 4200 : 2400
      const gain = a.createGain()
      gain.gain.value = spec.gain
      const panner = a.createPanner()
      panner.panningModel = 'HRTF'
      panner.distanceModel = 'inverse'
      panner.refDistance = spec.ref ?? 1.2
      panner.maxDistance = spec.max ?? 16
      panner.rolloffFactor = spec.rolloff ?? 1.6
      panner.positionX.value = spec.position[0]
      panner.positionY.value = spec.position[1]
      panner.positionZ.value = spec.position[2]
      source.connect(filter).connect(gain).connect(panner).connect(this.ambientGain!)
      source.start()
      this.loops.push({ id: spec.id, source, gain, filter, panner, base: spec.gain, position: new THREE.Vector3(...spec.position), kind: spec.kind, lastBlocks: -1 })
    }
  }

  private loopBuffer(kind: LoopKind) {
    const a = this.context!
    const seconds = 4
    const n = Math.floor(a.sampleRate * seconds)
    const fade = Math.floor(a.sampleRate * 0.25)
    const data = new Float32Array(n)
    let brown = 0
    let smooth = 0
    for (let i = 0; i < n; i++) {
      const t = i / a.sampleRate
      const noise = Math.random() * 2 - 1
      brown = (brown + noise * 0.04) / 1.02
      smooth += (noise - smooth) * 0.02
      let v = 0
      if (kind === 'hum') v = Math.sin(2 * Math.PI * 52 * t) * 0.5 + Math.sin(2 * Math.PI * 104 * t) * 0.18 + Math.sin(2 * Math.PI * 156 * t) * 0.07 + brown * 0.1
      else if (kind === 'pipe') v = Math.sin(2 * Math.PI * 120 * t) * 0.22 + Math.sin(2 * Math.PI * 240 * t) * 0.08 + brown * 0.12
      else if (kind === 'rain') v = ((noise - smooth) * 0.55 + noise * 0.12) * (0.82 + Math.sin(2 * Math.PI * t * 3 / seconds) * 0.1 + Math.random() * 0.08) + (Math.random() < 0.0016 ? (Math.random() - 0.5) * 1.6 : 0)
      else v = (smooth * 1.6 + brown * 0.8) * (0.75 + Math.sin(2 * Math.PI * t / seconds) * 0.25)
      data[i] = v
    }
    // Seamless loop: blend the start into the tail so the repeat never clicks.
    const length = n - fade
    const buffer = a.createBuffer(1, length, a.sampleRate)
    const out = buffer.getChannelData(0)
    for (let i = 0; i < length; i++) out[i] = data[i]
    for (let i = 0; i < fade; i++) {
      const k = i / fade
      out[i] = data[i] * k + data[length + i] * (1 - k)
    }
    return buffer
  }

  /** Cuts a recording into slices and repeats, drops or reverses some of them: a voice that skips. */
  private stutter(data: Float32Array) {
    const sr = this.context!.sampleRate
    const out = new Float32Array(data.length)
    let i = 0
    while (i < data.length) {
      const seg = Math.floor(sr * (0.03 + Math.random() * 0.09))
      const end = Math.min(data.length, i + seg)
      const mode = Math.random()
      for (let k = i; k < end; k++) {
        if (mode < 0.2) out[k] = k - seg >= 0 ? out[k - seg] : data[k]
        else if (mode < 0.3) out[k] = 0
        else if (mode < 0.4) out[k] = data[end - 1 - (k - i)]
        else out[k] = data[k]
      }
      i = end
    }
    data.set(out)
  }

  private buffer(kind: SoundKind) {
    const a = this.context!
    const cached = this.bufferCache.get(kind)
    if (cached) return cached
    const duration: Record<SoundKind, number> = {
      step: 0.18, stepTile: 0.12, stepConcrete: 0.24, door: 0.68, knock: 1.1, pipe: 1.9, drip: 0.6, creak: 1.8,
      scrape: 1.2, thud: 1.5, static: 0.18, breath: 1.25, click: 0.07, hum: 3.5, heartbeat: 0.75,
      whisper: 2.6, rasp: 2.2, thunder: 6.5,
      gunshot: 1.8, scream: 3.2, wood: 0.9, beep: 0.3, key: 0.8, drawer: 0.7, glitch: 0.5,
      roar: 3.5, cry: 2.4, crunch: 0.55, squelch: 0.7, tear: 1.0,
      bonestep: 0.42, clicks: 1.0, musicbox: 7.6, impact: 2.4, drag: 2.7, lockrattle: 0.55, rattle: 0.7, whisperRev: 2.6, paper: 0.7,
    }
    const buffer = a.createBuffer(1, Math.floor(a.sampleRate * duration[kind]), a.sampleRate)
    const data = buffer.getChannelData(0)
    let brown = 0
    let r1a = 0, r1b = 0, r2a = 0, r2b = 0
    let scPhase = 0, s1a = 0, s1b = 0, s2a = 0, s2b = 0
    for (let i = 0; i < data.length; i++) {
      const t = i / a.sampleRate, progress = i / data.length
      const noise = Math.random() * 2 - 1
      brown = (brown + noise * 0.065) / 1.035
      let value = 0
      switch (kind) {
        case 'step': value = (brown * 2.4 + Math.sin(t * 2 * Math.PI * 68) * 0.17) * Math.exp(-t * 27); break
        case 'stepTile': value = (noise * 0.6 + Math.sin(t * 2 * Math.PI * 2600) * 0.16) * Math.exp(-t * 115) + brown * 0.3 * Math.exp(-t * 30); break
        case 'stepConcrete': value = (brown * 2.9 + Math.sin(t * 2 * Math.PI * 74) * 0.28) * Math.exp(-t * 21); break
        case 'door': value = (brown * 1.5 + Math.sin(t * 2 * Math.PI * (130 - t * 90)) * 0.08) * Math.sin(progress * Math.PI) + noise * 0.14 * Math.exp(-t * 80); break
        case 'knock': { const hit = t % 0.34; value = (Math.sin(hit * 2 * Math.PI * 95) * 0.35 + brown * 1.2) * Math.exp(-hit * 48); break }
        case 'pipe': value = Math.sin(t * 2 * Math.PI * 142 + Math.sin(t * 11) * 0.8) * 0.13 * Math.exp(-t * 2.1) + brown * 0.16; break
        case 'drip': value = Math.sin(t * 2 * Math.PI * (900 + 800 * Math.exp(-t * 14))) * 0.35 * Math.exp(-t * 16); break
        case 'creak': value = (Math.sin(t * 2 * Math.PI * (172 + Math.sin(t * 4.2) * 17)) * 0.045 + brown * 0.18) * Math.sin(progress * Math.PI); break
        case 'scrape': value = brown * 1.1 * (0.6 + 0.4 * Math.sin(2 * Math.PI * 11 * t) ** 2) * Math.sin(progress * Math.PI) + noise * 0.035 * Math.sin(progress * Math.PI); break
        case 'thud': value = Math.sin(2 * Math.PI * 50 * t) * Math.exp(-t * 4.2) * 0.7 + brown * 0.5 * Math.exp(-t * 3.4); break
        case 'static': value = noise * 0.045 * Math.sin(progress * Math.PI); break
        case 'whisper':
        case 'whisperRev': {
          // Breath pushed through two moving resonances: syllables with no words.
          const syl = Math.pow(Math.max(0, Math.sin(2 * Math.PI * 1.9 * t + Math.sin(t * 2.3) * 1.4)), 1.6) * Math.sin(progress * Math.PI)
          const w1 = 2 * Math.PI * (480 + 280 * Math.sin(2 * Math.PI * 0.9 * t)) / a.sampleRate
          const w2 = 2 * Math.PI * (1650 + 650 * Math.sin(2 * Math.PI * 1.3 * t + 1)) / a.sampleRate
          const y1 = noise * 0.03 + 2 * 0.985 * Math.cos(w1) * r1a - 0.985 * 0.985 * r1b
          const y2 = noise * 0.03 + 2 * 0.985 * Math.cos(w2) * r2a - 0.985 * 0.985 * r2b
          r1b = r1a; r1a = y1; r2b = r2a; r2a = y2
          value = (y1 + y2 * 0.7) * syl * 0.5
          break
        }
        case 'bonestep': {
          // A heavy, wet foot, and the long nails that touch the floor a moment before the heel.
          const claw = (d: number) => (t > d ? (noise - brown * 3) * Math.exp(-(t - d) * 260) * 0.7 : 0)
          value = Math.sin(2 * Math.PI * 48 * t) * Math.exp(-t * 16) * 0.9 + brown * 1.6 * Math.exp(-t * 20) + claw(0.012) + claw(0.05) + claw(0.085) * 0.7 + (t > 0.1 ? brown * 0.5 * Math.exp(-(t - 0.1) * 14) : 0)
          break
        }
        case 'clicks': {
          // Tongue clicks, irregular, like something that finds its way by sound.
          const times = [0.04, 0.11, 0.15, 0.31, 0.37, 0.52, 0.56, 0.61, 0.8]
          let v = 0
          for (let k = 0; k < times.length; k++) {
            const d = times[k]
            if (t > d) v += (Math.sin(2 * Math.PI * (900 + (k * 137) % 700) * (t - d)) * 0.5 + noise * 0.35) * Math.exp(-(t - d) * (140 + (k % 3) * 50))
          }
          value = v
          break
        }
        case 'musicbox': {
          // A music box that is wearing out: it slows, it goes flat, and two notes are missing.
          const melody = [659.3, 587.3, 523.3, 587.3, 659.3, 659.3, 659.3, 587.3, 587.3, 587.3, 659.3, 784, 784]
          const drift = 1 - 0.035 * progress - 0.012 * Math.sin(t * 2.2)
          let v = 0
          for (let k = 0; k < melody.length; k++) {
            if (k === 4 || k === 9) continue
            const tt = t - (k * 0.52 + (k > 5 ? 0.06 * (k - 5) : 0))
            if (tt < 0) continue
            const f = melody[k] * drift * (k > 7 ? 0.97 : 1)
            v += (Math.sin(2 * Math.PI * f * tt) * 0.5 + Math.sin(2 * Math.PI * f * 2.76 * tt) * 0.18 * Math.exp(-tt * 6) + Math.sin(2 * Math.PI * f * 5.4 * tt) * 0.06 * Math.exp(-tt * 12)) * Math.exp(-tt * 2.6)
          }
          value = v * 0.5 * Math.min(1, (7.6 - t) / 0.6)
          break
        }
        case 'impact': value = Math.sin(2 * Math.PI * (62 - 28 * Math.min(1, t * 1.2)) * t) * Math.exp(-t * 2.6) * 0.95 + noise * Math.exp(-t * 55) * 0.4 + brown * 1.2 * Math.exp(-t * 4); break
        case 'drag': {
          const m = Math.pow(0.5 + 0.5 * Math.sin(2 * Math.PI * 1.7 * t + Math.sin(t * 3) * 1.2), 2)
          value = (brown * 1.5 + (noise - brown * 2) * 0.12) * m * Math.pow(Math.sin(progress * Math.PI), 0.7) + (Math.sin(t * 37) > 0.985 ? noise * 0.4 : 0)
          break
        }
        case 'lockrattle': {
          const tick = (d: number) => (t > d ? (Math.sin(2 * Math.PI * (2300 + d * 900) * (t - d)) * 0.5 + noise * 0.3) * Math.exp(-(t - d) * 95) : 0)
          value = tick(0) + tick(0.07) * 0.8 + tick(0.13) * 0.9 + tick(0.21) * 0.6 + tick(0.27) * 0.5
          break
        }
        case 'rattle': {
          const times = [0.03, 0.09, 0.12, 0.2, 0.26, 0.33, 0.4]
          let v = 0
          for (let k = 0; k < times.length; k++) {
            const d = times[k]
            if (t > d) v += (noise * 0.4 + Math.sin(2 * Math.PI * (1200 + k * 300) * (t - d)) * 0.25) * Math.exp(-(t - d) * (70 + k * 10)) * (1 - k * 0.1)
          }
          value = v
          break
        }
        case 'paper': value = (noise - brown * 2.6) * 0.5 * Math.pow(Math.sin(progress * Math.PI), 0.6) * (0.55 + 0.45 * Math.sin(2 * Math.PI * 17 * t + Math.sin(t * 40))); break
        case 'roar': {
          // Not a voice: a chest. A very low sawtooth through two moving resonances, growled at 27 Hz.
          const f0 = 46 + 24 * Math.sin(2 * Math.PI * 0.6 * t) + (t < 0.15 ? 70 * (1 - t / 0.15) : 0)
          scPhase += f0 / a.sampleRate
          const saw = (scPhase % 1) * 2 - 1
          const growl = 0.55 + 0.45 * Math.sin(2 * Math.PI * 27 * t)
          const fa = 2 * Math.PI * (260 + 130 * Math.sin(2 * Math.PI * 0.9 * t)) / a.sampleRate
          const fb = 2 * Math.PI * (900 + 320 * Math.sin(2 * Math.PI * 1.7 * t + 1)) / a.sampleRate
          const ya = saw * 0.3 + noise * 0.1 + 2 * 0.98 * Math.cos(fa) * s1a - 0.98 * 0.98 * s1b
          const yb = saw * 0.3 + noise * 0.12 + 2 * 0.975 * Math.cos(fb) * s2a - 0.975 * 0.975 * s2b
          s1b = s1a; s1a = ya; s2b = s2a; s2a = yb
          const env = Math.min(1, t / 0.03) * Math.min(1, (3.5 - t) / 0.9)
          value = Math.tanh((ya * 0.5 + yb * 0.4 + brown * 0.9) * 3.2 * growl) * env * 0.9
          break
        }
        case 'cry': {
          // The player's own scream: higher, shorter of breath, tearing at the edges.
          const base = 520 + 340 * Math.sin(2 * Math.PI * 1.1 * t) + 180 * Math.sin(2 * Math.PI * 3.4 * t + 1) + (t > 0.2 ? 90 : 0)
          const f0 = Math.max(220, base) * (1 + 0.03 * Math.sin(2 * Math.PI * 6.5 * t))
          scPhase += f0 / a.sampleRate
          const saw = (scPhase % 1) * 2 - 1
          const fa = 2 * Math.PI * (900 + 200 * Math.sin(2 * Math.PI * 0.9 * t)) / a.sampleRate
          const fb = 2 * Math.PI * (2300 + 400 * Math.sin(2 * Math.PI * 1.4 * t + 2)) / a.sampleRate
          const ya = saw * 0.22 + noise * 0.07 + 2 * 0.97 * Math.cos(fa) * s1a - 0.97 * 0.97 * s1b
          const yb = saw * 0.22 + noise * 0.07 + 2 * 0.97 * Math.cos(fb) * s2a - 0.97 * 0.97 * s2b
          s1b = s1a; s1a = ya; s2b = s2a; s2a = yb
          const env = Math.min(1, t / 0.03) * (0.75 + 0.25 * Math.sin(2 * Math.PI * 4 * t)) * Math.min(1, (2.4 - t) / 0.5)
          value = Math.tanh((ya * 0.5 + yb * 0.5) * 2.2) * env * 0.8
          break
        }
        case 'crunch': {
          const hit = (d: number, k: number, f: number) => (t > d ? (noise * 0.7 + Math.sin(2 * Math.PI * f * (t - d)) * 0.8) * Math.exp(-(t - d) * k) : 0)
          value = hit(0, 38, 95) + hit(0.12, 44, 130) * 0.8 + hit(0.23, 50, 80) * 0.6 + brown * 0.4 * Math.exp(-t * 7)
          break
        }
        case 'squelch': value = (noise * 0.5 * (0.5 + 0.5 * Math.sin(2 * Math.PI * (30 + 90 * progress) * t)) + brown * 1.2) * Math.pow(Math.sin(progress * Math.PI), 0.6) * 0.8; break
        case 'tear': value = noise * (0.5 + 0.5 * Math.sign(Math.sin(2 * Math.PI * 55 * t))) * Math.sin(progress * Math.PI) * 0.6 + brown * 0.5 * Math.sin(progress * Math.PI); break
        case 'gunshot': {
          const crack = noise * Math.exp(-t * 95)
          const boom = brown * 2.2 * Math.exp(-t * 9) + Math.sin(2 * Math.PI * 58 * t) * 0.85 * Math.exp(-t * 13)
          const room = noise * 0.06 * Math.exp(-t * 2.4) * (0.5 + 0.5 * Math.sin(t * 90))
          value = crack + boom + room
          break
        }
        case 'scream': {
          // A voice that is wrong: a sliding pitch, two moving formants, breath, hard clipping.
          const base = 430 + 380 * Math.sin(2 * Math.PI * 0.8 * t) + 260 * Math.sin(2 * Math.PI * 2.3 * t + 1) + (Math.sin(t * 7) > 0.9 ? 520 : 0)
          const f0 = Math.max(120, base) * (1 + 0.045 * Math.sin(2 * Math.PI * 7.5 * t))
          scPhase += f0 / a.sampleRate
          const saw = (scPhase % 1) * 2 - 1
          const fa = 2 * Math.PI * (780 + 380 * Math.sin(2 * Math.PI * 1.1 * t)) / a.sampleRate
          const fb = 2 * Math.PI * (1750 + 700 * Math.sin(2 * Math.PI * 0.7 * t + 2)) / a.sampleRate
          const ya = saw * 0.2 + noise * 0.05 + 2 * 0.975 * Math.cos(fa) * s1a - 0.975 * 0.975 * s1b
          const yb = saw * 0.2 + noise * 0.05 + 2 * 0.97 * Math.cos(fb) * s2a - 0.97 * 0.97 * s2b
          s1b = s1a; s1a = ya; s2b = s2a; s2a = yb
          const env = Math.min(1, t / 0.04) * (0.6 + 0.4 * Math.pow(Math.sin(2 * Math.PI * 3.1 * t), 2)) * Math.min(1, (3.2 - t) / 0.4)
          value = Math.tanh((ya * 0.55 + yb * 0.45) * 2.6) * env * 0.9
          break
        }
        case 'wood': {
          const hit = (d: number, k: number) => (t > d ? noise * Math.exp(-(t - d) * k) : 0)
          value = hit(0, 48) * 0.8 + hit(0.07, 60) * 0.7 + hit(0.15, 70) * 0.6 + Math.sin(2 * Math.PI * 92 * t) * Math.exp(-t * 9) * 0.5 + brown * 0.5 * Math.exp(-t * 6)
          break
        }
        case 'beep': value = Math.sin(2 * Math.PI * 1850 * t) * 0.42 * Math.min(1, t / 0.004) * Math.min(1, (0.3 - t) / 0.03); break
        case 'key': {
          const ring = (d: number) => (t > d ? Math.exp(-(t - d) * 16) * (Math.sin(2 * Math.PI * 3300 * (t - d)) * 0.22 + Math.sin(2 * Math.PI * 4600 * (t - d)) * 0.16 + Math.sin(2 * Math.PI * 5900 * (t - d)) * 0.1) : 0)
          value = ring(0) + ring(0.09) * 0.7 + ring(0.19) * 0.5 + noise * 0.03 * Math.exp(-t * 60)
          break
        }
        case 'drawer': value = (brown * 1.9 * Math.sin(progress * Math.PI) ** 0.7 + Math.sin(2 * Math.PI * 64 * t) * 0.1) * (0.7 + 0.3 * Math.sin(2 * Math.PI * 14 * t)) + (progress > 0.82 ? noise * 0.3 * Math.exp(-(progress - 0.82) * 40) : 0); break
        case 'glitch': value = (Math.floor(t * 64) % 3 === 0 ? noise : (Math.floor(t * 40) % 2 ? Math.sign(Math.sin(t * 3000)) * 0.4 : 0)) * 0.5 * Math.min(1, (0.5 - t) / 0.1); break
        case 'thunder': {
          // A crack, then a long low rolling that fades.
          const crack = noise * Math.exp(-t * 26) * 0.5
          const roll = brown * 2.4 * Math.exp(-t * 0.62) * (0.6 + 0.4 * Math.sin(2 * Math.PI * 1.7 * t + Math.sin(t * 0.9) * 2) ** 2)
          value = crack + roll + Math.sin(2 * Math.PI * 38 * t) * 0.22 * Math.exp(-t * 0.5)
          break
        }
        case 'rasp': {
          // A slow, wet breath in, a pause, a long rattling breath out.
          const env = progress < 0.45 ? Math.sin(progress / 0.45 * Math.PI) * 0.75 : progress < 0.56 ? 0 : Math.sin((progress - 0.56) / 0.44 * Math.PI)
          value = (noise * 0.35 + brown * 1.1) * env * (0.5 + 0.5 * (Math.sin(2 * Math.PI * 37 * t) > 0.2 ? 1 : 0.15))
          break
        }
        case 'breath': value = brown * 0.62 * Math.sin(progress * Math.PI) ** 2; break
        case 'click': value = noise * 0.23 * Math.exp(-t * 110); break
        case 'hum': value = (Math.sin(t * Math.PI * 100) * 0.035 + Math.sin(t * Math.PI * 198) * 0.012 + brown * 0.08) * Math.sin(progress * Math.PI); break
        case 'heartbeat': {
          const t2 = t - 0.32
          value = Math.sin(2 * Math.PI * 46 * t) * Math.exp(-t * 24) * 0.95 + (t2 > 0 ? Math.sin(2 * Math.PI * 54 * t2) * Math.exp(-t2 * 30) * 0.6 : 0) + brown * 0.04
          break
        }
      }
      data[i] = Math.max(-0.65, Math.min(0.65, value))
    }
    if (kind === 'scream') this.stutter(data)
    if (kind === 'whisperRev') data.reverse()
    this.bufferCache.set(kind, buffer)
    return buffer
  }

  play(kind: SoundKind, position?: THREE.Vector3, strength = 0.6) {
    const a = this.context
    if (!a || !this.master || this.quiet || this.voices.size >= 12 || a.state !== 'running') return
    const src = a.createBufferSource()
    src.buffer = this.buffer(kind)
    src.playbackRate.value = (0.94 + Math.random() * 0.12) * (this.glitch > 0.02 ? 0.55 + Math.random() * 0.8 : 1)
    const gain = a.createGain(), filter = a.createBiquadFilter()
    const blocks = position ? this.house.occlusion(this.listener, position, false) : 0
    filter.type = 'lowpass'
    filter.frequency.value = blocks ? Math.max(240, 1800 / (blocks * 1.8)) : kind === 'breath' || kind === 'heartbeat' ? 1600 : 6500
    gain.gain.value = Math.min(1, strength) * Math.pow(0.58, blocks)
    src.connect(filter).connect(gain)
    let pan: PannerNode | undefined
    if (position) {
      pan = a.createPanner()
      pan.panningModel = 'HRTF'
      pan.distanceModel = 'inverse'
      pan.refDistance = 1.6
      pan.maxDistance = 28
      pan.rolloffFactor = 1.35
      pan.positionX.value = position.x; pan.positionY.value = position.y; pan.positionZ.value = position.z
      gain.connect(pan).connect(this.master)
    } else gain.connect(this.master)
    let send: GainNode | undefined
    if (this.reverbIn && kind !== 'heartbeat' && kind !== 'static' && kind !== 'click') {
      send = a.createGain()
      send.gain.value = kind === 'breath' ? 0.12 : 0.55
      ;(pan ?? gain).connect(send).connect(this.reverbIn)
    }
    this.voices.add(src)
    src.onended = () => { this.voices.delete(src); src.disconnect(); filter.disconnect(); gain.disconnect(); pan?.disconnect(); send?.disconnect() }
    src.start()
  }

  dispose() {
    this.voices.forEach((voice) => { voice.onended = null; try { voice.stop() } catch { /* Already ended. */ } voice.disconnect() })
    this.voices.clear()
    this.loops.forEach((loop) => { try { loop.source.stop() } catch { /* Already stopped. */ } loop.source.disconnect() })
    this.loops = []
    try { this.tone?.stop() } catch { /* Already stopped. */ }
    this.presenceNodes.forEach((osc) => { try { osc.stop() } catch { /* Already stopped. */ } })
    this.presenceNodes = []
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
    this.master?.disconnect()
    this.compressor?.disconnect()
    void this.context?.close()
    this.bufferCache.clear()
  }
}
