import * as THREE from 'three'
import type { HouseSystem } from './house'
import type { HouseAudio, SoundKind } from './audio'

export type DreadState = 'CALME' | 'INQUIÉTUDE' | 'TENSION' | 'PRÉSENCE' | 'DANGER' | 'CLIMAX'
export const DREAD_STATES: DreadState[] = ['CALME', 'INQUIÉTUDE', 'TENSION', 'PRÉSENCE', 'DANGER', 'CLIMAX']

export interface AtmosphereSample {
  dt: number
  progress: number
  playerPos: THREE.Vector3
  roomLit: boolean
  torchOn: boolean
  running: boolean
  cameraActive: boolean
  openAnomalies: number
  batteryLow: boolean
  entityActive: boolean
  entityPos: THREE.Vector3
  entityDistance: number
  entitySeen: boolean
  intensity: number
}

export function dreadFor(value: number): DreadState {
  if (value < 0.18) return 'CALME'
  if (value < 0.34) return 'INQUIÉTUDE'
  if (value < 0.5) return 'TENSION'
  if (value < 0.66) return 'PRÉSENCE'
  if (value < 0.82) return 'DANGER'
  return 'CLIMAX'
}

/**
 * Invisible stress model. It rises fast when something threatens the player
 * and falls slowly, the way adrenaline actually behaves. Its outputs drive the
 * heartbeat, breathing, tinnitus, silences, camera tremor and tunnel vision.
 */
export class Atmosphere {
  stress = 0
  heartRate = 62
  pulse = 0
  tremorYaw = 0
  tremorPitch = 0
  ambient = 1
  private ambientTarget = 1
  private silence = 0
  private silenceCooldown = 50
  private beatTimer = 0
  private breathTimer = 0
  private entityBreathTimer = 7
  private tinnitus = 0
  private time = 0
  private loopClock = 0
  private state: DreadState = 'CALME'

  constructor(private house: HouseSystem, private audio: HouseAudio) {}

  get dread(): DreadState {
    return this.state
  }

  /** A sudden realisation: stress jumps and the house goes quiet for a moment. */
  shock(amount: number) {
    this.stress = Math.min(1, this.stress + amount)
    this.silence = Math.max(this.silence, 3.2)
  }

  reset() {
    this.stress = 0
    this.pulse = 0
    this.tremorYaw = 0
    this.tremorPitch = 0
    this.ambient = 1
    this.ambientTarget = 1
    this.silence = 0
    this.silenceCooldown = 50
    this.beatTimer = 0
    this.breathTimer = 0
    this.entityBreathTimer = 7
    this.tinnitus = 0
    this.state = 'CALME'
    this.audio.setAmbient(1)
    this.audio.setTone(0)
    this.audio.setDread(0)
  }

  tick(s: AtmosphereSample) {
    const dt = THREE.MathUtils.clamp(s.dt, 0, 0.1)
    if (dt <= 0) return
    this.time += dt

    // Target stress: darkness, proximity, being seen, sprinting, open anomalies,
    // a dying torch and a silent house all add to what the body feels.
    const dark = !s.roomLit && !s.torchOn
    let target = 0.05 + s.progress * 0.2
    if (dark) target += 0.13
    if (s.entityActive) {
      const near = THREE.MathUtils.clamp((13 - s.entityDistance) / 13, 0, 1)
      target += near * 0.3
      if (s.entitySeen) target += 0.3
    }
    target += Math.min(0.14, s.openAnomalies * 0.035)
    if (s.running) target += 0.07
    if (s.cameraActive) target += 0.05
    if (s.batteryLow) target += 0.05
    if (this.silence > 0) target += 0.05
    target += Math.sin(this.time / 37) * 0.025
    target = THREE.MathUtils.clamp(target * s.intensity, 0, 1)
    const rate = target > this.stress ? 0.85 : 0.22
    this.stress += (target - this.stress) * (1 - Math.exp(-dt * rate))
    this.state = dreadFor(this.stress)
    this.audio.setDread(this.stress)

    // Heartbeat: audible inside the head, not positioned in the house.
    const bpm = 60 + this.stress * 84 + (s.running ? 12 : 0)
    this.heartRate = bpm
    if (this.stress > 0.2) {
      this.beatTimer -= dt
      if (this.beatTimer <= 0) {
        this.beatTimer = 60 / bpm
        this.pulse = 1
        this.audio.heartbeat(THREE.MathUtils.clamp((this.stress - 0.18) * 1.1, 0.06, 0.6))
      }
    } else this.beatTimer = 0
    this.pulse = Math.max(0, this.pulse - dt * 3.2)

    // Breathing becomes audible and quicker as stress grows.
    if (this.stress > 0.3) {
      this.breathTimer -= dt
      if (this.breathTimer <= 0) {
        this.breathTimer = 60 / (14 + this.stress * 14)
        this.audio.play('breath', undefined, 0.04 + this.stress * 0.12)
      }
    }

    // Hand and body tremor. Small by design: it should be felt, not seen as a bug.
    const amp = this.stress * this.stress * 0.0026 * (s.cameraActive ? 0.4 : 1)
    this.tremorYaw = (Math.sin(this.time * 17.3) * 0.6 + Math.sin(this.time * 31.1 + 1.7) * 0.4) * amp
    this.tremorPitch = (Math.sin(this.time * 14.7 + 0.6) * 0.5 + Math.sin(this.time * 27.9) * 0.5) * amp * 0.8

    // Dynamic silence: the house goes quiet, then answers from elsewhere.
    if (this.silence > 0) {
      this.silence -= dt
      this.ambientTarget = 0
      if (this.silence <= 0) {
        this.ambientTarget = 1
        this.answerFromElsewhere(s)
      }
    } else {
      this.silenceCooldown -= dt * (0.5 + this.stress)
      if (this.silenceCooldown <= 0) {
        this.silenceCooldown = (42 + Math.random() * 60) / s.intensity
        if (this.stress > 0.3 && !s.cameraActive && Math.random() < 0.7) this.silence = 4 + Math.random() * 6
      }
    }
    this.ambient += (this.ambientTarget - this.ambient) * (1 - Math.exp(-dt * (this.ambientTarget < this.ambient ? 5 : 0.9)))
    this.audio.setAmbient(this.ambient)

    // Tinnitus: a very quiet high tone that appears only under strong stress.
    const toneTarget = THREE.MathUtils.clamp((this.stress - 0.55) * 0.5, 0, 1) * 0.011
    this.tinnitus += (toneTarget - this.tinnitus) * (1 - Math.exp(-dt * 0.8))
    this.audio.setTone(this.tinnitus)

    // Something breathing close by, behind a wall or a door, unseen.
    if (s.entityActive && s.entityDistance < 7 && !s.entitySeen) {
      this.entityBreathTimer -= dt
      if (this.entityBreathTimer <= 0) {
        this.entityBreathTimer = 6 + Math.random() * 6
        this.audio.play('breath', s.entityPos, 0.26)
      }
    }

    this.loopClock -= dt
    if (this.loopClock <= 0) {
      this.loopClock = 0.3
      this.audio.updateLoops()
    }
  }

  private answerFromElsewhere(s: AtmosphereSample) {
    const far = this.house.rooms.filter((r) => r.center.distanceTo(s.playerPos) > 6)
    if (!far.length) return
    const room = far[Math.floor(Math.random() * far.length)]
    const kinds: SoundKind[] = ['door', 'creak', 'pipe', 'knock', 'thud', 'scrape']
    const kind = kinds[Math.floor(Math.random() * kinds.length)]
    this.audio.play(kind, room.center.clone().add(new THREE.Vector3(0, 0.8, 0)), 0.3 + s.intensity * 0.06)
  }
}
