import * as THREE from 'three'
import { buildWorld, type World } from './world'
import { HouseSystem } from './house'
import { PlayerSystem } from './player'
import { LightingSystem } from './lighting'
import { HouseAudio, type SoundKind } from './audio'
import { DoorSystem } from './doors'
import { CameraSystem } from './cameras'
import { EntitySystem, CHASE_SECONDS } from './entity'
import { EscapeSystem, type EscapeSave } from './escape'
import { AnomalySystem, type AnomalyCategory, type SavedAnomaly } from './anomalies'
import { EventDirector } from './director'
import { NightSystem, PHASES, ENTITY_START, type JournalEntry, type NightSave } from './night'
import { InteractionSystem, type InteractionTarget } from './interactions'
import { loadSettings, readStorage, writeStorage, type Settings } from './settings'
import { drawHousePlan } from './map'
import { checkHouse, type HouseCheck } from './checks'
import { Atmosphere, type AtmosphereSample, type DreadState } from './atmosphere'
import { PostFX, type FxTier } from './post'
import { Dust } from './dust'
import { Viewmodel } from './viewmodel'
import { Mirrors } from './mirrors'
import { Weather } from './weather'

/** Length of the kill, in seconds: lunge, grab, lift, bite, black. */
const DEATH_SECONDS = 7.6
type DeathPose = ReturnType<EntitySystem['deathFrame']>

// Room acoustics: [pattern, wet level, brightness of the tail in Hz]. Big hard volumes ring
// long and dull, tiled rooms are short and bright, furnished rooms swallow the sound.
const REVERB: [RegExp, number, number][] = [
  [/Garage|Escalier sous-sol/, 0.36, 2600],
  [/Sous-sol|Local technique/, 0.42, 2200],
  [/Salle de bain|WC|Buanderie/, 0.3, 5200],
  [/Hall|Couloir|Cuisine/, 0.22, 3600],
  [/Salon|Dressing/, 0.12, 2600],
  [/Chambre|Suite/, 0.1, 2200],
]

export type GameMode = 'menu' | 'playing' | 'paused' | 'survived' | 'lost'
export type GamePanel = 'none' | 'camera' | 'report' | 'journal' | 'plan' | 'settings' | 'letter' | 'help' | 'keypad' | 'note'
export interface Photo { id: number; room: string; time: string; url: string }
export interface HudState {
  mode: GameMode; panel: GamePanel; time: string; progress: number; phase: string
  room: string; roomId: string; level: number; battery: number; stamina: number
  flashlight: boolean; crouched: boolean; power: boolean; prompt: string | null; hold: number
  reports: number; visited: number; roomsTotal: number; objective: string; hint: string | null
  fps: number; dragMode: boolean; hasSave: boolean; journal: JournalEntry[]; photos: Photo[]
  stress: number; dread: DreadState; heartRate: number
  inventory: { id: string; label: string }[]; bullets: number; hasGun: boolean; escapeLine: string | null; code: string | null
  chase: number; chasing: boolean; glitch: number; dying: boolean; fx: boolean; ending: 'dawn' | 'escaped' | 'chase' | 'caught'
  camera: { index: number; id: number; name: string; roomId: string; ir: boolean; offline: boolean; glitch: boolean; down: boolean[]; signal: number; transition: boolean; zoom: number } | null
}
interface SavedGame {
  version: 2; signature: string; night: NightSave
  player: { position: number[]; yaw: number; pitch: number; battery: number; stamina: number; distance: number; flashlight?: boolean; crouched?: boolean }
  doors: { open: boolean; t: number; ajar?: number }[]; lights: [string, boolean][]; power: boolean; visited: string[]
  anomalies: SavedAnomaly[]; entity: ReturnType<EntitySystem['save']>; director: ReturnType<EventDirector['save']>; photos: Photo[]; corruption?: number
  escape?: EscapeSave
}
const SAVE_KEY = 'la-maison-night-v2'
export const INITIAL_HUD: HudState = {
  mode: 'menu', panel: 'none', time: '22:00', progress: 0, phase: 'Les habitudes', room: 'Salon', roomId: '', level: 0,
  battery: 100, stamina: 100, flashlight: true, crouched: false, power: true, prompt: null, hold: 0, reports: 0, visited: 0, roomsTotal: 13,
  objective: 'Apprenez la maison avant 23:00.', hint: null, fps: 0, dragMode: false, hasSave: false, journal: [], photos: [], camera: null,
  stress: 0, dread: 'CALME', heartRate: 62,
  inventory: [], bullets: 0, hasGun: false, escapeLine: null, code: null, chase: 0, chasing: false, glitch: 0, dying: false, fx: false, ending: 'dawn',
}

export class Game {
  renderer: THREE.WebGLRenderer
  scene = new THREE.Scene()
  camera = new THREE.PerspectiveCamera(70, 1, 0.055, 110)
  world!: World
  house!: HouseSystem
  player!: PlayerSystem
  lights!: LightingSystem
  audio!: HouseAudio
  doors!: DoorSystem
  cameras!: CameraSystem
  entity!: EntitySystem
  anomalies!: AnomalySystem
  director!: EventDirector
  night = new NightSystem()
  interactions!: InteractionSystem
  atmosphere!: Atmosphere
  post?: PostFX
  dust!: Dust
  viewmodel!: Viewmodel
  mirrors!: Mirrors
  weather!: Weather
  escape!: EscapeSystem
  checks: HouseCheck[] = []
  initialized = false
  private initializing: Promise<void> | null = null
  settings: Settings = loadSettings()
  mode: GameMode = 'menu'
  panel: GamePanel = 'none'
  photos: Photo[] = []
  dragMode = false
  private dragging = false
  private lastPointer = { x: 0, y: 0 }
  private lockTransition = 0
  private raf = 0
  private last = performance.now()
  private hudTimer = 0
  private saveTimer = 0
  private shadowTimer = 0
  private fps = 60
  private frameCount = 0
  private frameTime = 0
  private elapsed = 0
  private disposed = false
  private resizeObserver: ResizeObserver
  private hint: string | null = null
  private hintUntil = 0
  private target: InteractionTarget | null = null
  private held: InteractionTarget | null = null
  private holdProgress = 0
  private reportFromCamera = false
  private remotePlayers = new Map<string, THREE.Group>()
  private resumeAfterPanel = false
  private torchBeforeCamera = false
  private photoRequested = false
  private saved: SavedGame | null = null
  private frameBudget = 0
  private caught = 0
  private echoCooldown = 20
  private feedWasDown = false
  private glitch = 0
  private entityWoke = false
  private deathPose: DeathPose | null = null
  private deathEye = new THREE.Vector3()
  private deathCues = new Set<string>()
  private deathSilence = false
  private glitchLeft = 0
  private kick = 0
  private ending: 'dawn' | 'escaped' | 'chase' | 'caught' = 'dawn'
  private fxHidden: THREE.Object3D[] = []
  private eyeAdapt = 1
  private darkness = 0.5
  private dustTimer = 0
  private retract = 0
  private retractTarget = 0
  private retractTimer = 0
  private reverbRoom = ''
  private readonly tmpDir = new THREE.Vector3()
  private stepsInRow = 0

  constructor(private container: HTMLElement, private events: { onHud: (state: HudState) => void }) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(this.pixelRatioFor())
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping
    this.renderer.toneMappingExposure = this.settings.brightness
    this.renderer.shadowMap.enabled = true
    this.renderer.shadowMap.type = THREE.PCFShadowMap
    this.renderer.outputColorSpace = THREE.SRGBColorSpace
    this.renderer.domElement.setAttribute('aria-label', 'La maison, scène de jeu en trois dimensions')
    this.renderer.domElement.tabIndex = -1
    container.appendChild(this.renderer.domElement)
    this.camera.rotation.order = 'YXZ'
    this.scene.add(this.camera)
    this.resizeObserver = new ResizeObserver(this.resize)
    this.resizeObserver.observe(container)
    this.resize()
    window.addEventListener('keydown', this.onKeyDown)
    window.addEventListener('keyup', this.onKeyUp)
    window.addEventListener('blur', this.onBlur)
    window.addEventListener('beforeunload', this.beforeUnload)
    document.addEventListener('visibilitychange', this.visibility)
    document.addEventListener('pointerlockchange', this.onLockChange)
    document.addEventListener('pointerlockerror', this.onLockError)
    document.addEventListener('mousemove', this.onMouseMove)
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown)
    window.addEventListener('pointerup', this.onPointerUp)
    this.renderer.domElement.addEventListener('pointermove', this.onPointerMove)
    this.renderer.domElement.addEventListener('wheel', this.onWheel, { passive: false })
  }

  initialize(onProgress?: (progress: number, label: string) => void | Promise<void>) {
    if (this.initialized) return Promise.resolve()
    if (this.initializing) return this.initializing
    this.initializing = (async () => {
      const progress = async (value: number, label: string) => {
        if (onProgress) await onProgress(value, label)
        await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()))
      }
      await progress(3, 'Initialisation du rendu')
      this.world = await buildWorld(async (value, label) => progress(3 + value * 0.72, label))
      if (this.disposed) return
      this.scene.add(this.world.root)
      this.prepareTextureQuality()
      await progress(78, 'Analyse des pièces et des passages')
      this.house = new HouseSystem(this.world)
      this.checks = checkHouse(this.house)
      const warnings = this.checks.filter((check) => !check.passed)
      if (warnings.length) console.warn('House geometry diagnostics:', warnings)
      this.player = new PlayerSystem(this.house)
      this.audio = new HouseAudio(this.house)
      this.audio.setVolume(this.settings.volume)
      this.doors = new DoorSystem(this.world, this.audio)
      await progress(84, 'Éclairage et ombres')
      this.lights = new LightingSystem(this.scene, this.renderer, this.camera, this.house)
      this.cameras = new CameraSystem(this.scene, this.renderer, this.house, this.night)
      this.entity = new EntitySystem(this.scene, this.house, this.player, this.lights, this.doors, this.audio, this.night)
      this.camera.add(this.entity.grabGroup)
      this.anomalies = new AnomalySystem(this.house, this.night, this.lights, this.audio, this.entity)
      this.atmosphere = new Atmosphere(this.house, this.audio)
      this.director = new EventDirector(this.house, this.player, this.night, this.anomalies, this.entity, this.lights, this.audio, this.atmosphere)
      this.interactions = new InteractionSystem(this.house, this.lights, this.scene)
      this.escape = new EscapeSystem(this.scene)
      this.interactions.targets.push(...this.escape.targets)
      this.escape.reset(() => this.night.random())
      await progress(87, 'Poussière, miroirs et météo')
      this.dust = new Dust()
      this.scene.add(this.dust.points)
      this.viewmodel = new Viewmodel(this.camera)
      this.mirrors = new Mirrors()
      this.mirrors.enabled = this.settings.quality === 'ultra'
      this.scene.add(this.mirrors.group)
      this.weather = new Weather(this.lights, this.audio)
      this.fxHidden = [this.dust.points, this.viewmodel.group, this.mirrors.group]
      this.scene.traverse((o) => {
        if (o instanceof THREE.Mesh && !(o as THREE.Mesh & { isReflector?: boolean }).isReflector && (o.material as THREE.Material).transparent) this.fxHidden.push(o)
      })
      this.post = new PostFX(this.renderer, this.scene, this.camera, () => this.fxHidden)
      this.post.setTier(this.tierFor())
      this.dust.setPixelRatio(this.renderer.getPixelRatio())
      const saved = readStorage<SavedGame>(SAVE_KEY)
      if (saved && saved.version === 2 && saved.signature === this.house.architectureSignature && Number.isFinite(saved.night?.elapsed) && saved.night.elapsed < saved.night.duration && Array.isArray(saved.player?.position) && saved.player.position.length === 3 && saved.player.position.every(Number.isFinite) && Array.isArray(saved.doors) && Array.isArray(saved.lights) && Array.isArray(saved.anomalies) && Array.isArray(saved.visited) && Array.isArray(saved.night.entries) && saved.entity && saved.director) this.saved = saved
      await progress(89, 'Préparation de la première image')
      this.updateCamera(0)
      this.lights.tick(0, this.player, false, true, 0, this.settings.reducedEffects)
      this.initialized = true
      this.pushHud()
      this.last = performance.now()
      this.raf = requestAnimationFrame(this.loop)
    })()
    return this.initializing
  }

  private prepareTextureQuality() {
    const max = Math.min(16, this.renderer.capabilities.getMaxAnisotropy())
    const seen = new Set<THREE.Texture>()
    this.scene.traverse((object) => {
      if (!(object instanceof THREE.Mesh)) return
      for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
        for (const value of Object.values(material)) {
          if (value instanceof THREE.Texture && !seen.has(value)) {
            seen.add(value)
            value.anisotropy = max
            value.needsUpdate = true
          }
        }
      }
    })
  }

  beginDirect() {
    if (!this.initialized) return
    if (this.saved && this.night.status !== 'active') this.restore(this.saved)
    if (this.night.status === 'active') {
      this.mode = 'playing'
      this.panel = 'none'
      this.reportFromCamera = false
      this.player.clear()
      this.audio.setPaused(false)
      this.pushHud()
    } else this.startNew()
  }

  async prewarm(onProgress?: (progress: number, label: string) => void | Promise<void>) {
    if (!this.initialized) return
    this.updateCamera(0)
    this.lights.tick(0, this.player, this.cameraActive, this.mode === 'menu', 0, this.settings.reducedEffects)
    this.lights.invalidateShadows()
    this.renderer.compile(this.scene, this.camera)
    for (let frame = 0; frame < 7; frame++) {
      this.lights.invalidateShadows()
      this.renderFrame(0.016)
      if (onProgress) await onProgress(91 + frame, 'Chargement des ombres et des reflets')
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()))
      if (this.disposed) return
    }
    if (onProgress) await onProgress(99, 'La maison est prête')
  }

  get cameraActive() { return this.panel === 'camera' || this.panel === 'report' && this.reportFromCamera }
  get hasSave() { return !!this.saved || this.night.status === 'active' }
  private pixelRatioFor() {
    const dpr = window.devicePixelRatio || 1
    return Math.min(dpr, this.settings.quality === 'ultra' ? 1.5 : this.settings.quality === 'high' ? 1.8 : 1.25)
  }
  private tierFor(): FxTier { return this.settings.quality === 'ultra' ? 'ultra' : 'standard' }

  private resize = () => {
    const width = this.container.clientWidth || window.innerWidth, height = this.container.clientHeight || window.innerHeight
    this.renderer.setSize(width, height); this.camera.aspect = width / height; this.camera.updateProjectionMatrix()
    this.post?.setSize(width, height, this.renderer.getPixelRatio())
    this.dust?.setPixelRatio(this.renderer.getPixelRatio())
  }

  setSettings(patch: Partial<Settings>) {
    this.settings = { ...this.settings, ...patch }
    writeStorage('la-maison-settings-v1', this.settings)
    this.renderer.toneMappingExposure = this.settings.brightness
    this.renderer.setPixelRatio(this.pixelRatioFor())
    this.post?.setTier(this.tierFor())
    if (this.mirrors) this.mirrors.enabled = this.settings.quality === 'ultra'
    if (this.initialized) this.audio.setVolume(this.settings.volume)
    this.resize()
  }

  startNew() {
    this.panel = 'none'; this.reportFromCamera = false; this.resumeAfterPanel = false
    this.anomalies.reset(); this.doors.reset(); this.lights.reset(); this.player.reset(); this.entity.reset(); this.cameras.reset(); this.director.reset(); this.atmosphere.reset(); this.weather.reset()
    this.photos = []; this.held = null; this.holdProgress = 0; this.caught = 0; this.echoCooldown = 20; this.stepsInRow = 0
    this.house.rooms.forEach((r) => { r.visited = false })
    this.night.reset(this.settings.duration); this.mode = 'playing'
    this.escape.reset(() => this.night.random())
    this.glitch = 0; this.glitchLeft = 0; this.kick = 0; this.ending = 'dawn'; this.entityWoke = false
    this.player.freeSprint = false; this.audio.setGlitch(0)
    this.resetDeathFx()
    this.scene.background = new THREE.Color(0x070b10)
    void this.audio.unlock(); this.audio.setPaused(false); this.captureMouse()
    this.notify('22:00. Faites une première ronde. La lettre est sur la console du hall.', 7)
    this.save()
  }

  resume() {
    if (this.night.status !== 'active') {
      if (!this.saved) { this.startNew(); return }
      this.restore(this.saved)
    }
    this.mode = 'playing'; this.panel = 'none'; this.reportFromCamera = false
    this.player.clear(); void this.audio.unlock(); this.audio.setPaused(false); this.captureMouse(); this.pushHud()
  }

  pause() {
    if (this.mode !== 'playing') return
    if (this.cameraActive) this.player.flashlight = this.torchBeforeCamera && this.player.battery > 0
    this.mode = 'paused'; this.panel = 'none'; this.reportFromCamera = false
    this.player.clear(); this.held = null; this.holdProgress = 0
    this.audio.setPaused(true); this.releaseMouse(); this.save(); this.pushHud()
  }

  openPanel(panel: GamePanel) {
    if (panel === 'camera') { this.enterCamera(); return }
    if (panel === 'report') {
      if (this.mode !== 'playing') return
      this.reportFromCamera = this.cameraActive; this.panel = panel; this.player.clear(); this.releaseMouse(); this.pushHud(); return
    }
    this.resumeAfterPanel = this.mode === 'playing'
    if (this.mode === 'playing') this.pause()
    this.panel = panel; this.releaseMouse(); this.pushHud()
  }

  closePanel() {
    if (this.panel === 'camera') { this.exitCamera(); return }
    if (this.panel === 'report') {
      this.panel = this.reportFromCamera ? 'camera' : 'none'; this.reportFromCamera = false
      if (this.panel === 'none') this.captureMouse()
    } else {
      this.panel = 'none'
      if (this.resumeAfterPanel) { this.resumeAfterPanel = false; this.resume() }
    }
    this.pushHud()
  }

  enterCamera(index?: number) {
    if (this.mode === 'paused') { this.mode = 'playing'; this.audio.setPaused(false) }
    if (this.mode === 'playing' && this.player.battery <= 0 && !this.nearMonitor()) { this.notify('La tablette est déchargée. Utilisez un terminal mural ou le chargeur.'); return }
    if (!this.cameraActive) { this.torchBeforeCamera = this.player.flashlight; this.player.flashlight = false }
    if (index !== undefined) this.cameras.select(index)
    else this.cameras.transition = 0.25
    this.panel = 'camera'; this.reportFromCamera = false; this.player.clear(); this.releaseMouse()
    this.audio.play('static', undefined, 0.16); this.pushHud()
  }

  selectCamera(index: number) {
    this.cameras.select(index); this.audio.play('static', undefined, 0.13); this.lights.invalidateShadows(); this.pushHud()
  }
  exitCamera() {
    this.panel = 'none'; this.reportFromCamera = false; this.player.flashlight = this.torchBeforeCamera && this.player.battery > 0
    this.player.clear(); if (this.mode === 'playing') this.captureMouse(); this.pushHud()
  }
  zoomCamera(direction: number) { this.cameras.zoom = THREE.MathUtils.clamp(this.cameras.zoom + direction * 8, 0, 42); this.pushHud() }
  panCamera(x: number, y: number) { this.cameras.move(x, y) }

  report(room: string, category: AnomalyCategory) {
    if (this.mode !== 'playing' || this.caught > 0 || this.entity.chasing || !this.house.rooms.some((r) => r.id === room)) return
    const result = this.anomalies.report(room, category)
    if (!result.pending) this.director.report(result.accepted)
    this.notify(result.message, 5); this.closePanel(); this.save()
  }

  /** Digicode on the front door. Returns whether the code was right. */
  tryCode(code: string) {
    if (this.escape.checkCode(code)) {
      this.audio.play('key', undefined, 0.5)
      this.night.log('Digicode de la porte déverrouillé.', 'report')
      this.notify('Code accepté. Le digicode passe au vert.', 4)
      this.closePanel()
      return true
    }
    this.audio.play('thud', undefined, 0.3)
    this.notify('Code erroné.', 2)
    return false
  }

  /** One of three cartridges. A hit makes the current manifestation vanish without erasing encounter history. */
  shoot() {
    if (this.mode !== 'playing' || this.panel !== 'none' || this.caught > 0 || !this.escape.hasGun) return
    if (!this.escape.fire()) { this.audio.play('click', undefined, 0.4); this.notify('Plus de cartouches.', 2.5); return }
    this.audio.play('gunshot', undefined, 0.95)
    this.lights.muzzle = 1
    this.kick = 1
    this.player.pitch = Math.min(1.35, this.player.pitch + 0.05)
    const origin = this.camera.position.clone()
    const dir = this.camera.getWorldDirection(new THREE.Vector3())
    const hit = this.entity.rayHit(origin, dir, 40)
    if (hit && this.house.occlusion(origin, hit.point, false) === 0) {
      this.entity.shot()
      this.player.freeSprint = false
      this.atmosphere.shock(0.3)
      this.glitchLeft = 0
      this.night.log('Un coup au but. Il a disparu. Votre historique de rencontres reste enregistré.', 'report')
      this.notify('Touché. Il a disparu... pour l’instant.', 5)
    } else {
      this.entity.disturb(this.player.position)
      const n = this.escape.bullets
      this.notify(n > 0 ? `Raté. Il reste ${n} cartouche${n > 1 ? 's' : ''}.` : 'Raté. Plus aucune cartouche.', 3)
    }
    this.save()
  }

  photograph() {
    if (this.mode !== 'playing') return
    if (this.cameraActive && this.cameras.offline > 0) { this.notify('Le signal est trop faible pour prendre une image.'); return }
    this.photoRequested = true
  }
  toggleFlashlight() {
    if (this.mode !== 'playing' || this.cameraActive) return
    if (this.player.battery <= 0) { this.notify('Batterie vide. Le chargeur se trouve dans la buanderie.'); return }
    this.player.flashlight = !this.player.flashlight; this.audio.play('click', undefined, 0.28); this.pushHud()
  }

  interact() {
    if (this.mode !== 'playing' || this.panel !== 'none') return
    const t = this.interactions.pick(this.player.eyePosition(), this.camera.getWorldDirection(new THREE.Vector3()))
    if (!t) return
    switch (t.kind) {
      case 'door':
        if (t.door!.locked) { this.notify('Verrouillée pour la nuit. La relève arrive à 06:00.'); return }
        this.anomalies.doorTouched(t.door!); this.doors.set(t.door!, !t.door!.open); break
      case 'switch':
        this.lights.toggle(t.roomId!); this.audio.play('click', t.position, 0.35)
        if (!this.lights.power) this.notify('Aucun courant. Le disjoncteur est dans le local technique.')
        break
      case 'monitor': this.enterCamera(); break
      case 'letter': this.openPanel('letter'); break
      case 'charger':
        if (!this.lights.power) { this.notify('Le chargeur n’est plus alimenté. Réarmez le disjoncteur.'); return }
        if (this.player.battery > 99) { this.notify('La batterie est déjà pleine.'); return }
        this.held = t; this.holdProgress = 0; break
      case 'breaker':
        if (this.lights.power) { this.notify('Le circuit fonctionne normalement.'); return }
        this.held = t; this.holdProgress = 0; break
      case 'escape': {
        const r = this.escape.use(t)
        if (r.sound) this.audio.play(r.sound, t.position, 0.5)
        if (r.also) this.audio.play(r.also, t.position, 0.45)
        if (r.log) this.night.log(r.log, 'note')
        if (r.msg) this.notify(r.msg, r.long ? 6 : 3.5)
        if (r.hold) { this.held = t; this.holdProgress = 0 }
        if (r.panel) this.openPanel(r.panel)
        if (r.exit) this.finish(true, 'escaped')
        break
      }
      case 'object': this.notify(`${t.label}. ${this.house.roomForPoint(t.position)?.purpose ?? 'Observez sa position. Si elle a changé, signalez-la avec R.'}`, 6); break
    }
  }

  setKey(code: string, down: boolean) {
    if (down) { this.player.keys.add(code); if (code === 'KeyE') this.interact() }
    else { this.player.keys.delete(code); if (code === 'KeyE') { this.held = null; this.holdProgress = 0 } }
  }
  toggleCrouch() { this.player.crouched = !this.player.crouched; this.pushHud() }
  private nearMonitor() { return this.world.monitors.some((m) => this.player.eyePosition().distanceTo(new THREE.Vector3(m.x, m.y, m.z)) < 2) }

  private captureMouse() {
    if (this.mode !== 'playing' || this.panel !== 'none') return
    this.renderer.domElement.focus({ preventScroll: true })
    if (window.matchMedia('(pointer: coarse)').matches) { this.dragMode = true; return }
    const canvas = this.renderer.domElement
    this.lockTransition = performance.now() + 400
    if (!canvas.requestPointerLock) { this.dragMode = true; return }
    try {
      const promise = canvas.requestPointerLock() as unknown as Promise<void> | undefined
      promise?.catch(() => { this.dragMode = true; this.pushHud() })
    } catch { this.dragMode = true }
  }
  private releaseMouse() {
    this.lockTransition = performance.now() + 300
    if (document.pointerLockElement === this.renderer.domElement) document.exitPointerLock()
  }
  private onLockChange = () => {
    if (this.disposed) return
    if (document.pointerLockElement === this.renderer.domElement) { this.dragMode = false; return }
    if (performance.now() < this.lockTransition || this.panel !== 'none') return
    if (this.mode === 'playing' && !this.dragMode) this.pause()
  }
  private onLockError = () => { this.dragMode = true }
  private onBlur = () => { if (!this.initialized) return; this.player.clear(); if (this.mode === 'playing') this.pause() }
  private visibility = () => { if (document.hidden) this.onBlur() }
  private beforeUnload = () => this.save()
  private onMouseMove = (e: MouseEvent) => {
    if (this.mode === 'playing' && this.panel === 'none' && document.pointerLockElement === this.renderer.domElement) this.player.look(e.movementX, e.movementY, this.settings.sensitivity / 1000)
  }
  private onPointerDown = (e: PointerEvent) => {
    if (!this.initialized || this.mode !== 'playing' || this.panel !== 'none') return
    void this.audio.unlock()
    this.dragging = true; this.lastPointer = { x: e.clientX, y: e.clientY }
    if (e.button === 0 && document.pointerLockElement === this.renderer.domElement) this.shoot()
    else if (!this.dragMode && document.pointerLockElement !== this.renderer.domElement) this.captureMouse()
  }
  private onPointerMove = (e: PointerEvent) => {
    if (!this.dragging || this.mode !== 'playing' || this.panel !== 'none' || document.pointerLockElement) return
    this.player.look(e.clientX - this.lastPointer.x, e.clientY - this.lastPointer.y, this.settings.sensitivity / 1000 * (e.pointerType === 'touch' ? 1.7 : 1))
    this.lastPointer = { x: e.clientX, y: e.clientY }
  }
  private onPointerUp = () => { this.dragging = false }
  private onWheel = (e: WheelEvent) => { if (this.cameraActive) { e.preventDefault(); this.zoomCamera(e.deltaY < 0 ? 1 : -1) } }

  private onKeyDown = (e: KeyboardEvent) => {
    if ((e.target as HTMLElement)?.matches('input, select, textarea')) return
    if ((e.target as HTMLElement)?.matches('button') && (e.code === 'Space' || e.code === 'Enter')) return
    if (e.code === 'Escape') { e.preventDefault(); if (this.panel !== 'none') this.closePanel(); else if (this.mode === 'playing') this.pause(); return }
    if (this.mode !== 'playing' && !(this.mode === 'menu' && this.cameraActive)) return
    if (this.panel !== 'none' && this.panel !== 'camera') return
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code) || /^Key[WASDZQEFCVRJMNL]$/.test(e.code)) e.preventDefault()
    void this.audio.unlock()
    this.player.keys.add(e.code)
    if (e.repeat) return
    switch (e.code) {
      case 'KeyE': this.interact(); break
      case 'KeyG': this.shoot(); break
      case 'KeyF': this.toggleFlashlight(); break
      case 'KeyC': if (!this.cameraActive) this.toggleCrouch(); break
      case 'KeyV': if (this.cameraActive) this.exitCamera(); else this.enterCamera(); break
      case 'KeyR': this.openPanel('report'); break
      case 'KeyJ': this.openPanel('journal'); break
      case 'KeyM': this.openPanel('plan'); break
      case 'KeyN': this.photograph(); break
      case 'KeyL': {
        const t = this.interactions.pick(this.player.eyePosition(), this.camera.getWorldDirection(new THREE.Vector3()), 'switch')
        if (t) { this.lights.toggle(t.roomId!); this.audio.play('click', t.position, 0.3) }
        else this.notify('Approchez-vous d’un interrupteur pour changer l’éclairage.')
        break
      }
      case 'BracketLeft': case 'PageUp': if (this.cameraActive) this.selectCamera(this.cameras.selected - 1); break
      case 'BracketRight': case 'PageDown': if (this.cameraActive) this.selectCamera(this.cameras.selected + 1); break
      case 'Equal': case 'NumpadAdd': if (this.cameraActive) this.zoomCamera(1); break
      case 'Minus': case 'NumpadSubtract': if (this.cameraActive) this.zoomCamera(-1); break
    }
  }
  private onKeyUp = (e: KeyboardEvent) => this.setKey(e.code, false)

  private observed = (point: THREE.Vector3, furniture = false) => {
    if (this.cameraActive && this.cameras.offline > 0) return false
    const from = this.camera.position, delta = point.clone().sub(from), distance = delta.length()
    const roomLit = this.lights.isOn(this.house.roomAt(this.player.position)?.id)
    const range = this.cameraActive ? 16 : this.player.flashlight && this.player.battery > 0 ? 18 : roomLit ? 9.5 : 5.4
    if (distance > range || distance < 0.001) return false
    const alignment = delta.normalize().dot(this.camera.getWorldDirection(new THREE.Vector3()))
    const field = Math.cos(THREE.MathUtils.degToRad(this.camera.fov * 0.62))
    if (alignment < field) return false
    // Beyond the clearly readable band, a point must sit close to the centre of
    // view. Distant shapes can be glimpsed, but they are no longer identified.
    if (!this.cameraActive && distance > 7 && (!this.player.flashlight || this.player.battery <= 0) && alignment < 0.94) return false
    if (!this.cameraActive && distance > 10 && alignment < 0.9) return false
    return this.house.occlusion(from, point, furniture) === 0
  }

  private updateCamera(dt: number) {
    if (this.caught > 0 && this.deathPose) {
      const p = this.deathPose
      this.camera.position.copy(p.pos)
      this.camera.lookAt(p.look)
      this.camera.rotateZ(p.roll)
      const fov = this.settings.fov + p.fov
      if (Math.abs(this.camera.fov - fov) > 0.05) { this.camera.fov = fov; this.camera.updateProjectionMatrix() }
      this.camera.updateMatrixWorld()
      return
    }
    if (this.cameraActive) {
      this.cameras.orient(this.camera)
      if (this.panel === 'camera') {
        const k = this.player.keys
        const horizontal = Number(k.has('ArrowLeft') || k.has('KeyA') || k.has('KeyQ')) - Number(k.has('ArrowRight') || k.has('KeyD'))
        const vertical = Number(k.has('ArrowUp') || k.has('KeyW') || k.has('KeyZ')) - Number(k.has('ArrowDown') || k.has('KeyS'))
        if (horizontal || vertical) this.cameras.move(horizontal * dt * 0.45, vertical * dt * 0.3)
      }
    } else if (this.mode === 'menu') {
      const drift = this.settings.motion ? Math.sin(this.elapsed * 0.065) * 0.1 : 0
      this.camera.position.set(16.4 + drift, 1.6, 8.16); this.camera.lookAt(10.1, 1.42, 5.35)
      if (this.camera.fov !== 65) { this.camera.fov = 65; this.camera.updateProjectionMatrix() }
    } else {
      const pose = this.player.cameraPose(this.settings.motion)
      this.camera.position.copy(pose.position)
      this.camera.position.y -= this.atmosphere.pulse * 0.005 * this.settings.intensity
      const handheld = this.settings.motion && !this.settings.reducedEffects && this.mode === 'playing' ? 0.0011 : 0
      this.camera.rotation.set(
        pose.pitch + Math.sin(this.elapsed * 0.83) * handheld + this.atmosphere.tremorPitch,
        pose.yaw + Math.sin(this.elapsed * 0.61) * handheld + this.atmosphere.tremorYaw,
        pose.roll,
      )
      // Fear narrows the view: a few degrees less field of view at high stress.
      const targetFov = this.settings.fov + pose.fovKick - this.atmosphere.stress * 4.5 * this.settings.intensity
      if (Math.abs(this.camera.fov - targetFov) > 0.02) { this.camera.fov = targetFov; this.camera.updateProjectionMatrix() }
    }
    this.camera.updateMatrixWorld()
  }

  /** The three meetings: it looks, it looks while everything breaks, then it stares and hunts. */
  private handleEntityEvents() {
    for (const ev of this.entity.events.splice(0)) {
      if (ev.type === 'encounter') {
        const where = this.house.rooms.find((r) => r.id === ev.room)?.name.toLowerCase() ?? 'la maison'
        if (ev.strikes === 1) {
          this.night.log(`Quelqu'un se tenait immobile dans : ${where}. Il vous fixait${ev.viaCamera ? ' à travers l’écran' : ''}. À signaler.`, 'warning')
          this.notify(ev.viaCamera ? 'Il s’est arrêté. Il fixe la caméra.' : 'Il vous regarde. Il ne bouge pas.', 5)
          this.atmosphere.shock(0.35)
        } else if (ev.strikes === 2) {
          this.night.log('Il est revenu. L’image s’est déformée, les sons aussi. Signalez-le avant qu’il ne revienne.', 'warning')
          this.glitchLeft = 5.5
          this.audio.play('glitch', undefined, 0.55)
          this.atmosphere.shock(0.55)
        } else {
          this.night.log('Il ne bouge plus. Il vous fixe. Il va venir.', 'warning')
          this.atmosphere.shock(0.7)
        }
      } else if (ev.type === 'chaseStart') {
        this.player.freeSprint = true
        if (this.panel === 'report') this.closePanel()
        if (this.cameraActive) this.exitCamera()
        this.atmosphere.shock(0.9)
        this.night.log('Il court. Tenez dix secondes.', 'warning')
        this.notify('Courez !', 3)
      } else {
        this.finish(true, 'chase')
      }
    }
  }

  /** Everything breaks together: the picture tears, the colours turn, the sound distorts. */
  private updateGlitch(dt: number) {
    if (this.caught > 0) return
    let level = 0
    if (this.entity.chasing) level = Math.random() < 0.12 ? 0.75 : 0.28
    else if (this.entity.staring && this.entity.strikes >= 3) level = this.entity.stareProgress * 0.4 * (Math.random() < 0.3 ? 1 : 0.2)
    else if (this.glitchLeft > 0) {
      this.glitchLeft -= dt
      level = Math.min(1, this.glitchLeft / 1.2) * (0.65 + Math.random() * 0.35)
    }
    this.glitch = level
    this.audio.setGlitch(this.entity.chasing ? level * 0.7 : level)
  }

  /** Caught. The player cannot move: what follows is a fixed sequence, from the lunge to the black. */
  private beginCapture() {
    if (this.caught > 0) return
    this.caught = DEATH_SECONDS
    this.held = null
    this.holdProgress = 0
    this.panel = 'none'
    this.reportFromCamera = false
    this.deathCues.clear()
    this.deathSilence = false
    this.deathEye.copy(this.player.eyePosition())
    this.entity.beginDeath()
    this.atmosphere.shock(1)
    this.pushHud()
  }

  private caughtTick(dt: number) {
    this.caught -= dt
    const t = DEATH_SECONDS - this.caught
    const calm = this.settings.reducedEffects
    const pose = this.entity.deathFrame(dt, t, this.deathEye, calm)
    this.deathPose = pose
    const head = this.entity.headPoint()
    const cue = (id: string, at: number, fn: () => void) => {
      if (t >= at && !this.deathCues.has(id)) { this.deathCues.add(id); fn() }
    }
    const a = this.audio
    cue('roar', 0, () => { a.play('roar', undefined, 1); a.play('scream', head, 1); a.play('rasp', head, 0.9) })
    cue('grab', 0.5, () => { a.play('thud', undefined, 0.95); a.play('cry', undefined, 0.95) })
    cue('crack', 1.35, () => { a.play('creak', undefined, 0.9); a.play('crunch', undefined, 0.45) })
    cue('roar2', 1.9, () => { a.play('roar', undefined, 1); a.play('scream', head, 0.8) })
    cue('bite1', 3.5, () => {
      a.play('crunch', undefined, 1); a.play('squelch', undefined, 0.9); a.setMuffle(0.55)
      this.lights.power = false; this.player.flashlight = false
    })
    cue('bite2', 4.15, () => { a.play('crunch', undefined, 0.95); a.play('squelch', undefined, 0.7); a.setMuffle(0.85) })
    cue('silence', 4.5, () => { this.deathSilence = true; a.setAmbient(0); a.setPresence(0, head); a.setMuffle(0.9) })
    cue('bite3', 4.9, () => { a.play('crunch', undefined, 0.8); a.play('tear', undefined, 0.9); a.play('squelch', undefined, 0.6) })
    cue('bite4', 5.6, () => { a.play('crunch', undefined, 0.55); a.play('squelch', undefined, 0.5) })
    cue('drip', 6.5, () => { a.play('drip', undefined, 0.35) })
    // The lights die in stutters, the picture and the sound break; none of it when effects are reduced.
    if (t < 3.5 && !calm) this.lights.power = Math.random() > 0.3
    this.glitch = calm ? 0 : t < 0.9 ? 0.5 + Math.random() * 0.5 : t < 3.5 ? 0.2 + Math.random() * 0.45 : 0.12 * Math.random()
    a.setGlitch(calm ? 0 : this.glitch * 0.8)
    const root = this.container.parentElement
    root?.style.setProperty('--fade', pose.fade.toFixed(3))
    root?.style.setProperty('--blood', pose.blood.toFixed(3))
    if (this.caught <= 0) this.finish(false)
  }

  private resetDeathFx() {
    this.caught = 0
    this.deathPose = null
    this.deathSilence = false
    this.deathCues.clear()
    this.audio.setMuffle(0)
    if (this.entity) this.entity.grabGroup.visible = false
    const root = this.container.parentElement
    root?.style.setProperty('--fade', '0')
    root?.style.setProperty('--blood', '0')
  }

  /** Footsteps follow the floor under the player: tile, concrete, wood, and creaks on stairs. */
  private footstep(running: boolean) {
    const p = this.player.position
    const room = this.house.roomAt(p)?.name ?? ''
    const surface: SoundKind = /Salle de bain|WC|Buanderie/.test(room) ? 'stepTile' : /Garage|Sous-sol|Escalier sous-sol|Local technique/.test(room) ? 'stepConcrete' : 'step'
    const onStairs = this.world.surfaces.some((s) => s.fn && p.x >= s.x1 && p.x <= s.x2 && p.z >= s.z1 && p.z <= s.z2 && Math.abs(s.fn(p.x, p.z) - p.y) < 0.12)
    const at = p.clone().add(new THREE.Vector3(0, 0.08, 0))
    this.audio.play(surface, at, this.player.crouched ? 0.13 : running ? 0.66 : 0.38)
    if (onStairs && Math.random() < 0.55) this.audio.play('creak', at, (running ? 0.34 : 0.22) * this.settings.intensity)

    // Late and in the dark, something else walks a few metres behind you. It copies your
    // pace, and stops when you stop. Turn around and nobody is there.
    this.stepsInRow = Math.min(12, this.stepsInRow + 1)
    this.echoCooldown -= 0.7
    const dark = !this.lights.isOn(this.house.roomAt(p)?.id) && !this.player.flashlight
    if (this.stepsInRow > 4 && this.echoCooldown <= 0 && dark && this.night.phase >= 3 && this.atmosphere.stress > 0.3 && Math.random() < 0.25 * this.settings.intensity) {
      const back = new THREE.Vector3(Math.sin(this.player.yaw), 0, Math.cos(this.player.yaw))
      const spot = p.clone().addScaledVector(back, 3.4)
      if (!this.house.blocked(spot.x, spot.y, spot.z, 0.2, true) && this.house.roomAt(spot)) {
        this.echoCooldown = 28
        const count = 3 + Math.floor(Math.random() * 3)
        for (let i = 0; i < count; i++) {
          window.setTimeout(() => {
            if (this.mode === 'playing' && !this.disposed) this.audio.play(surface, spot.clone().add(new THREE.Vector3(0, 0.08, 0)), 0.3)
          }, 420 + i * 520)
        }
      }
    }
  }

  private atmosphereSample(dt: number): AtmosphereSample {
    const room = this.house.roomAt(this.player.position)
    const entityHead = this.entity.headPoint()
    return {
      dt,
      progress: this.night.progress,
      playerPos: this.player.position,
      roomLit: this.lights.isOn(room?.id),
      torchOn: this.player.flashlight && this.player.battery > 0,
      running: this.player.running,
      cameraActive: this.cameraActive,
      openAnomalies: this.anomalies.active.filter((a) => !a.acknowledged).length,
      batteryLow: this.player.battery < 16,
      entityActive: this.entity.state !== 'dormant',
      entityPos: entityHead,
      entityDistance: this.entity.position.distanceTo(this.player.position),
      entitySeen: this.entity.state !== 'dormant' && this.observed(entityHead, true),
      intensity: this.settings.intensity,
    }
  }

  private update(dt: number) {
    this.elapsed += dt
    if (this.hint && this.elapsed > this.hintUntil) this.hint = null
    if (this.mode === 'playing') {
      this.player.tick(dt, this.panel !== 'none' || !!this.held || this.caught > 0, (running) => {
        this.footstep(running)
        if (running) this.entity.disturb(this.player.position)
      }, this.settings.motion, (impact) => {
        this.audio.play('step', this.player.position.clone().add(new THREE.Vector3(0, 0.05, 0)), Math.min(0.85, 0.3 + impact * 0.1))
      })
      this.night.tick(dt)
      if (!this.entityWoke && this.night.progress >= ENTITY_START) {
        // 01:00. The house does not announce it: one low sound, one line in the notebook.
        this.entityWoke = true
        this.night.log('01:00. Le silence n’est plus le même.', 'warning')
        this.audio.play('impact', undefined, 0.45)
      }
      if (this.player.velocity.length() < 0.3) this.stepsInRow = 0
      const room = this.house.roomAt(this.player.position)
      if (room && !room.visited) { room.visited = true; this.night.log(`Première visite : ${room.name.toLowerCase()}.`) }
      if (this.cameraActive && !this.nearMonitor()) {
        this.player.battery = Math.max(0, this.player.battery - dt * 0.085)
        if (this.player.battery === 0) { this.exitCamera(); this.notify('La tablette est déchargée. Trouvez un terminal mural.') }
      }
      if (this.held) {
        if (!this.player.keys.has('KeyE') || this.player.eyePosition().distanceTo(this.held.position) > 2.15) { this.held = null; this.holdProgress = 0 }
        else {
          this.holdProgress += dt / (this.held.hold ?? 1)
          if (this.holdProgress >= 1) {
            if (this.held.kind === 'charger' && this.lights.power) { this.player.battery = 100; this.notify('Batterie rechargée.'); this.audio.play('click', this.held.position, 0.35) }
            if (this.held.kind === 'breaker') { this.lights.power = true; this.night.log('Le courant a été rétabli.', 'note'); this.notify('Le courant est rétabli.'); this.audio.play('click', this.held.position, 0.5) }
            if (this.held.kind === 'escape') {
              const r = this.escape.complete(this.held.escapeId ?? '')
              if (r.sound) this.audio.play(r.sound, this.held.position, 0.85)
              if (r.log) this.night.log(r.log, 'note')
              if (r.msg) this.notify(r.msg, 4)
            }
            this.held = null; this.holdProgress = 0
          }
        }
      }
      if (this.doors.tick(dt, this.player.position)) this.lights.invalidateShadows()
      this.updateCamera(dt); this.audio.update(this.player.eyePosition(), this.player.viewYaw)
      if (!this.deathSilence) this.atmosphere.tick(this.atmosphereSample(dt)); this.anomalies.tick(dt, this.observed); this.director.tick(dt, this.cameraActive, this.observed, this.settings.reducedEffects, this.settings.intensity)
      if (this.caught > 0) this.caughtTick(dt)
      else if (this.entity.tick(dt, this.director.tension, (p) => this.observed(p, true), { camera: this.cameraActive, at: this.cameraActive ? this.camera.position.clone() : null })) this.beginCapture()
      this.handleEntityEvents()
      this.escape.tick(dt, this.camera)
      this.updateGlitch(dt)
      this.audio.tick(dt)
      // Seeing it again after a long time is a shock: the house goes quiet, the body reacts.
      if (this.entity.consumeSight()) this.atmosphere.shock(0.2)
      if (this.night.status === 'survived') this.finish(true)
      this.shadowTimer -= dt
      if (this.shadowTimer <= 0) { this.shadowTimer = 0.2; this.lights.invalidateShadows() }
      this.saveTimer -= dt
      if (this.saveTimer <= 0) { this.saveTimer = 25; this.save() }
    } else this.updateCamera(dt)
    this.cameras.tick(this.mode === 'paused' ? 0 : dt, this.cameraActive, this.player.position, this.camera, this.entity.state !== 'dormant' ? this.entity.position : null)
    // A feed dying or coming back is audible, like a signal being cut.
    const feedDown = this.cameraActive && this.cameras.offline > 0
    if (feedDown !== this.feedWasDown) {
      this.feedWasDown = feedDown
      this.audio.play('static', undefined, feedDown ? 0.24 : 0.12)
    }
    const dawn = this.night.status === 'survived' ? 1 : Math.max(0, (this.night.progress - 0.97) / 0.03)
    this.lights.tick(dt, this.player, this.cameraActive, this.mode === 'menu', dawn, this.settings.reducedEffects)
    this.updateRealism(dt)
  }

  /** Everything that makes the image and the air behave like real life rather than a render. */
  private updateRealism(dt: number) {
    const playing = this.mode === 'playing'
    const feed = this.cameraActive
    const room = this.house.roomAt(this.player.position)
    const roomLit = this.lights.isOn(room?.id)
    const torchOn = this.player.flashlight && this.player.battery > 0 && !feed

    // The eye adapts: slowly toward the dark, quickly back to the light. Cameras keep a fixed exposure.
    const target = this.mode === 'menu' ? 1 : torchOn ? 1.1 : roomLit ? 1 : 1.4
    this.eyeAdapt += (target - this.eyeAdapt) * Math.min(1, dt * (target < this.eyeAdapt ? 1.4 : 0.07))
    this.darkness += ((roomLit || torchOn ? 0.12 : 1) - this.darkness) * Math.min(1, dt * 1.2)
    this.renderer.toneMappingExposure = this.settings.brightness * (feed ? 1 : this.eyeAdapt)

    // Dust: always in the air, visible only where light reaches.
    this.dustTimer -= dt
    if (this.dustTimer <= 0) {
      this.dustTimer = 0.4
      this.dust.setLamps(this.lights.litSources(this.player.position.clone().setY(this.player.position.y + 1.5), 5, 4))
    }
    this.dust.points.visible = playing && !feed
    if (this.dust.points.visible) this.dust.update(dt, this.camera, { on: torchOn, power: 1.1, angle: 0.37 })

    // The torch in hand is pulled back when a wall is too close, as a real arm would.
    this.retractTimer -= dt
    if (this.retractTimer <= 0 && playing && !feed) {
      this.retractTimer = 0.06
      const eye = this.camera.position
      this.camera.getWorldDirection(this.tmpDir)
      let r = 0
      for (const [d, v] of [[0.6, 0.3], [0.44, 0.65], [0.3, 1]] as const) {
        if (this.house.occlusion(eye, eye.clone().addScaledVector(this.tmpDir, d), true) > 0) r = v
      }
      this.retractTarget = r
    }
    this.retract += (this.retractTarget - this.retract) * Math.min(1, dt * 9)
    this.lights.setTorchRetract(this.retract)
    this.kick = Math.max(0, this.kick - dt * 6)
    this.viewmodel.update(dt, this.camera, {
      visible: playing && !feed && this.caught <= 0,
      on: torchOn,
      charge: this.player.battery / 100,
      retract: this.retract,
      running: this.player.running,
      speed: Math.hypot(this.player.velocity.x, this.player.velocity.z),
      bob: this.player.bob,
      motion: this.settings.motion,
      gun: this.escape.hasGun,
      kick: this.kick,
    })

    this.mirrors.update(this.player.position, this.camera.position, playing && !feed)
    this.weather.tick(dt, this.night.progress, playing && !feed, this.settings.reducedEffects)

    // Room acoustics follow the room the player stands in.
    const name = room?.name ?? ''
    if (name !== this.reverbRoom) {
      this.reverbRoom = name
      const profile = REVERB.find(([pattern]) => pattern.test(name))
      this.audio.setReverb(profile ? profile[1] : 0.06, profile ? profile[2] : 3000)
    }
  }

  private renderFrame(dt: number) {
    const params = { cctv: this.cameraActive, stress: this.atmosphere?.stress ?? 0, darkness: this.darkness, glitch: this.glitch }
    if (this.post) this.post.render(dt, params)
    else this.renderer.render(this.scene, this.camera)
  }

  private finish(survived: boolean, reason: 'dawn' | 'escaped' | 'chase' | 'caught' = survived ? 'dawn' : 'caught') {
    this.ending = reason
    this.player.freeSprint = false
    this.glitch = 0
    this.audio.setGlitch(0)
    this.night.status = survived ? 'survived' : 'lost'; this.mode = survived ? 'survived' : 'lost'
    this.panel = 'none'; this.reportFromCamera = false; this.player.clear(); this.releaseMouse(); this.audio.setPaused(true)
    this.entity.mesh.visible = false; this.entity.grabGroup.visible = false; this.saved = null
    try { localStorage.removeItem(SAVE_KEY) } catch { /* Storage is optional. */ }
    if (survived) writeStorage('la-maison-last-night', { reports: this.night.reports, date: new Date().toISOString(), minutes: Math.round(this.night.elapsed / 60) })
    this.pushHud()
  }

  notify(text: string, seconds = 4) { this.hint = text; this.hintUntil = this.elapsed + seconds; this.pushHud() }
  private pushHud() {
    const room = this.house.roomAt(this.player.position)
    this.target = this.mode === 'playing' && this.panel === 'none' ? this.interactions.pick(this.player.eyePosition(), this.camera.getWorldDirection(new THREE.Vector3())) : null
    let prompt = this.target?.label ?? null
    if (this.target?.door) prompt = this.target.door.locked ? 'Porte verrouillée' : `${this.target.door.open ? 'Fermer' : 'Ouvrir'} la porte`
    if (this.target?.kind === 'switch') prompt = this.lights.isOn(this.target.roomId) ? 'Éteindre la lumière' : 'Allumer la lumière'
    if (this.target?.hold) prompt = `${this.target.label} · maintenir`
    const feed = this.cameraActive ? this.cameras.feed : null
    const visited = this.house.rooms.filter((r) => r.visited).length
    const objective = !this.lights.power ? 'Réarmez le disjoncteur dans le local technique.' : this.player.battery < 16 ? 'Rechargez la lampe dans la buanderie.' : this.night.phase === 0 ? 'Faites une première ronde. Mémorisez la maison.' : PHASES[this.night.phase].line
    this.events.onHud({ mode: this.mode, panel: this.panel, time: this.night.time, progress: this.night.progress, phase: PHASES[this.night.phase].name,
      room: room?.name ?? 'Escalier', roomId: room?.id ?? '', level: room?.level ?? 0, battery: Math.round(this.player.battery), stamina: Math.round(this.player.stamina), flashlight: this.player.flashlight, crouched: this.player.crouched,
      power: this.lights.power, prompt, hold: this.holdProgress, reports: this.night.reports, visited, roomsTotal: this.house.rooms.length, objective,
      hint: this.hint, fps: Math.round(this.fps), dragMode: this.dragMode, hasSave: this.hasSave, journal: [...this.night.entries], photos: [...this.photos],
      stress: this.atmosphere?.stress ?? 0, dread: this.atmosphere?.dread ?? 'CALME', heartRate: this.atmosphere?.heartRate ?? 62,
      inventory: this.escape?.inventory() ?? [], bullets: this.escape?.bullets ?? 0, hasGun: this.escape?.hasGun ?? false, escapeLine: this.escape?.objective() ?? null,
      code: this.escape?.hasNote ? this.escape.code : null,
      chase: this.entity?.chasing ? 1 - this.entity.chaseLeft / CHASE_SECONDS : 0, chasing: this.entity?.chasing ?? false, glitch: this.glitch, dying: this.caught > 0,
      fx: !!this.post && this.post.tier !== 'off', ending: this.ending,
      camera: feed ? { index: this.cameras.selected, id: feed.id, name: feed.name, roomId: this.cameras.room?.id ?? '', ir: feed.ir,
        offline: this.cameras.offline > 0, glitch: this.cameras.glitching, down: this.cameras.downList(), signal: this.cameras.signal, transition: this.cameras.transition > 0, zoom: this.cameras.zoom } : null,
    })
  }

  drawMap(canvas: HTMLCanvasElement, level: number) { drawHousePlan(canvas, this.house, this.player, level) }
  save() {
    if (this.night.status !== 'active' || this.caught > 0) return
    const data: SavedGame = { version: 2, signature: this.house.architectureSignature, night: this.night.save(),
      player: { position: this.player.position.toArray(), yaw: this.player.yaw, pitch: this.player.pitch, battery: this.player.battery, stamina: this.player.stamina, distance: this.player.distance, flashlight: this.cameraActive ? this.torchBeforeCamera : this.player.flashlight, crouched: this.player.crouched },
      doors: this.world.doors.map((d) => ({ open: d.open, t: d.t, ajar: d.ajar })), lights: [...this.lights.states], power: this.lights.power,
      visited: this.house.rooms.filter((r) => r.visited).map((r) => r.id), anomalies: this.anomalies.save(), entity: this.entity.save(), director: this.director.save(), photos: this.photos.slice(0, 4), corruption: this.lights.corruption, escape: this.escape.save() }
    this.saved = data; writeStorage(SAVE_KEY, data)
  }
  private restore(saved: SavedGame) {
    this.anomalies.reset(); this.doors.reset(); this.lights.reset(); this.player.reset(); this.entity.reset(); this.director.reset(); this.atmosphere.reset(); this.weather.reset(); this.night.restore(saved.night)
    const p = saved.player
    this.caught = 0
    this.player.position.fromArray(p.position); this.player.yaw = p.yaw; this.player.pitch = p.pitch; this.player.syncView()
    this.player.battery = THREE.MathUtils.clamp(p.battery, 0, 100); this.player.stamina = THREE.MathUtils.clamp(p.stamina, 0, 100); this.player.distance = p.distance
    this.player.flashlight = (p.flashlight ?? true) && this.player.battery > 0
    this.player.crouched = p.crouched ?? false
    this.player.height = this.player.crouched ? 1.06 : 1.78
    this.player.eye = this.player.crouched ? 0.94 : 1.64
    this.world.doors.forEach((d, i) => { if (saved.doors[i]) Object.assign(d, saved.doors[i]) })
    this.lights.states = new Map(saved.lights); this.lights.power = saved.power; this.lights.corruption = THREE.MathUtils.clamp(saved.corruption ?? 0, 0, 0.85)
    this.house.rooms.forEach((r) => { r.visited = saved.visited.includes(r.id) })
    this.anomalies.load(saved.anomalies); if (saved.corruption === undefined) this.lights.corruption = THREE.MathUtils.clamp(this.anomalies.missed * 0.075, 0, 0.85); this.entity.restore(saved.entity); this.director.restore(saved.director)
    if (saved.escape) this.escape.restore(saved.escape); else this.escape.reset(() => this.night.random())
    this.glitch = 0; this.glitchLeft = 0; this.player.freeSprint = false; this.ending = 'dawn'
    this.entityWoke = this.night.progress >= ENTITY_START
    this.resetDeathFx()
    this.photos = saved.photos ?? []; this.doors.tick(0.016, this.player.position); this.lights.invalidateShadows()
  }
  downloadAudit() {
    const url = URL.createObjectURL(new Blob([JSON.stringify({ ...this.house.audit(), runtimeChecks: this.checks }, null, 2)], { type: 'application/json' }))
    const link = document.createElement('a'); link.href = url; link.download = 'la-maison-analyse.json'; link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  private loop = (now: number) => {
    if (this.disposed) return
    this.raf = requestAnimationFrame(this.loop)
    const dt = Math.min(0.05, Math.max(0, (now - this.last) / 1000)); this.last = now
    this.frameCount++; this.frameTime += dt
    if (this.frameTime > 0.75) { this.fps = this.frameCount / this.frameTime; this.frameCount = 0; this.frameTime = 0 }
    this.update(dt); this.hudTimer -= dt
    if (this.hudTimer <= 0) { this.hudTimer = 0.15; this.pushHud() }
    this.frameBudget += dt
    if (this.cameraActive && this.frameBudget < 1 / 15 && !this.photoRequested) return
    this.frameBudget = 0
    this.cameras.renderMonitors(this.player.position, this.mode === 'playing' && !this.cameraActive)
    this.renderFrame(dt)
    if (this.post && this.mode === 'playing' && this.elapsed > 12) {
      const dropped = this.post.adapt(this.fps, dt)
      if (dropped) {
        if (this.mirrors) this.mirrors.enabled = dropped === 'ultra'
        this.notify(dropped === 'standard' ? 'Qualité réduite automatiquement pour garder la fluidité.' : 'Effets visuels désactivés pour garder la fluidité.', 5)
      }
    }
    if (this.photoRequested) {
      this.photoRequested = false
      const canvas = document.createElement('canvas'); canvas.width = 560; canvas.height = 315
      const ctx = canvas.getContext('2d')
      if (ctx) {
        ctx.drawImage(this.renderer.domElement, 0, 0, canvas.width, canvas.height)
        const room = this.cameraActive ? this.cameras.room?.name : this.house.roomAt(this.player.position)?.name
        this.photos.unshift({ id: Date.now(), room: room ?? 'Maison', time: this.night.time, url: canvas.toDataURL('image/jpeg', 0.76) }); this.photos = this.photos.slice(0, 6)
        this.audio.play('click', undefined, 0.3); this.notify('Photographie ajoutée au carnet. J pour la consulter.')
      }
    }
  }

  syncRemotePlayers(peers: Array<{ id: string; name: string; position: [number, number, number]; yaw: number; pitch: number; crouched: boolean; flashlight: boolean }>) {
    const keep = new Set(peers.map((p) => p.id))
    for (const [id, group] of this.remotePlayers) {
      if (!keep.has(id)) { group.removeFromParent(); this.remotePlayers.delete(id) }
    }
    for (const peer of peers) {
      let group = this.remotePlayers.get(peer.id)
      if (!group) {
        group = new THREE.Group()
        const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 1.05, 4, 8), new THREE.MeshStandardMaterial({ color: 0x6f7478, roughness: 0.95 }))
        body.position.y = 0.82
        const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 8), new THREE.MeshStandardMaterial({ color: 0x9a9a9a, roughness: 1 }))
        head.position.y = 1.58
        group.add(body, head)
        group.userData.name = peer.name
        this.scene.add(group)
        this.remotePlayers.set(peer.id, group)
      }
      group.position.set(...peer.position)
      group.rotation.y = peer.yaw
      group.scale.y = peer.crouched ? 0.72 : 1
      group.visible = this.mode === 'playing' && !this.cameraActive
    }
  }

  clearRemotePlayers() {
    for (const group of this.remotePlayers.values()) group.removeFromParent()
    this.remotePlayers.clear()
  }

  dispose() {
    this.clearRemotePlayers()
    this.disposed = true; this.save(); cancelAnimationFrame(this.raf)
    window.removeEventListener('keydown', this.onKeyDown); window.removeEventListener('keyup', this.onKeyUp)
    window.removeEventListener('blur', this.onBlur); window.removeEventListener('beforeunload', this.beforeUnload); window.removeEventListener('pointerup', this.onPointerUp)
    document.removeEventListener('visibilitychange', this.visibility); document.removeEventListener('pointerlockchange', this.onLockChange)
    document.removeEventListener('pointerlockerror', this.onLockError); document.removeEventListener('mousemove', this.onMouseMove)
    this.resizeObserver.disconnect(); this.releaseMouse()
    if (this.initialized) { this.anomalies.dispose(); this.cameras.dispose(); this.lights.dispose(); this.audio.dispose(); this.post?.dispose(); this.dust.dispose(); this.viewmodel.dispose(); this.mirrors.dispose() }
    const geometries = new Set<THREE.BufferGeometry>(), materials = new Set<THREE.Material>(), textures = new Set<THREE.Texture>()
    this.scene.traverse((o) => {
      if (!(o instanceof THREE.Mesh)) return
      geometries.add(o.geometry)
      for (const mat of Array.isArray(o.material) ? o.material : [o.material]) {
        materials.add(mat)
        for (const value of Object.values(mat)) if (value instanceof THREE.Texture) textures.add(value)
      }
    })
    geometries.forEach((g) => g.dispose()); materials.forEach((m) => m.dispose()); textures.forEach((t) => t.dispose())
    this.renderer.dispose(); this.renderer.domElement.remove()
  }
}