export type MultiplayerPeer = {
  id: string
  name: string
  position: [number, number, number]
  yaw: number
  pitch: number
  crouched: boolean
  flashlight: boolean
}

type ServerMessage =
  | { type: 'welcome'; id: string }
  | { type: 'lobby-created'; code: string; peers: MultiplayerPeer[] }
  | { type: 'lobby-joined'; code: string; peers: MultiplayerPeer[] }
  | { type: 'peer-joined'; peer: MultiplayerPeer }
  | { type: 'peer-left'; id: string }
  | { type: 'state'; peer: MultiplayerPeer }
  | { type: 'error'; message: string }

export class MultiplayerClient {
  ws: WebSocket | null = null
  id = ''
  code = ''
  connected = false
  isHost = false
  peers = new Map<string, MultiplayerPeer>()
  onPeers: (peers: MultiplayerPeer[]) => void = () => {}
  onStatus: (status: string) => void = () => {}
  onError: (message: string) => void = () => {}

  connect() {
    if (this.ws && this.ws.readyState <= WebSocket.OPEN) return
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:'
    const url = `${protocol}//${location.host}/ws`
    this.ws = new WebSocket(url)
    this.ws.addEventListener('open', () => { this.connected = true; this.onStatus('Connecté au serveur') })
    this.ws.addEventListener('close', () => { this.connected = false; this.onStatus('Déconnecté') })
    this.ws.addEventListener('error', () => this.onError('Connexion multijoueur impossible. Lancez le serveur La Maison.'))
    this.ws.addEventListener('message', (event) => {
      try { this.handle(JSON.parse(String(event.data)) as ServerMessage) } catch { this.onError('Réponse multijoueur invalide.') }
    })
  }

  private send(message: object) {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(message))
  }

  create(name: string) {
    this.connect()
    const run = () => this.send({ type: 'create', name: name.trim().slice(0, 18) || 'Joueur' })
    if (this.ws?.readyState === WebSocket.OPEN) run(); else this.ws?.addEventListener('open', run, { once: true })
  }

  join(code: string, name: string) {
    this.connect()
    const run = () => this.send({ type: 'join', code: code.replace(/\D/g, '').slice(0, 4), name: name.trim().slice(0, 18) || 'Joueur' })
    if (this.ws?.readyState === WebSocket.OPEN) run(); else this.ws?.addEventListener('open', run, { once: true })
  }

  sendState(state: Omit<MultiplayerPeer, 'id'>) {
    if (!this.code) return
    this.send({ type: 'state', state })
  }

  leave() {
    this.send({ type: 'leave' })
    this.code = ''
    this.peers.clear()
    this.onPeers([])
  }

  dispose() {
    this.leave()
    this.ws?.close()
    this.ws = null
  }

  private publish() { this.onPeers([...this.peers.values()]) }

  private handle(message: ServerMessage) {
    switch (message.type) {
      case 'welcome': this.id = message.id; break
      case 'lobby-created':
      case 'lobby-joined':
        this.code = message.code; this.isHost = message.type === 'lobby-created'; this.peers = new Map(message.peers.filter(p => p.id !== this.id).map(p => [p.id, p])); this.publish(); this.onStatus(`Salon ${this.code}`); break
      case 'peer-joined': this.peers.set(message.peer.id, message.peer); this.publish(); break
      case 'peer-left': this.peers.delete(message.id); this.publish(); break
      case 'state': if (message.peer.id !== this.id) { this.peers.set(message.peer.id, message.peer); this.publish() } break
      case 'error': this.onError(message.message); break
    }
  }
}
