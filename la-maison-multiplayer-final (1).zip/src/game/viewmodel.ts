import * as THREE from 'three'
import { buildPistol } from './props'

const wrap = (a: number) => Math.atan2(Math.sin(a), Math.cos(a))

export interface ViewmodelState {
  visible: boolean
  on: boolean
  charge: number
  /** 0 = free, 1 = fully pulled back because a wall is right in front. */
  retract: number
  running: boolean
  speed: number
  bob: number
  motion: boolean
  gun: boolean
  /** 0..1 recoil, decays by itself. */
  kick: number
}

/**
 * The torch as the player holds it: a metal body, a gloved fist and a sleeve.
 * It lags behind head turns, bobs with each step, drops when sprinting and is drawn
 * back toward the body when something is too close, as a real hand would.
 */
export class Viewmodel {
  readonly group = new THREE.Group()
  private lens: THREE.MeshStandardMaterial
  private rest = new THREE.Vector3(0.175, -0.18, -0.34)
  private offset = new THREE.Vector3()
  private rot = new THREE.Euler()
  private lastYaw = 0
  private lastPitch = 0
  private yawLag = 0
  private pitchLag = 0
  private ready = false
  private gunGroup = new THREE.Group()
  private gunOffset = new THREE.Vector3(-0.19, -0.17, -0.38)

  constructor(camera: THREE.Camera) {
    const body = new THREE.MeshStandardMaterial({ color: 0x1a1c1e, metalness: 0.85, roughness: 0.34, envMapIntensity: 0.5 })
    const ring = new THREE.MeshStandardMaterial({ color: 0x2b2e31, metalness: 0.9, roughness: 0.22, envMapIntensity: 0.5 })
    const chrome = new THREE.MeshStandardMaterial({ color: 0xc9ccce, metalness: 1, roughness: 0.12, envMapIntensity: 0.9 })
    const glove = new THREE.MeshStandardMaterial({ color: 0x1d1f20, roughness: 0.82, envMapIntensity: 0.1 })
    const skin = new THREE.MeshStandardMaterial({ color: 0xa57d68, roughness: 0.78, envMapIntensity: 0.1 })
    const sleeve = new THREE.MeshStandardMaterial({ color: 0x20262b, roughness: 0.95, envMapIntensity: 0.05 })
    this.lens = new THREE.MeshStandardMaterial({ color: 0x222222, emissive: 0xfff1d6, emissiveIntensity: 0, roughness: 0.1 })
    const add = (g: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) => {
      const mesh = new THREE.Mesh(g, m)
      mesh.position.set(x, y, z)
      mesh.rotation.set(rx, ry, rz)
      mesh.castShadow = false
      mesh.receiveShadow = false
      this.group.add(mesh)
      return mesh
    }
    const quarter = Math.PI / 2
    // Torch body, pointing along -z. The head is wider and holds a chrome reflector and the lens.
    add(new THREE.CylinderGeometry(0.0205, 0.0205, 0.17, 20), body, 0, 0, -0.07, quarter)
    for (let i = 0; i < 6; i++) add(new THREE.TorusGeometry(0.0207, 0.0012, 6, 20), ring, 0, 0, 0.0 - i * 0.012 - 0.01, 0, 0, 0)
    add(new THREE.CylinderGeometry(0.034, 0.0215, 0.052, 24), body, 0, 0, -0.18, quarter)
    add(new THREE.CylinderGeometry(0.0345, 0.0345, 0.006, 24), ring, 0, 0, -0.208, quarter)
    add(new THREE.CylinderGeometry(0.029, 0.014, 0.034, 20, 1, true), chrome, 0, 0, -0.192, quarter)
    add(new THREE.CircleGeometry(0.0295, 24), this.lens, 0, 0, -0.2115, 0, Math.PI, 0)
    add(new THREE.CylinderGeometry(0.0212, 0.0212, 0.022, 20), body, 0, 0, 0.034, quarter)
    add(new THREE.BoxGeometry(0.008, 0.004, 0.016), chrome, 0, 0.0215, -0.02)
    // Fist wrapped around the body: palm, four fingers over the top, thumb alongside.
    add(new THREE.CapsuleGeometry(0.0235, 0.05, 6, 12), glove, 0, -0.008, 0.0, quarter, 0, 0)
    for (let i = 0; i < 4; i++) add(new THREE.CapsuleGeometry(0.0072, 0.03, 4, 8), glove, 0.0, 0.017, -0.026 + i * 0.0155, 0, 0, quarter)
    add(new THREE.CapsuleGeometry(0.0085, 0.036, 4, 8), glove, 0.02, 0.012, -0.055, quarter, 0, -0.35)
    add(new THREE.CylinderGeometry(0.0275, 0.0265, 0.03, 14), skin, 0.0, -0.03, 0.07, quarter * 0.95, 0, 0)
    // Forearm in a dark sleeve, going back and down toward the body.
    const arm = add(new THREE.CapsuleGeometry(0.036, 0.3, 8, 14), sleeve, 0.045, -0.085, 0.24, 1.1, 0.12, -0.32)
    arm.scale.set(1, 1, 0.92)
    this.group.position.copy(this.rest)
    this.group.rotation.set(0.015, 0.045, 0)
    this.group.scale.setScalar(1.0)
    this.group.renderOrder = 6
    this.group.name = 'viewmodel'
    camera.add(this.group)
    this.buildGun(camera)
  }

  private buildGun(camera: THREE.Camera) {
    const glove = new THREE.MeshStandardMaterial({ color: 0x1d1f20, roughness: 0.82, envMapIntensity: 0.1 })
    const sleeve = new THREE.MeshStandardMaterial({ color: 0x20262b, roughness: 0.95, envMapIntensity: 0.05 })
    this.gunGroup.add(buildPistol())
    const part = (g: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) => {
      const o = new THREE.Mesh(g, m)
      o.position.set(x, y, z)
      o.rotation.set(rx, ry, rz)
      o.castShadow = false
      this.gunGroup.add(o)
    }
    part(new THREE.CapsuleGeometry(0.0255, 0.05, 6, 12), glove, 0.004, -0.052, 0.036, -0.2)
    for (let i = 0; i < 4; i++) part(new THREE.CapsuleGeometry(0.0072, 0.028, 4, 8), glove, 0.0, -0.075 + i * 0.0, 0.0 - i * 0.0 + 0.012, 0, 0, Math.PI / 2)
    part(new THREE.CapsuleGeometry(0.009, 0.04, 4, 8), glove, 0.022, -0.02, -0.01, 1.2, 0, -0.3)
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.036, 0.3, 8, 14), sleeve)
    arm.position.set(-0.02, -0.12, 0.2)
    arm.rotation.set(1.05, -0.1, 0.25)
    this.gunGroup.add(arm)
    this.gunGroup.position.copy(this.gunOffset)
    this.gunGroup.rotation.set(0.02, 0.07, 0)
    this.gunGroup.visible = false
    camera.add(this.gunGroup)
  }

  update(dt: number, camera: THREE.Camera, s: ViewmodelState) {
    this.group.visible = s.visible
    this.gunGroup.visible = s.visible && s.gun
    if (!s.visible) { this.ready = false; return }
    const yaw = camera.rotation.y
    const pitch = camera.rotation.x
    if (!this.ready) { this.lastYaw = yaw; this.lastPitch = pitch; this.ready = true }
    const rate = Math.max(dt, 0.001)
    // Inertia: the arm trails the head when turning and settles back.
    const yawRate = s.motion ? wrap(yaw - this.lastYaw) / rate : 0
    const pitchRate = s.motion ? (pitch - this.lastPitch) / rate : 0
    this.lastYaw = yaw
    this.lastPitch = pitch
    this.yawLag += (THREE.MathUtils.clamp(-yawRate * 0.012, -0.07, 0.07) - this.yawLag) * Math.min(1, dt * 9)
    this.pitchLag += (THREE.MathUtils.clamp(-pitchRate * 0.01, -0.05, 0.05) - this.pitchLag) * Math.min(1, dt * 9)

    const walk = s.motion ? THREE.MathUtils.clamp(s.speed / 4.2, 0, 1) : 0
    const bobX = Math.sin(s.bob) * 0.006 * walk
    const bobY = Math.abs(Math.sin(s.bob)) * -0.008 * walk
    const sprint = s.running ? 1 : 0
    const retract = THREE.MathUtils.clamp(s.retract, 0, 1)
    const target = new THREE.Vector3(
      this.rest.x + bobX + this.yawLag * 0.6 - retract * 0.07,
      this.rest.y + bobY + this.pitchLag * 0.5 - sprint * 0.05 - retract * 0.13,
      this.rest.z + sprint * 0.03 + retract * 0.2,
    )
    this.offset.lerp(target, Math.min(1, dt * 11))
    this.group.position.copy(this.offset)
    this.rot.set(
      0.015 - sprint * 0.2 + this.pitchLag * 1.2 + retract * 0.45,
      0.045 + this.yawLag * 1.6 - retract * 0.5,
      Math.sin(s.bob) * 0.018 * walk + sprint * 0.12 + this.yawLag * 0.9,
    )
    this.group.rotation.copy(this.rot)
    if (s.gun) {
      const kick = THREE.MathUtils.clamp(s.kick, 0, 1)
      this.gunOffset.lerp(new THREE.Vector3(
        -0.19 - bobX + this.yawLag * 0.5 + retract * 0.05,
        -0.17 + bobY * 0.9 + this.pitchLag * 0.4 - sprint * 0.06 - retract * 0.1 + kick * 0.012,
        -0.38 + sprint * 0.02 + retract * 0.15 + kick * 0.055,
      ), Math.min(1, dt * 14))
      this.gunGroup.position.copy(this.gunOffset)
      this.gunGroup.rotation.set(0.02 + kick * 0.38 - sprint * 0.25 + this.pitchLag, 0.07 + this.yawLag * 1.2, -Math.sin(s.bob) * 0.015 * walk)
    }

    const lit = s.on ? 1 : 0
    const dim = THREE.MathUtils.clamp(s.charge, 0.25, 1)
    this.lens.emissiveIntensity += (lit * 3.2 * dim - this.lens.emissiveIntensity) * Math.min(1, dt * 14)
  }

  dispose() {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) { o.geometry.dispose(); (o.material as THREE.Material).dispose() }
    })
    this.group.removeFromParent()
    this.gunGroup.removeFromParent()
  }
}
