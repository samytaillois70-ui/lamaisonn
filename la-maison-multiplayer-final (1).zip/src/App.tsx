import { useEffect, useRef, useState, type CSSProperties } from 'react'
import { Game, INITIAL_HUD, type HudState } from './game/engine'
import { loadSettings, type Settings } from './game/settings'
import { MultiplayerClient, type MultiplayerPeer } from './game/multiplayer'
import { Icon, Key } from './components/Icon'
import { HelpPanel, JournalPanel, KeypadPanel, LetterPanel, Modal, NotePanel, PlanPanel, ReportPanel, SettingsPanel } from './components/Panels'

function Surveillance({ game, hud }: { game: Game; hud: HudState }) {
  const feed = hud.camera!
  const preview = hud.mode === 'menu'
  return <section className="surveillance" aria-label="Caméras de la maison">
    <header className="surveillance-header"><div className="surveillance-brand"><Icon name="camera" size={22}/><div><strong>SURVEILLANCE</strong><span>RÉSEAU LOCAL / {preview ? 'REPÉRAGE AVANT LA NUIT' : 'DIFFUSION EN DIRECT'}</span></div></div><div className="feed-clock"><span className="status-dot"/>{hud.time}<button className="icon-button" onClick={() => game.exitCamera()} aria-label="Quitter les caméras"><Icon name="close"/></button></div></header>
    <div className="feed-info"><span className="micro">CANAL {String(feed.index + 1).padStart(2, '0')}</span><h2>{feed.name.toLocaleLowerCase('fr')}</h2><span className="feed-quality">{feed.ir ? 'INFRAROUGE' : 'BASSE LUMINOSITÉ'} <i/> 15 IPS</span></div>
    <div className="viewfinder"><i/><i/><i/><i/></div>
    {feed.offline && <div className="signal-loss"><Icon name="signal" size={34}/><h3>Signal interrompu.</h3><p>Rétablissement de la connexion en cours.</p><span className="connecting-line"/></div>}
    {feed.transition && !game.settings.reducedEffects && <div className="signal-transition"/>}
    {feed.glitch && !game.settings.reducedEffects && <div className="signal-glitch"/>}
    <aside className="camera-sidebar"><header><span className="micro">CAMÉRAS INTÉRIEURES</span><span>{game.cameras.feeds.length}</span></header><div className="camera-list">{game.cameras.feeds.map((cam, index) => <button key={cam.id} onClick={() => game.selectCamera(index)} className={index === feed.index ? 'active' : ''} aria-pressed={index === feed.index}><span className="channel-number">{String(index + 1).padStart(2, '0')}</span><span>{cam.name.toLocaleLowerCase('fr')}</span>{feed.down[index] && <span className="channel-flag">HORS LIGNE</span>}<i className={`channel-dot ${feed.down[index] ? 'is-down' : ''}`}/></button>)}</div><div className="camera-signal"><Icon name="signal" size={15}/><span>Signal local</span><strong>{feed.offline ? '0' : feed.signal}%</strong></div><p className="camera-notice">Une caméra ne surveille jamais toute une pièce.</p></aside>
    <div className="ptz-controls"><div><button className="icon-button" onClick={() => game.selectCamera(feed.index - 1)} aria-label="Caméra précédente"><Icon name="chevron" className="rotate-180"/></button><span>{String(feed.index + 1).padStart(2, '0')} <small>/ {String(game.cameras.feeds.length).padStart(2, '0')}</small></span><button className="icon-button" onClick={() => game.selectCamera(feed.index + 1)} aria-label="Caméra suivante"><Icon name="chevron"/></button></div><div><button className="icon-button" onClick={() => game.panCamera(0.12, 0)} aria-label="Orienter la caméra vers la gauche"><Icon name="chevron" className="rotate-180" size={17}/></button><button className="icon-button" onClick={() => game.panCamera(0, 0.1)} aria-label="Orienter vers le haut"><Icon name="chevron" className="rotate-up" size={17}/></button><button className="icon-button" onClick={() => game.panCamera(0, -0.1)} aria-label="Orienter vers le bas"><Icon name="chevron" className="rotate-down" size={17}/></button><button className="icon-button" onClick={() => game.panCamera(-0.12, 0)} aria-label="Orienter vers la droite"><Icon name="chevron" size={17}/></button></div><div><button className="icon-button" onClick={() => game.zoomCamera(-1)} aria-label="Dézoomer"><Icon name="minus" size={16}/></button><span className="micro">ZOOM</span><button className="icon-button" onClick={() => game.zoomCamera(1)} aria-label="Zoomer"><Icon name="plus" size={16}/></button></div></div>
    <footer className="surveillance-footer"><button className="text-button" onClick={() => game.exitCamera()}><Icon name="arrow" className="rotate-180" size={18}/>{preview ? 'Retour à la maison' : 'Quitter la tablette'}<Key>V</Key></button><span className="viewer-location">{preview ? 'REPÉRAGE / LA NUIT N’A PAS COMMENCÉ' : `VOUS ÊTES DANS : ${hud.room.toLocaleUpperCase('fr')}`}</span><div><button className="icon-button" aria-label="Photographier le flux" disabled={preview || feed.offline} onClick={() => game.photograph()}><Icon name="photo"/></button><button className="outline-button" disabled={preview} onClick={() => game.openPanel('report')}>Signaler une anomalie <Key>R</Key></button></div></footer>
  </section>
}

function TouchControls({ game, armed }: { game: Game; armed: boolean }) {
  return <div className="touch-controls"><span className="touch-look-hint">Glissez sur l’image pour regarder</span><div className="d-pad">{[['KeyW', 'up', 'Avancer'], ['KeyA', 'left', 'Aller à gauche'], ['KeyS', 'down', 'Reculer'], ['KeyD', 'right', 'Aller à droite']].map(([code, direction, label]) => <button key={code} className={`d-${direction}`} aria-label={label} onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); game.setKey(code, true) }} onPointerUp={() => game.setKey(code, false)} onPointerCancel={() => game.setKey(code, false)}><Icon name="chevron"/></button>)}</div><div className="touch-actions"><button onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); game.setKey('KeyE', true) }} onPointerUp={() => game.setKey('KeyE', false)} onPointerCancel={() => game.setKey('KeyE', false)}>E</button><button onClick={() => game.toggleFlashlight()} aria-label="Lampe torche"><Icon name="flashlight"/></button><button onClick={() => game.toggleCrouch()} aria-label="S’accroupir"><Icon name="footsteps"/></button>{armed && <button onClick={() => game.shoot()} aria-label="Tirer">TIR</button>}<button onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); game.setKey('ShiftLeft', true) }} onPointerUp={() => game.setKey('ShiftLeft', false)} onPointerCancel={() => game.setKey('ShiftLeft', false)}>COURIR</button></div></div>
}

export default function App() {
  const holder = useRef<HTMLDivElement>(null)
  const root = useRef<HTMLDivElement>(null)
  const engine = useRef<Game | null>(null)
  const [hud, setHud] = useState<HudState>(INITIAL_HUD)
  const [ready, setReady] = useState(false)
  const [bootDone, setBootDone] = useState(false)
  const [loadProgress, setLoadProgress] = useState(0)
  const [loadLabel, setLoadLabel] = useState('Ouverture de la maison')
  const [error, setError] = useState('')
  const [settings, setSettings] = useState<Settings>(loadSettings)
  const [confirmNew, setConfirmNew] = useState(false)
  const [fullScreen, setFullScreen] = useState(false)
  const multiplayer = useRef(new MultiplayerClient())
  const [mpOpen, setMpOpen] = useState(false)
  const [mpName, setMpName] = useState('Joueur')
  const [mpCode, setMpCode] = useState('')
  const [mpStatus, setMpStatus] = useState('Hors ligne')
  const [mpPeers, setMpPeers] = useState<MultiplayerPeer[]>([])
  const [mpError, setMpError] = useState('')

  useEffect(() => {
    let instance: Game | null = null
    let cancelled = false
    let revealTimer = 0
    const frame = () => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
    const timeout = setTimeout(() => {
      void (async () => {
        if (!holder.current) return
        try {
          instance = new Game(holder.current, { onHud: setHud })
          engine.current = instance
          // Diagnostic access for automated checks, only with ?debug in the address.
          if (new URLSearchParams(window.location.search).has('debug')) (window as unknown as { __game: Game }).__game = instance
          await frame()
          await instance.initialize((progress, label) => {
            if (cancelled) return
            setLoadProgress(Math.round(progress))
            setLoadLabel(label)
          })
          if (cancelled) return
          instance.beginDirect()
          await instance.prewarm((progress, label) => {
            if (cancelled) return
            setLoadProgress(Math.round(progress))
            setLoadLabel(label)
          })
          if (cancelled) return
          setLoadProgress(100)
          setLoadLabel('La maison est prête')
          setReady(true)
          revealTimer = window.setTimeout(() => { if (!cancelled) setBootDone(true) }, 650)
        } catch (e) {
          if (!cancelled) setError(e instanceof Error ? e.message : 'WebGL n’est pas disponible dans ce navigateur.')
        }
      })()
    }, 30)
    return () => { cancelled = true; clearTimeout(timeout); clearTimeout(revealTimer); instance?.dispose(); engine.current = null }
  }, [])
  useEffect(() => {
    const net = multiplayer.current
    net.onStatus = setMpStatus
    net.onError = setMpError
    net.onPeers = (peers) => { setMpPeers(peers); engine.current?.syncRemotePlayers(peers) }
    return () => net.dispose()
  }, [])

  useEffect(() => {
    const net = multiplayer.current
    const timer = window.setInterval(() => {
      const g = engine.current
      if (!g || !net.connected || !net.code || g.mode !== 'playing' || !g.player) return
      net.sendState({ name: mpName, position: [g.player.position.x, g.player.position.y, g.player.position.z], yaw: g.player.yaw, pitch: g.player.pitch, crouched: g.player.crouched, flashlight: g.player.flashlight })
    }, 50)
    return () => window.clearInterval(timer)
  }, [mpName])

  useEffect(() => { const onChange = () => setFullScreen(!!document.fullscreenElement); document.addEventListener('fullscreenchange', onChange); return () => document.removeEventListener('fullscreenchange', onChange) }, [])

  const game = engine.current
  const changeSettings = (patch: Partial<Settings>) => { setSettings((previous) => ({ ...previous, ...patch })); game?.setSettings(patch) }
  const fullscreen = async () => {
    try { if (document.fullscreenElement) await document.exitFullscreen(); else await root.current?.requestFullscreen() }
    catch { game?.notify('Le plein écran n’est pas autorisé par ce navigateur.') }
  }
  const start = () => { setConfirmNew(false); game?.startNew() }
  const menuVisible = hud.mode === 'paused' && !hud.camera && hud.panel === 'none'
  const ended = hud.mode === 'survived' || hud.mode === 'lost'
  const modalOpen = hud.panel !== 'none' && hud.panel !== 'camera'

  return <div ref={root} className={`experience ${settings.reducedEffects ? 'reduced-effects' : ''}`}>
    <div ref={holder} className={`world-canvas ${ready ? 'scene-ready' : ''} ${hud.camera?.ir ? 'infrared-feed' : ''} ${hud.camera?.glitch || (hud.glitch > 0.05 && !hud.fx) ? 'feed-glitch' : ''}`}/>
    {hud.mode === 'playing' && !hud.camera && !hud.dying && <div className="dread-layer" aria-hidden="true" style={{ '--stress': hud.stress.toFixed(3), '--beat': `${(60 / Math.max(45, hud.heartRate)).toFixed(3)}s` } as CSSProperties}><div className="dread-vignette"/><div className="dread-edge"/></div>}
    {menuVisible && <div className="menu-shade"/>}

    {!bootDone && !error && <div className={`boot-screen ${ready ? 'is-leaving' : ''}`} role="status" aria-live="polite" aria-label="Chargement de la maison">
      <div className="boot-brand"><span className="brand-mark"><Icon name="house" size={24}/></span><span>LA MAISON<small>PRÉPARATION DE LA NUIT</small></span></div>
      <div className="boot-center"><span className="micro">CHARGEMENT DIRECT</span><h1>La maison<br/>se réveille.</h1><p>Construction de la géométrie, chargement des textures, calcul des ombres et préparation du premier son.</p></div>
      <div className="boot-progress-wrap"><div className="boot-progress-meta"><span>{loadLabel}</span><strong>{loadProgress}%</strong></div><div className="boot-progress"><i style={{ width: `${loadProgress}%` }}/></div><small>La partie commencera automatiquement. Cliquez-glissez ensuite dans la maison pour regarder autour.</small></div>
    </div>}

    {(menuVisible || ended) && <header className="main-header"><button className="wordmark" aria-label="La Maison, accueil" onClick={() => { if (modalOpen) game?.closePanel() }}><span className="brand-mark"><Icon name="house" size={23}/></span><span>LA MAISON<span className="wordmark-caption">UNE EXPÉRIENCE IMMERSIVE</span></span></button><nav aria-label="Navigation principale"><button className="active" onClick={() => { if (modalOpen) game?.closePanel() }}>La nuit</button><button disabled={!ready || ended} onClick={() => game?.enterCamera()}>Surveillance</button><button disabled={!ready} onClick={() => { setMpOpen(true); setMpError('') }}>Multijoueur</button><button disabled={!ready} onClick={() => game?.openPanel('plan')}>Plan de la maison</button></nav><div className="header-tools"><button className="icon-button audio-toggle" disabled={!ready} onClick={() => changeSettings({ volume: settings.volume ? 0 : 0.65 })} aria-label={settings.volume ? 'Couper le son' : 'Activer le son'} title={settings.volume ? 'Couper le son' : 'Activer le son'}><Icon name={settings.volume ? 'sound' : 'mute'} size={19}/></button><span className="tool-divider"/><button className="icon-button" aria-label={fullScreen ? 'Quitter le plein écran' : 'Passer en plein écran'} onClick={fullscreen}><Icon name="expand" size={18}/></button></div></header>}

    {menuVisible && <main className={`intro ${ready ? 'is-ready' : ''}`}>
      <div className="intro-content"><div className="intro-eyebrow"><span className="status-dot"/><span>HORREUR PSYCHOLOGIQUE <span className="eyebrow-separator">/</span> NUIT 01</span></div><h1>LA MAISON<span className="title-stop">.</span></h1><p className="intro-subtitle">{hud.mode === 'paused' ? 'Elle vous attend toujours.' : 'Vous connaissez les lieux.'}<br/><em>{hud.mode === 'paused' ? 'Prenez le temps de respirer.' : 'Pas ce qui s’y cache.'}</em></p><p className="intro-description">{hud.mode === 'paused' ? 'Votre ronde est sauvegardée. Le temps s’est arrêté, mais rien dans la maison n’a été oublié.' : 'Une maison familière. Une nuit entière. Observez les détails, surveillez les pièces et ne faites pas confiance à vos premières impressions.'}</p><div className="intro-actions"><button className="primary-button start-button" disabled={!ready || !!error} onClick={() => hud.hasSave ? game?.resume() : start()}><span>{!ready ? 'Préparation de la maison' : hud.hasSave ? 'Reprendre la nuit' : 'Commencer la nuit'}</span>{!ready ? <span className="tiny-loader"/> : <Icon name="arrow" size={21}/>}</button><button className="text-button" disabled={!ready} onClick={() => game?.openPanel('help')}>Les consignes <Icon name="chevron" size={15}/></button></div><div className="intro-afterword"><Icon name="headphones" size={16}/><span>Un casque. Le calme. Et toute votre attention.</span></div>{hud.hasSave && <button className="new-night-link" onClick={() => setConfirmNew(true)}>Commencer une nouvelle nuit</button>}</div>
      <div className="intro-chapter" aria-hidden="true"><span>01</span><i/><span>RESTEZ ATTENTIF.</span></div>
    </main>}

    {menuVisible && <footer className="main-footer"><div className="footer-location"><span className="micro">RÉSIDENCE FAMILIALE</span><span>{hud.mode === 'paused' ? 'Nuit en pause · sauvegarde locale' : 'Exploration intérieure · expérience solo'}</span></div><div className="night-timeline"><span className="timeline-time">{hud.mode === 'paused' ? hud.time : '22:00'}</span><div className="timeline-track"><i style={{ width: `${hud.mode === 'paused' ? hud.progress * 100 : 0}%` }}/><span/><span/><span/><span/><span/><span/><span/><b/></div><span>06:00</span><small>JUSQU’À L’AUBE</small></div><button className="footer-settings" disabled={!ready} onClick={() => game?.openPanel('settings')}><Icon name="settings" size={19}/><span>Paramètres</span></button></footer>}

    {hud.mode === 'playing' && !hud.camera && !hud.dying && <div className="game-hud"><header className="hud-header"><div><span className="eyebrow">NUIT 01 <i/> {hud.level === 1 ? 'ÉTAGE' : hud.level === -1 ? 'SOUS-SOL' : 'REZ-DE-CHAUSSÉE'}</span><h2 key={hud.room}>{hud.room}</h2></div><div className="hud-time"><Icon name="moon" size={19}/><time>{hud.time}</time><button className="icon-button" onClick={() => game?.pause()} aria-label="Mettre en pause"><Icon name="pause" size={17}/></button></div></header><div className="night-progress"><i style={{ width: `${hud.progress * 100}%` }}/></div><div className="objective"><span className="micro">{hud.phase}</span><p>{hud.objective}</p></div><span className={`crosshair ${hud.prompt ? 'is-interactive' : ''}`}/>{hud.prompt && <div className="interaction-prompt"><Key>E</Key><span>{hud.prompt}</span>{hud.hold > 0 && <span className="interaction-progress"><i style={{ width: `${hud.hold * 100}%` }}/></span>}</div>}<footer className="hud-footer"><div className={`player-resources ${hud.battery < 16 ? 'low-battery' : ''}`}><div><Icon name="flashlight" size={20}/><span>{hud.flashlight ? 'LAMPE ALLUMÉE' : 'LAMPE ÉTEINTE'}</span><strong>{hud.battery}<small>%</small></strong></div><div className="resource-track"><i style={{ width: `${hud.battery}%` }}/></div>{hud.stamina < 97 && <div className="stamina-track" aria-label={`Endurance ${hud.stamina}%`}><Icon name="footsteps" size={13}/><span><i style={{ width: `${hud.stamina}%` }}/></span></div>}{hud.crouched && <small className="crouch-status">ACCROUPI · DÉPLACEMENTS DISCRETS</small>}</div><div className="hud-actions"><button onClick={() => game?.enterCamera()}><Icon name="camera" size={17}/><span>Caméras</span><Key>V</Key></button><button onClick={() => game?.openPanel('report')}><Icon name="eye" size={18}/><span>Signaler</span><Key>R</Key></button><button onClick={() => game?.openPanel('journal')}><Icon name="book" size={17}/><span>Carnet</span><Key>J</Key></button><button onClick={() => game?.openPanel('plan')} aria-label="Plan de la maison"><Icon name="map" size={17}/><Key>M</Key></button></div></footer>{settings.captions && <div className="movement-help"><span><Key>ZQSD</Key> / <Key>WASD</Key> Déplacement</span><span><Key>F</Key> Lampe</span><span><Key>C</Key> S’accroupir</span><span><Key>N</Key> Photo</span>{hud.dragMode && <span className="drag-hint">Cliquez-glissez pour regarder</span>}</div>}{game && hud.panel === 'none' && <TouchControls game={game} armed={hud.hasGun}/>}</div>}

    {hud.mode === 'playing' && !hud.camera && !hud.dying && <div className="escape-hud">
      {hud.chasing && <div className="chase-bar" role="progressbar" aria-label="Survie à la poursuite" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(hud.chase * 100)}><i style={{ width: `${hud.chase * 100}%` }}/><span>COUREZ</span></div>}
      {(hud.inventory.length > 0 || hud.hasGun) && <div className="inventory" aria-label="Objets en poche">
        {hud.inventory.map((item) => <span key={item.id} className="chip">{item.label}</span>)}
        {hud.hasGun && <span className="chip gun">Pistolet <b className="ammo" aria-label={`${hud.bullets} cartouche${hud.bullets > 1 ? 's' : ''}`}>{[0, 1, 2].map((n) => <i key={n} className={n < hud.bullets ? 'on' : ''}/>)}</b></span>}
      </div>}
      {hud.escapeLine && !hud.chasing && <div className="escape-line">{hud.escapeLine}</div>}
    </div>}

    {hud.dying && <div className="devour-layer" aria-hidden="true"><div className="devour-blood"/><div className="devour-black"/></div>}

    {hud.camera && game && <Surveillance game={game} hud={hud}/>}

    {ended && <div className={`ending ${hud.mode}`}><span className="eyebrow">{hud.ending === 'escaped' ? 'LA PORTE EST OUVERTE / DEHORS' : hud.ending === 'chase' ? 'DIX SECONDES / LA POURSUITE EST FINIE' : hud.mode === 'survived' ? '06:00 / LA RELÈVE' : `${hud.time} / FIN DE LA RONDE`}</span><h1>{hud.ending === 'escaped' ? <>VOUS ÊTES<br/>SORTI.</> : hud.ending === 'chase' ? <>IL N’A PAS PU<br/>VOUS ATTEINDRE.</> : hud.mode === 'survived' ? <>VOUS ÊTES<br/>ENCORE LÀ.</> : <>VOUS N’ÉTIEZ<br/>PAS SEUL.</>}</h1><p>{hud.ending === 'escaped' ? 'La dernière planche a cédé, le verrou a tourné, le code était le bon. L’air froid de la nuit vous a frappé le visage. Derrière vous, la maison est restée silencieuse, comme si elle attendait.' : hud.ending === 'chase' ? 'Vous avez couru sans vous retourner. Au bout de dix secondes, il s’est arrêté net, au milieu du couloir. Pour l’instant.' : hud.mode === 'survived' ? `Le matin a fini par arriver. Vous avez confirmé ${hud.reports} écart${hud.reports > 1 ? 's' : ''} et parcouru ${hud.visited} espaces de la maison. Ce que vous avez vu vous appartient.` : 'Il vous a fixé trois fois. La première, il suffisait de le signaler. La prochaine fois, ne le laissez pas revenir : signalez ce que vous avez vu, ou cherchez de quoi sortir d’ici. Et si la peur est trop forte, réglez-la sur « Doux » dans les paramètres.'}</p><div><button className="primary-button" onClick={start}>Recommencer la nuit <Icon name="arrow"/></button><button className="text-button" onClick={() => game?.openPanel('journal')}>Relire le carnet <Icon name="book" size={18}/></button></div></div>}

    {game && hud.panel === 'report' && <ReportPanel game={game} hud={hud}/>}
    {game && hud.panel === 'plan' && <PlanPanel game={game} level={hud.level}/>}
    {game && hud.panel === 'journal' && <JournalPanel game={game} hud={hud}/>}
    {game && hud.panel === 'letter' && <LetterPanel game={game}/>}
    {game && hud.panel === 'keypad' && <KeypadPanel game={game} hud={hud}/>}
    {game && hud.panel === 'note' && <NotePanel game={game} hud={hud}/>}
    {game && hud.panel === 'help' && <HelpPanel game={game}/>}
    {game && hud.panel === 'settings' && <SettingsPanel game={game} settings={settings} change={changeSettings}/>}

    {mpOpen && <div className="mp-overlay">
      <div className="mp-panel">
        <div className="mp-eyebrow">RÉSEAU COOPÉRATIF / JUSQU’À 4 JOUEURS</div>
        <h2>Rejoindre la maison</h2>
        <p>Créez un salon et partagez son code à 4 chiffres, ou rejoignez un salon existant.</p>
        <label>Nom <input value={mpName} maxLength={18} onChange={(e) => setMpName(e.target.value)} /></label>
        <div className="mp-actions"><button className="primary-button" onClick={() => multiplayer.current.create(mpName)}>Créer un lobby</button><div className="mp-join"><input inputMode="numeric" maxLength={4} placeholder="CODE" value={mpCode} onChange={(e) => setMpCode(e.target.value.replace(/\D/g,'').slice(0,4))}/><button className="outline-button" disabled={mpCode.length !== 4} onClick={() => multiplayer.current.join(mpCode, mpName)}>Rejoindre</button></div></div>
        {multiplayer.current.code && <div className="mp-room"><span>CODE DU LOBBY</span><strong>{multiplayer.current.code}</strong><small>{mpPeers.length + 1}/4 joueurs · {mpStatus}</small></div>}
        {mpPeers.length > 0 && <div className="mp-list">{mpPeers.map((peer) => <span key={peer.id}>{peer.name}</span>)}</div>}
        {mpError && <div className="mp-error">{mpError}</div>}
        <button className="text-button" onClick={() => { multiplayer.current.leave(); setMpOpen(false) }}>Fermer</button>
      </div>
    </div>}

    {confirmNew && <Modal title="Recommencer la nuit ?" eyebrow="NOUVELLE RONDE" onClose={() => setConfirmNew(false)}><div className="confirmation-body"><p>Votre sauvegarde actuelle sera remplacée. La maison restera la même, mais la nuit sera différente.</p><button className="primary-button" onClick={start}>Commencer une nouvelle nuit <Icon name="arrow"/></button><button className="text-button" onClick={() => setConfirmNew(false)}>Conserver ma sauvegarde</button></div></Modal>}
    {hud.hint && ready && <div className="toast" key={hud.hint} role="status"><span/><p>{hud.hint}</p></div>}
    {error && <div className="error-panel" role="alert"><Icon name="alert" size={30}/><h2>La scène 3D n’a pas pu démarrer.</h2><p>Cette expérience nécessite WebGL et l’accélération graphique. Essayez un navigateur récent.</p><details><summary>Détail technique</summary><p>{error}</p></details><button className="primary-button" onClick={() => window.location.reload()}>Réessayer <Icon name="refresh"/></button></div>}
  </div>
}