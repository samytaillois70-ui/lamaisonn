import type { CSSProperties } from 'react'

export type IconName = 'house' | 'arrow' | 'camera' | 'map' | 'book' | 'settings' | 'sound' | 'mute' | 'expand' | 'close' | 'play' | 'pause' | 'moon' | 'sun' | 'battery' | 'flashlight' | 'headphones' | 'eye' | 'check' | 'chevron' | 'alert' | 'plus' | 'minus' | 'signal' | 'footsteps' | 'photo' | 'refresh' | 'download' | 'clock' | 'lock'
const paths: Record<IconName, React.ReactNode> = {
  house: <><path d="m3 10 9-7 9 7v10H3Z"/><path d="M9 20V11h6v9M6 10V6"/></>,
  arrow: <><path d="M4 12h16m-6-6 6 6-6 6"/></>,
  camera: <><rect x="3" y="7" width="13" height="11" rx="1.5"/><path d="m16 10 5-3v11l-5-3M6 4h7"/></>,
  map: <><path d="m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2ZM9 3v16M15 5v16"/></>,
  book: <><path d="M4 3h7a3 3 0 0 1 3 3v15a3 3 0 0 0-3-2H4ZM14 6a3 3 0 0 1 3-3h3v16h-3a3 3 0 0 0-3 2M7 7h3M7 10h3"/></>,
  settings: <><path d="M4 7h16M4 17h16"/><rect x="7" y="4" width="4" height="6" rx="1"/><rect x="14" y="14" width="4" height="6" rx="1"/></>,
  sound: <><path d="m4 9 4 0 5-4v14l-5-4H4ZM17 8a6 6 0 0 1 0 8M20 5a10 10 0 0 1 0 14"/></>,
  mute: <><path d="m4 9 4 0 5-4v14l-5-4H4ZM17 9l5 6m0-6-5 6"/></>,
  expand: <><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/></>,
  close: <path d="m6 6 12 12M6 18 18 6"/>,
  play: <path d="m8 4 13 8-13 8Z"/>,
  pause: <><path d="M8 5v14M16 5v14"/></>,
  moon: <path d="M20 14A9 9 0 0 1 10 3a9 9 0 1 0 10 11Z"/>,
  sun: <><circle cx="12" cy="12" r="4"/><path d="M12 1v2M12 21v2M1 12h2m18 0h2M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2"/></>,
  battery: <><rect x="2" y="6" width="17" height="12" rx="1.5"/><path d="M22 10v4M6 10v4m4-4v4m4-4v4"/></>,
  flashlight: <><path d="m9 3-2 6 3 4v8h4v-8l3-4-2-6ZM7 9h10M10 16h4"/></>,
  headphones: <><path d="M4 15v-4a8 8 0 0 1 16 0v4"/><rect x="3" y="12" width="4" height="8" rx="1.5"/><rect x="17" y="12" width="4" height="8" rx="1.5"/></>,
  eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  chevron: <path d="m9 5 7 7-7 7"/>,
  alert: <><path d="M12 3 2 21h20ZM12 9v5M12 17v.2"/></>,
  plus: <path d="M5 12h14M12 5v14"/>,
  minus: <path d="M5 12h14"/>,
  signal: <><path d="M4 17v4M9 13v8M14 8v13M19 3v18"/></>,
  footsteps: <><path d="M7 3c-3 0-3 6-2 9l4-1c2-3 1-8-2-8ZM5 15l4-1v4c-1 3-4 2-4 0ZM17 6c-3 0-3 6-2 9l4-1c2-3 1-8-2-8ZM15 18l4-1v3c-1 3-4 2-4 0Z"/></>,
  photo: <><path d="M3 7h4l2-3h6l2 3h4v14H3Z"/><circle cx="12" cy="13" r="4"/></>,
  refresh: <><path d="M20 10a8 8 0 1 0-2 8M20 3v7h-7"/></>,
  download: <><path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></>,
  lock: <><rect x="5" y="10" width="14" height="11" rx="1"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>,
}
export function Icon({ name, size = 20, className = '', style }: { name: IconName; size?: number; className?: string; style?: CSSProperties }) {
  return <svg className={className} style={style} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

export function Key({ children }: { children: React.ReactNode }) { return <kbd>{children}</kbd> }