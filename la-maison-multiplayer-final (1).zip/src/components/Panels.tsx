import { useEffect, useRef, useState, type ReactNode } from 'react'
import type { Game, HudState } from '../game/engine'
import { CATEGORIES, type AnomalyCategory } from '../game/anomalies'
import { LETTER } from '../game/interactions'
import { DEFAULT_SETTINGS, type Settings } from '../game/settings'
import { Icon, Key } from './Icon'

export function Modal({ title, eyebrow, children, onClose, wide = false, className = '' }: { title: string; eyebrow?: string; children: ReactNode; onClose: () => void; wide?: boolean; className?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    ref.current?.focus()
    return () => { if (previous?.isConnected) previous.focus({ preventScroll: true }) }
  }, [])
  return <div className={`modal-backdrop ${className}`} onPointerDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
    <section className={`dialog ${wide ? 'dialog-wide' : ''}`} ref={ref} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} onKeyDown={(e) => {
      if (e.key === 'Escape') { e.stopPropagation(); onClose() }
      if (e.key === 'Tab') {
        e.stopPropagation()
        const elements = ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input, select, a[href], [tabindex="0"]')
        if (!elements?.length) return
        const first = elements[0], last = elements[elements.length - 1]
        if (e.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { e.preventDefault(); last.focus() }
        if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
      }
    }}>
      <header className="dialog-header"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h2>{title}</h2></div><button className="icon-button" aria-label="Fermer" onClick={onClose}><Icon name="close" /></button></header>
      {children}
    </section>
  </div>
}

export function ReportPanel({ game, hud }: { game: Game; hud: HudState }) {
  const [room, setRoom] = useState(hud.camera?.roomId || hud.roomId || game.house.rooms[0].id)
  const [category, setCategory] = useState<AnomalyCategory | ''>('')
  return <Modal title="Quelque chose a changé ?" eyebrow="CARNET D’OBSERVATION / NOUVEAU RELEVÉ" className="report-backdrop" onClose={() => game.closePanel()}>
    <form className="report-form" onSubmit={(e) => { e.preventDefault(); if (category) game.report(room, category) }}>
      <p className="muted">Fiez-vous à votre mémoire. Tous les bruits ne sont pas des anomalies.</p>
      <label className="field-label" htmlFor="report-room">01. La pièce</label>
      <select id="report-room" value={room} onChange={(e) => setRoom(e.target.value)}>{game.house.rooms.map((r) => <option key={r.id} value={r.id}>{r.name} {r.level === 1 ? ' · Étage' : r.level === -1 ? ' · Sous-sol' : ''}</option>)}</select>
      <fieldset className="report-categories"><legend className="field-label">02. Le changement observé</legend>{CATEGORIES.map((c) => <button type="button" key={c.id} aria-pressed={category === c.id} className={category === c.id ? 'selected' : ''} onClick={() => setCategory(c.id)}><span className="radio-dot"/><span>{c.name}<small>{c.description}</small></span></button>)}</fieldset>
      <p className="live-note"><span className="status-dot"/> La nuit continue pendant votre signalement.</p>
      <button className="primary-button" type="submit" disabled={!category}>Envoyer le relevé <Icon name="arrow"/></button>
    </form>
  </Modal>
}

export function PlanPanel({ game, level: initialLevel }: { game: Game; level: number }) {
  const [level, setLevel] = useState(initialLevel)
  const canvas = useRef<HTMLCanvasElement>(null)
  useEffect(() => { if (canvas.current) game.drawMap(canvas.current, level) }, [game, level])
  return <Modal title="Chaque pièce compte." eyebrow="LA MAISON / PLAN INTÉRIEUR" wide onClose={() => game.closePanel()}>
    <div className="plan-toolbar"><div className="tabs">{[[-1, 'Sous-sol'], [0, 'Rez-de-chaussée'], [1, 'Étage']] .map(([id, label]) => <button key={id} className={level === id ? 'active' : ''} onClick={() => setLevel(Number(id))}>{label}</button>)}</div><span className="micro">GÉOMÉTRIE D’ORIGINE</span></div>
    <canvas ref={canvas} width={1100} height={660} className="house-plan" aria-label={`Plan du niveau ${level}, pièces, mobilier, portes et caméras`}/>
    <div className="plan-legend"><span><i className="legend-player"/> Votre position</span><span><i className="legend-camera"/> Caméra</span><span><i className="legend-door"/> Porte fermée</span><span className="muted">Aucun déplacement rapide.</span></div>
  </Modal>
}

export function JournalPanel({ game, hud }: { game: Game; hud: HudState }) {
  const [tab, setTab] = useState<'journal' | 'rooms' | 'photos'>('journal')
  const [enlarged, setEnlarged] = useState<number | null>(null)
  const photo = hud.photos.find((p) => p.id === enlarged)
  return <Modal title="Le carnet de nuit." eyebrow={`${hud.time} / ${hud.reports} ÉCART${hud.reports !== 1 ? 'S' : ''} CONFIRMÉ${hud.reports !== 1 ? 'S' : ''}`} wide onClose={() => game.closePanel()}>
    <div className="tabs journal-tabs"><button className={tab === 'journal' ? 'active' : ''} onClick={() => setTab('journal')}>Journal</button><button className={tab === 'rooms' ? 'active' : ''} onClick={() => setTab('rooms')}>Repères de la maison</button><button className={tab === 'photos' ? 'active' : ''} onClick={() => { setTab('photos'); setEnlarged(null) }}>Photographies <span>{hud.photos.length}</span></button></div>
    <div className="journal-content">
      {tab === 'journal' && (hud.journal.length ? <ol className="journal-entries">{hud.journal.map((entry) => <li key={entry.id} className={entry.kind}><time>{entry.time}</time><i/><p>{entry.text}</p>{entry.kind === 'report' && <Icon name="check" size={16}/>}</li>)}</ol> : <div className="empty-state"><Icon name="book" size={34}/><h3>La nuit n’a pas encore commencé.</h3><p>Vos observations et vos relevés apparaîtront ici.</p><button className="text-button" onClick={() => game.openPanel('letter')}>Lire la lettre laissée dans le hall <Icon name="arrow" size={16}/></button></div>)}
      {tab === 'rooms' && <div className="room-notes">{game.house.rooms.map((r) => <article key={r.id} className={r.visited ? 'visited' : ''}><div><span className="micro">{r.level === 1 ? 'ÉTAGE' : r.level === -1 ? 'SOUS-SOL' : 'REZ-DE-CHAUSSÉE'}</span>{r.visited ? <Icon name="check" size={15}/> : <Icon name="lock" size={14}/>}</div><h3>{r.name}</h3><p>{r.visited ? r.purpose : 'Parcourez cette pièce pour en noter les repères.'}</p></article>)}</div>}
      {tab === 'photos' && (photo ? <div className="photo-enlarged"><button className="text-button" onClick={() => setEnlarged(null)}>Retour aux photographies</button><img src={photo.url} alt={`${photo.room}, photographiée à ${photo.time}`}/><p>{photo.room} <time>{photo.time}</time></p></div> : hud.photos.length ? <div className="photo-grid">{hud.photos.map((p) => <button key={p.id} onClick={() => setEnlarged(p.id)}><img src={p.url} alt={`${p.room} à ${p.time}`}/><span>{p.room}<time>{p.time}</time></span></button>)}</div> : <div className="empty-state"><Icon name="photo" size={34}/><h3>Ne vous fiez pas qu’à votre mémoire.</h3><p>En jeu, appuyez sur <Key>N</Key> pour photographier ce que vous voyez.<br/>Les six dernières images sont conservées dans votre carnet.</p></div>)}
    </div>
    <footer className="dialog-footer"><span>{hud.visited} / {hud.roomsTotal} espaces parcourus</span><span>LA NUIT EST EN PAUSE</span></footer>
  </Modal>
}

export function LetterPanel({ game }: { game: Game }) {
  return <Modal title="Pour cette nuit." eyebrow="UNE LETTRE SUR LA CONSOLE DU HALL" className="letter-backdrop" onClose={() => game.closePanel()}><div className="letter-paper">{LETTER.map((paragraph, i) => <p key={i}>{paragraph}</p>)}</div><footer className="dialog-footer"><span>Note retrouvée dans la maison</span><button className="text-button" onClick={() => game.closePanel()}>Reposer la lettre <Icon name="arrow" size={17}/></button></footer></Modal>
}

export function SettingsPanel({ game, settings, change }: { game: Game; settings: Settings; change: (patch: Partial<Settings>) => void }) {
  const sliders: { key: 'brightness' | 'volume' | 'sensitivity' | 'fov'; label: string; min: number; max: number; step: number; value: string }[] = [
    { key: 'volume', label: 'Volume général', min: 0, max: 1, step: 0.05, value: `${Math.round(settings.volume * 100)} %` },
    { key: 'brightness', label: 'Luminosité', min: 0.8, max: 1.8, step: 0.05, value: `${settings.brightness.toFixed(2)}` },
    { key: 'sensitivity', label: 'Sensibilité de la souris', min: 0.5, max: 4, step: 0.1, value: `${settings.sensitivity.toFixed(1)}` },
    { key: 'fov', label: 'Champ de vision', min: 55, max: 90, step: 1, value: `${settings.fov}°` },
  ]
  return <Modal title="À votre rythme." eyebrow="PARAMÈTRES / ENREGISTREMENT AUTOMATIQUE" onClose={() => game.closePanel()}>
    <div className="settings-content">
      <label className="field-label">Intensité de la peur</label><div className="segments">{[{ v: 0.8, l: 'Doux' }, { v: 1, l: 'Intense' }, { v: 1.35, l: 'Extrême' }].map((o) => <button className={settings.intensity === o.v ? 'active' : ''} key={o.l} onClick={() => change({ intensity: o.v })}>{o.l}</button>)}</div>
      <p className="setting-note">Règle la fréquence des signes, le battement de cœur, le tremblement et le rétrécissement du champ de vision. Baissez le volume si vous jouez au casque.</p>
      <label className="field-label">Durée de la prochaine nuit</label><div className="segments">{[12, 20, 32].map((duration) => <button className={settings.duration === duration ? 'active' : ''} key={duration} onClick={() => change({ duration })}>{duration} min</button>)}</div>
      <p className="setting-note">Toujours de 22:00 à 06:00. Seul le rythme du temps change.</p>
      {sliders.map((s) => <label className="range-field" key={s.key}><span>{s.label}<output>{s.value}</output></span><input type="range" min={s.min} max={s.max} step={s.step} value={settings[s.key]} onChange={(e) => change({ [s.key]: Number(e.target.value) })}/></label>)}
      <label className="select-field"><span>Qualité du rendu</span><select value={settings.quality} onChange={(e) => change({ quality: e.target.value as Settings['quality'] })}><option value="balanced">Équilibrée</option><option value="high">Haute résolution</option><option value="ultra">Réalisme extrême</option></select></label>
      {([
        ['motion', 'Mouvements de caméra', 'Balancement léger des pas et du regard.'],
        ['reducedEffects', 'Réduire les effets', 'Désactive les scintillements et parasites visuels.'],
        ['captions', 'Afficher les raccourcis', 'Des repères discrets pendant la ronde.'],
      ] as const).map(([key, label, description]) => <label className="toggle-field" key={key}><span>{label}<small>{description}</small></span><input type="checkbox" checked={settings[key]} onChange={(e) => change({ [key]: e.target.checked })}/><i/></label>)}
      <div className="settings-links"><button className="text-button" onClick={() => change(DEFAULT_SETTINGS)}><Icon name="refresh" size={15}/> Réinitialiser</button><button className="text-button" onClick={() => game.downloadAudit()}><Icon name="download" size={15}/> Analyse de la maison</button></div>
    </div>
  </Modal>
}

const CONTROLS = [['Z Q S D / W A S D', 'Se déplacer'], ['Souris', 'Regarder autour de soi'], ['E', 'Interagir, ouvrir ou fermer'], ['F', 'Allumer la lampe torche'], ['Maj', 'Courir, environ 5 secondes'], ['C', 'S’accroupir / se relever'], ['Espace', 'Petit saut'], ['V', 'Consulter les caméras'], ['R', 'Signaler un changement'], ['N', 'Prendre une photographie'], ['J', 'Ouvrir le carnet'], ['M', 'Consulter le plan'], ['Clic gauche / G', 'Tirer, une fois le pistolet trouvé'], ['Échap', 'Faire une pause'], ['[ / ]', 'Changer de caméra'], ['+ / −', 'Zoomer dans une caméra'], ['Flèches', 'Orienter une caméra']]
export function HelpPanel({ game }: { game: Game }) {
  return <Modal title="Observer. Douter. Survivre." eyebrow="LES CONSIGNES DE LA NUIT" wide onClose={() => game.closePanel()}>
    <div className="help-content"><div className="help-intro"><span>01</span><div><h3>Apprenez les lieux.</h3><p>Faites une première ronde avant 23:00. Mémorisez les objets, les cadres et les lumières. Photographiez les détails qui vous semblent importants.</p></div></div><div className="help-intro"><span>02</span><div><h3>Vérifiez vos doutes.</h3><p>Un véritable changement se signale avec sa pièce et sa catégorie. Une porte qui grince ou un tuyau qui claque n’est pas forcément une anomalie.</p></div></div><div className="help-intro"><span>03</span><div><h3>Ne perdez pas la maison de vue.</h3><p>Les caméras ne mettent pas la nuit en pause. Si des pas approchent, éteignez votre lampe, accroupissez-vous et cherchez un obstacle ou une porte pour rompre la ligne de vue. La batterie se recharge dans la buanderie.</p></div></div>
    <div className="help-intro"><span>04</span><div><h3>Sortir, ou le tenir à distance.</h3><p>La porte d’entrée est condamnée : deux planches, un verrou à clé et un digicode. Cherchez dans l’ordre : une petite clé de meuble dort dans un tiroir du rez-de-chaussée, le marteau est dans le garage, un papier avec le code traîne dans une chambre ou la salle de bain. Les meubles fermés (télévision, commode, dressing) cachent la clé de la porte et celle de l’armoire à armes du sous-sol : trois cartouches, jamais plus. Vers 01:00, quelque chose se réveille ; avant, profitez-en. Le signaler le fait disparaître 30 secondes, une balle une minute.</p></div></div>
    <div className="controls-grid">{CONTROLS.map(([key, label]) => <div key={key}><Key>{key}</Key><span>{label}</span></div>)}</div>
    <p className="help-footnote"><Icon name="headphones" size={18}/> Au casque, les sons vous donnent des informations que vos yeux ne peuvent pas voir.</p>
    <p className="setting-note">Sur écran tactile : utilisez les directions à gauche et glissez sur la scène pour regarder. Si le navigateur refuse la capture de la souris, cliquez-glissez sur la scène.</p>
    </div>
  </Modal>
}
export function KeypadPanel({ game, hud }: { game: Game; hud: HudState }) {
  const [value, setValue] = useState('')
  const [bad, setBad] = useState(false)
  const press = (d: string) => { setBad(false); setValue((v) => (v.length < 4 ? v + d : v)) }
  const submit = () => { if (value.length !== 4) return; if (!game.tryCode(value)) { setBad(true); setValue('') } }
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) press(e.key)
      else if (e.key === 'Backspace') setValue((v) => v.slice(0, -1))
      else if (e.key === 'Enter') submit()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })
  return <Modal title="Digicode" eyebrow="PORTE D’ENTRÉE / VERROU ÉLECTRONIQUE" onClose={() => game.closePanel()}>
    <div className="keypad">
      <div className={`keypad-screen ${bad ? 'bad' : ''}`} role="status" aria-live="polite">{bad ? 'ERREUR' : value.padEnd(4, '·').split('').join(' ')}</div>
      <div className="keypad-grid">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => <button key={d} onClick={() => press(d)}>{d}</button>)}
        <button onClick={() => { setValue(''); setBad(false) }} aria-label="Effacer">C</button>
        <button onClick={() => press('0')}>0</button>
        <button className="ok" onClick={submit} disabled={value.length !== 4}>OK</button>
      </div>
      {hud.code ? <p className="keypad-note">Le papier trouvé indique : <strong>{hud.code}</strong></p> : <p className="keypad-note">Quatre chiffres. Quelqu’un les a notés quelque part dans la maison.</p>}
    </div>
  </Modal>
}

export function NotePanel({ game, hud }: { game: Game; hud: HudState }) {
  return <Modal title="Un papier plié." eyebrow="TROUVÉ DANS UN TIROIR" className="letter-backdrop" onClose={() => game.closePanel()}>
    <div className="letter-paper">
      <p>Si ça tourne mal, voilà pour la porte :</p>
      <p className="note-code">{hud.code ?? '----'}</p>
      <p>Les planches sont clouées par-dessus. La clé du verrou est ailleurs. Cherchez dans les tiroirs : certains sont fermés, et la clé qui les ouvre est cachée aussi.</p>
      <p>Ne le laissez pas vous regarder trois fois.</p>
    </div>
    <footer className="dialog-footer"><span>Le code est noté dans votre carnet</span><button className="text-button" onClick={() => game.closePanel()}>Ranger le papier <Icon name="arrow" size={17}/></button></footer>
  </Modal>
}
