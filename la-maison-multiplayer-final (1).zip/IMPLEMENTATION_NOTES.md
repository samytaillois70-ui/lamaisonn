# La Maison — Extreme Horror v2

## Modifications
- Les signalements font disparaître la présence pendant exactement 30 secondes sans effacer l'historique des rencontres.
- Les rencontres restent comptabilisées : le jeu se souvient que la présence a déjà fixé le joueur.
- La présence apparaît brièvement, se déplace, puis disparaît pour revenir plus tard.
- Si elle reste non observée pendant 60 secondes, elle déclenche une poursuite directe.
- Les anomalies manquées augmentent une corruption progressive de l'éclairage et de l'ambiance.
- Le stress, les battements de cœur, les respirations, les distorsions et les sons de proximité restent dynamiques.
- Ajout de chuchotements vocaux rares via Speech Synthesis, avec phrases courtes en français.
- Intensité par défaut portée au niveau maximal disponible (1.35).
- Les commandes tactiles existaient déjà ; un repère de glissement pour regarder a été ajouté. Le déplacement et le regard tactile restent légers pour ne pas recouvrir l'écran.
- La corruption est sauvegardée et restaurée avec la partie.
- La persistance de l'historique des rencontres du monstre a été corrigée lors des sauvegardes.

## Validation
La syntaxe TypeScript des fichiers modifiés a été contrôlée. Le build complet n'a pas pu être exécuté dans l'environnement de travail car l'installation `node_modules` du ZIP est incomplète (les binaires Vite et plusieurs paquets sont absents). Le projet conserve toutefois son `package.json` et son `package-lock.json` pour une installation propre avec `npm ci` dans un environnement Node normal.

## Multijoueur
Le multijoueur en ligne avec code de lobby à 4 chiffres n'a pas été simulé avec un faux système local : une vraie synchronisation entre appareils nécessite un serveur de signalisation / relais ou une infrastructure WebRTC. Le ZIP reste donc jouable en solo et n'intègre pas de faux bouton « multijoueur » qui donnerait l'impression que le réseau fonctionne alors qu'il ne fonctionne pas.
