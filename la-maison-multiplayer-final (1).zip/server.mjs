import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const projectRoot = path.dirname(fileURLToPath(import.meta.url))
const root = fs.existsSync(path.join(projectRoot, 'dist', 'index.html')) ? path.join(projectRoot, 'dist') : projectRoot
const PORT = Number(process.env.PORT || 5173)
const rooms = new Map()
const sockets = new Map()

const send = (socket, payload) => {
  const data = Buffer.from(JSON.stringify(payload))
  const head = data.length < 126 ? Buffer.from([0x81, data.length]) : data.length < 65536 ? Buffer.from([0x81, 126, data.length >> 8, data.length & 255]) : null
  if (!head) return
  socket.write(Buffer.concat([head, data]))
}
const closeSocket = (socket) => { try { socket.end() } catch {} }
const newCode = () => { let c; do c = String(1000 + Math.floor(Math.random() * 9000)); while (rooms.has(c)); return c }
const publicPeer = p => ({ id:p.id, name:p.name, position:p.position, yaw:p.yaw, pitch:p.pitch, crouched:p.crouched, flashlight:p.flashlight })

function leave(peer) {
  if (!peer?.room) return
  const room = rooms.get(peer.room)
  if (!room) return
  room.peers.delete(peer.id)
  for (const p of room.peers.values()) send(p.socket, { type:'peer-left', id:peer.id })
  if (!room.peers.size) rooms.delete(peer.room)
  else if (room.host === peer.id) room.host = room.peers.keys().next().value
  peer.room = ''
}
function handle(peer, msg) {
  if (msg.type === 'create') {
    leave(peer)
    const code = newCode(); const room = { host:peer.id, peers:new Map() }
    rooms.set(code, room); peer.room = code; peer.name = String(msg.name || 'Joueur').slice(0,18)
    peer.position=[8.7,0,7.8]; peer.yaw=-Math.PI/2; peer.pitch=-0.04; peer.crouched=false; peer.flashlight=true; room.peers.set(peer.id, peer)
    send(peer.socket, { type:'lobby-created', code, peers:[publicPeer(peer)] })
    return
  }
  if (msg.type === 'join') {
    leave(peer)
    const code = String(msg.code || '').replace(/\D/g,'').slice(0,4); const room = rooms.get(code)
    if (!room) return send(peer.socket, { type:'error', message:'Ce code de lobby n’existe pas.' })
    if (room.peers.size >= 4) return send(peer.socket, { type:'error', message:'Ce lobby est complet (4 joueurs maximum).' })
    peer.room=code; peer.name=String(msg.name || 'Joueur').slice(0,18); peer.position=[8.7,0,7.8]; peer.yaw=-Math.PI/2; peer.pitch=-0.04; peer.crouched=false; peer.flashlight=true; room.peers.set(peer.id,peer)
    send(peer.socket, { type:'lobby-joined', code, peers:[...room.peers.values()].map(publicPeer) })
    for (const p of room.peers.values()) if (p.id !== peer.id) send(p.socket, { type:'peer-joined', peer:publicPeer(peer) })
    return
  }
  if (msg.type === 'state') {
    if (!peer.room) return
    const s = msg.state || {}
    peer.position = Array.isArray(s.position) && s.position.length === 3 ? s.position.map(Number) : peer.position
    peer.yaw=Number(s.yaw)||0; peer.pitch=Number(s.pitch)||0; peer.crouched=!!s.crouched; peer.flashlight=!!s.flashlight
    const room=rooms.get(peer.room); if (!room) return
    const packet={ type:'state', peer:publicPeer(peer) }
    for (const p of room.peers.values()) if (p.id !== peer.id) send(p.socket, packet)
    return
  }
  if (msg.type === 'leave') leave(peer)
}

function parseFrames(peer, buf) {
  let offset=0
  while (offset+2<=buf.length) {
    const b1=buf[offset], b2=buf[offset+1]; let len=b2&127; let header=2
    if (len===126) { if(offset+4>buf.length)return buf.subarray(offset); len=buf.readUInt16BE(offset+2); header=4 }
    else if(len===127) return Buffer.alloc(0)
    const masked=(b2&128)!==0; if(masked) header+=4
    if(offset+header+len>buf.length)return buf.subarray(offset)
    let payload=buf.subarray(offset+header,offset+header+len)
    if(masked){const key=buf.subarray(offset+header-4,offset+header); payload=Buffer.from(payload);for(let i=0;i<payload.length;i++)payload[i]^=key[i%4]}
    const opcode=b1&15
    if(opcode===8){closeSocket(peer.socket);return Buffer.alloc(0)}
    if(opcode===1){try{handle(peer,JSON.parse(payload.toString('utf8')))}catch{}}
    offset+=header+len
  }
  return buf.subarray(offset)
}

const server=http.createServer((req,res)=>{
  let url=decodeURIComponent(req.url.split('?')[0]); if(url==='/') url='/index.html'
  const file=path.resolve(root,'.',url.slice(1)); if(!file.startsWith(path.resolve(root))) return res.writeHead(403).end()
  if(!fs.existsSync(file)||fs.statSync(file).isDirectory()) return res.writeHead(404).end('Not found')
  const ext=path.extname(file); const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml'}
  res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-cache'}); fs.createReadStream(file).pipe(res)
})
server.on('upgrade',(req,socket)=>{
  if(req.url!=='/ws') return socket.destroy()
  const key=req.headers['sec-websocket-key']; if(!key)return socket.destroy()
  const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n')
  const peer={id:crypto.randomUUID(),socket,room:'',name:'Joueur',position:[8.7,0,7.8],yaw:0,pitch:0,crouched:false,flashlight:true}; sockets.set(peer.id,peer); send(socket,{type:'welcome',id:peer.id})
  let buffer=Buffer.alloc(0); socket.on('data',chunk=>{buffer=Buffer.concat([buffer,chunk]);buffer=parseFrames(peer,buffer)}); socket.on('close',()=>{leave(peer);sockets.delete(peer.id)}); socket.on('error',()=>{leave(peer);sockets.delete(peer.id)})
})
server.listen(PORT,()=>console.log(`La Maison server: http://localhost:${PORT}`))
