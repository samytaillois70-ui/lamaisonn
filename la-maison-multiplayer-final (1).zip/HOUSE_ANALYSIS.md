# La Maison: Preservation and Gameplay

## Existing House

`src/game/world.ts` and `src/game/rooms.ts` remain the source of the existing house. No replacement house, new level, alternative floor plan, new structural opening, or rearranged baseline furniture was introduced.

Changes to the existing builder are metadata and mesh partitioning: selected original furnishing geometry is made independently addressable. Its world-space vertices, textures, baseline bounds and collision boxes are preserved. Restarting a night restores those same objects; it does not regenerate the building. Procedural texture randomness is fixed for consistent appearances across reloads.

The exterior remains in the original scene, visible through the original windows. Gameplay begins indoors. The front door and vehicle door are locked for the night. There is no gameplay teleportation. Existing exterior cameras are excluded from the playable interior camera network, not removed from the house.

## Measured Layout

These bounds come from the original room records. Rectangles can overlap at subrooms and stairs; they are not summed as a claimed habitable surface. The runtime audit additionally computes navigable area.

| Level | Space | Original X bounds | Original Z bounds | Function |
| --- | --- | --- | --- | --- |
| 0 | Garage | 0 to 6 | 0 to 9 | Vehicle, tools, security terminal, basement access |
| 0 | Laundry | 6 to 8.5 | 0 to 3 | Lamp charging, basket, plumbing noises |
| 0 | WC | 8.5 to 10 | 0 to 3 | Small enclosed room, light, framed picture |
| 0 | Entry hall | 6 to 10 | 3 to 9 | Letter, terminal, main stairs |
| 0 | Kitchen | 10 to 18 | 0 to 4.5 | Three original stools, island, appliance noises |
| 0 | Living room | 10 to 18 | 4.5 to 9 | Original television, books, furniture cover |
| 1 | Upper hall | 6 to 8.6 | 0 to 9 | Landing, frames, stair void |
| 1 | Upper hall extension | 8.6 to 11.6 | 4.5 to 5.7 | Shared logical hall, bathroom and suite access |
| 1 | Guest bedroom | 8.6 to 13 | 0 to 4.5 | Original desk chair, pictures, wardrobe |
| 1 | Bathroom | 8.6 to 11.6 | 5.7 to 9 | Original towel, light, plumbing noises |
| 1 | Main bedroom | 11.6 to 18 | 4.5 to 9 | Original armchair, frames, dressing access |
| 1 | Dressing | 13 to 18 | 0 to 4.5 | Original small box, wardrobe blind spots |
| -1 | Basement envelope | 0 to 9 | 0 to 9 | Storage, table, structure-borne noises |
| -1 | Utility room | 6.4 to 9 | 5.8 to 9 | Original breaker panel, security terminal |
| -1 | Basement stair region | 0.3 to 4.5 | 0 to 1.5 | Only connection to the garage |

The original floor elevations are -3, 0 and 3 metres. The two original ramp functions define the stair slopes. Interior ceiling clearance is approximately 2.8 metres.

## Automatic Analysis

`src/game/house.ts` builds the logical house from the actual construction output:

- Room identifiers, dimensions, subregions, original objects and room functions.
- Wall openings captured during the original wall construction, including windows, doors and arches.
- Floor and ceiling volumes used for sight and acoustic obstruction.
- A 0.25 m navigation lattice sampled on the original floors and stair ramps.
- Connectivity and inaccessible components determined by flood-fill of collision-cleared nodes.
- A* movement between reachable nodes, with no edges jumping between unrelated floors.
- Cover candidates determined by low-height obstruction tests.
- Interior camera room assignments and sampled sightlines.
- Oriented door-leaf collision and occlusion when a leaf is open.

The downloadable analysis in **Settings > Analyse de la maison** contains the real runtime measurements and diagnostic results. It does not invent a scanned area or a reconstruction percentage.

## System Boundaries

| Module | Responsibility |
| --- | --- |
| `house.ts` | Geometry-derived rooms, navigation, visibility, object/collider transforms |
| `player.ts` | Inertial movement, collisions, stairs, crouching, finite sprint, battery |
| `doors.ts` | Door state, animation, locked exits, closing safety |
| `interactions.ts` | Original object inspection, switches, terminals, letter, charger, breaker |
| `lighting.ts` | Physical light sources, room circuits, shadow pool, torch, dawn |
| `cameras.ts` | Existing interior viewpoints, bounded PTZ, signal faults, wall monitor render targets |
| `audio.ts` | Procedural Web Audio, HRTF spatialization, distance falloff, wall/door/floor low-pass filtering |
| `anomalies.ts` | Weighted definitions, unseen activation, room/category reports, original-state restoration |
| `entity.ts` | A* locomotion, observation, searching, retreat and late-night pursuit |
| `director.ts` | Irregular pacing, benign noises, calm intervals, optional electrical failure |
| `night.ts` | 22:00 to 06:00 progression, phases, journal, terminal success |
| `settings.ts` | Persistent preferences and safe local-storage access |
| `engine.ts` | System orchestration, input, UI state, rendering, snapshots, local saves |

## Play Loop

The first hour is a baseline observation period. Changes then appear in previously visited spaces, and later throughout the house. The player identifies a room and a category rather than receiving automatic anomaly highlights. Successful reports reduce pressure. Repeated false reports and neglected anomalies increase it. Acknowledged objects return to their original states outside the view, not in a visible pop.

The entity begins at a fixed concealed location in the existing utility room. It does not repeatedly spawn or teleport. It follows the same connected floors, stairs and openings as the player, waits for doors to open, responds to running noise, and retreats from sustained observation before the late-night hunting phases. Losing its sightline with a wall, a door, or sufficiently tall furnishing matters. Crouching does not grant invulnerability.

The night lasts 20 real-time minutes by default; 12 and 32 minute variants are available. Victory is surviving until 06:00, not guessing a hidden minimum report quota. Capture is a physical proximity and line-of-sight condition. The ending stays in the same house.

Cameras and the reporting panel do not pause the simulation. Reading the journal, plan, instructions or settings pauses it explicitly. Losing browser focus also pauses it. The player remains at their physical position while viewing a camera.

The torch lasts roughly ten minutes if continuously lit. The laundry charger requires six seconds of held interaction. A triggered power failure is resolved at the original utility panel. Sprint lasts about five seconds, followed by approximately ten seconds of recovery.

## Added Props

Only discreet interaction elements were added: light switches beside existing openings, a small charger on the existing laundry counter, a letter on the existing hall console, and live display planes over existing surveillance screens. None creates a new room, hides a structural modification, or substitutes the existing architecture.

## Validation

`src/game/checks.ts` runs against the real constructed house in the browser. Its diagnostic results are included in the exported analysis:

- Collision-free interior spawn.
- Preservation of both stair ramp definitions.
- Continuous routes to the upper floor, basement, laundry and breaker.
- Occlusion by an existing partition and closed door; visibility through an existing arch.
- Preservation of the captured furnishings' original bounds.
- Correct 22:00, midnight and 06:00 clock states and victory transition.
- Limited sprint and recovery.

Production compilation is checked with the project's build tool. These runtime diagnostics do not replace a manual full-night playthrough or hardware-specific performance and audio testing.

## Manual QA Checklist

1. Start a night, read the physical hall letter, and navigate every room without any teleport controls.
2. Ascend and descend both original staircases, including the narrow bottom landing of the main stairs.
3. Open and close each interior door, including while standing in its doorway.
4. Toggle a real nearby switch; confirm the local lamps and illumination change together.
5. Drain some battery, locate the laundry charger, hold E, release early, then complete a charge.
6. Open V, switch channels, pan, zoom, return, and confirm the player's position is unchanged.
7. Photograph with N and inspect the actual image in J.
8. Observe a baseline, discover a changed object, and report the correct room/category with R.
9. Compare a false report, a sound caused by ordinary plumbing, and repeated anomalous knocking.
10. Pause, reload the page, resume, and verify doors, battery, clock, anomalies and visited rooms persist.
11. Test power restoration at the original utility panel if the director triggers the event.
12. Complete a full night and test a loss, then restart and confirm the original house state returns.
13. Repeat input tests with a refused pointer lock, touch controls, muted audio and reduced-effects settings.

## Scope and Limits

This is a solo React/Three.js browser game, not a Roblox Studio place. There are no fictional server, replication or streaming claims. Multiplayer and a Roblox/Luau port are not implemented.

The original modeled house is preserved rather than replaced with photogrammetry. Acoustic obstruction uses the actual collision geometry and floor volumes, not a full wave simulation. Cameras expose one selected live feed, plus low-frequency wall displays; there are no video archives. They have occasional interference only, not a permanent VHS filter. Graphics, pointer-lock availability and frame rate depend on the browser and hardware.
## Escape game and encounters (added later)

Nothing of the house structure was changed. Everything below sits on faces and surfaces that already exist.

**Hiding places.** Twelve drawer fronts are laid over existing furniture faces (hall and living-room consoles, kitchen island, laundry unit, garage tool chest and workbench, both upstairs bedside tables, dressing island, bathroom vanity, TV unit, main-bedroom chest). They slide out when used. Two of them (TV unit, main-bedroom chest) are locked. Each night the hammer, the front-door key, the gun-cabinet key, a paper with the door code and the small drawer key are shuffled among them; the small key is never behind a lock, so every layout is solvable. This was checked automatically on 12 random layouts.

**Front door.** Two planks are nailed over the inside of the door, a brass deadbolt sits at handle height and a keypad is fixed to the wall to its right. The door only opens once all three are dealt with (hammer, key, code). The original door leaf is still locked for navigation purposes.

**Gun cabinet.** A steel cabinet against the east wall of the basement. Its key is hidden like the others. It holds a pistol and exactly three cartridges, which cannot be reloaded.

**Encounters.** Each time the player lays eyes on the creature (in the room, or on a camera) without having reported the previous one, a counter goes up:
1. it stops and stares for 8 s (at the lens, if seen on a camera);
2. it stares for 7 s while the picture tears, the colours turn and the sound distorts;
3. it stares for 10 s, then chases at 4.5 m/s (the player runs at 4.35 m/s) for 10 s. Surviving the chase ends the game as a win.
Any accepted report, or a bullet that hits, makes it disappear, resets the counter and brings another one back later in the night.

**Verification.** Reachability of all 18 interaction points, solvability, the encounter state machine, the chase timing, shooting and the keypad were exercised in a headless browser with software rendering. The look of the creature and of the new props could not be judged by eye in that environment, only by luminance maps, and frame rate could not be measured on a real GPU.


## Second pass: the chain, 01:00, and what a drawer is

**01:00.** The creature does not exist before 01:00 (three eighths of the night: 4.5, 7.5 or 12 minutes of play for the 12, 20 and 32 minute nights). Nothing can wake it, and it never appears in a camera. A journal line and one low sound mark the hour; it then appears 6 to 22 seconds later, out of sight and far from the player.

**Vanishing.** An accepted report makes it disappear for 30 s, a bullet that hits for 60 s. Both clear the count of unreported meetings. It comes back somewhere dark and out of view.

**The chain.** Items are never scattered at random any more. The small drawer key is always in a free drawer on the ground floor (hall, living room, kitchen island or laundry); the hammer in the garage (workbench or tool chest); the paper with the code in a bedside table or the bathroom; the front-door and gun-cabinet keys in the three drawers that have a lock (TV unit, main-bedroom chest, dressing island). Picking up the small key lists the locked pieces of furniture. A key tag says what it opens. After 150 seconds without progress the objective names a room (never a drawer) for the next thing needed. Checked on 60 random nights: always solvable, and the first three tools never sit behind a lock.

**Drawers.** Twelve, each with a wooden or painted front, a handle in one of four styles, a keyhole plate when locked, a black seam where it meets the furniture, runners, a box with raw wood inside, and the same junk in the same places every night (pencils, batteries, tape, matches, coins, screws, rubber bands, fuses, an envelope). They slide on a spring, stop with a small bounce, rattle when opened, shake and rattle when a locked one is tried, and a picked-up object rises to the eyes and turns before it is pocketed.

**Verification.** Chain, early tools, hints, pickup, spawn time, both vanishing durations and the death sequence were run in a headless browser with software rendering. All 24 sounds were synthesised and checked for non-silence and invalid samples. How the creature and the drawers look, and how the new sounds feel, could not be judged there.
