# La Maison — vrai multijoueur

Le projet inclut maintenant un serveur WebSocket léger avec salons à 4 chiffres.

## Lancer

1. Installer les dépendances : `npm install`
2. Construire : `npm run build`
3. Lancer le serveur : `npm start`
4. Ouvrir `http://localhost:5173`.

Pour jouer depuis plusieurs appareils du même réseau, lancer le serveur sur le PC hôte puis ouvrir son adresse LAN, par exemple `http://192.168.1.20:5173`.

Le serveur gère :
- création de salons avec code à 4 chiffres ;
- rejoindre un salon ;
- maximum 4 joueurs ;
- présence et déconnexion ;
- synchronisation des positions, orientation, accroupissement et lampe ;
- avatars distants légers pour préserver les performances.

Le gameplay d'horreur reste local pour éviter de faire transiter les grosses données 3D. Le protocole peut ensuite être étendu pour synchroniser les anomalies et événements de partie.
